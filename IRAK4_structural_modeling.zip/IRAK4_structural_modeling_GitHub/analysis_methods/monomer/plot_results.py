"""Static scientific plots of descriptive metrics; samples are not replicates."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.patches import Patch

OUT=Path(__file__).resolve().parents[1]
D=OUT/'data';F=OUT/'figures'
def read(name):return list(csv.DictReader((D/name).open()))
rows=read('all_pairwise_comparisons.csv');tors=read('local_torsions.csv');dist=read('selected_distances.csv');conf=read('aligned_per_residue.csv')
COL={'WT':'#2875A5','Q29P':'#D67A26','D320Y':'#A0498C'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','svg.fonttype':'none'})
fig,ax=plt.subplots(2,3,figsize=(15,10))
fig.subplots_adjust(left=.065,right=.975,bottom=.13,top=.86,wspace=.36,hspace=.55)

# Atom-independent, per-residue QA metric from CIF, identical to CA pLDDT.
a=ax[0,0]
for g in COL:
 y=np.array([[float(r['pLDDT']) for r in conf if r['group']==g and int(r['rank'])==k and r['domain_fit']=='DD'] for k in range(5)])
 a.plot(np.arange(1,461),y.mean(0),label=g,color=COL[g],lw=1.5)
 a.fill_between(np.arange(1,461),y.min(0),y.max(0),alpha=.13,color=COL[g])
a.axvspan(20,104,color='#D5E8F0',alpha=.35,zorder=-2);a.axvspan(186,454,color='#E3DFEB',alpha=.3,zorder=-2)
a.set(xlim=(1,460),ylim=(0,100),xlabel='IRAK4 residue',ylabel='pLDDT (0-100)',title='A  Local confidence\nMean and sample range');a.legend(frameon=False,loc='lower right',bbox_to_anchor=(1,.10),ncol=3,fontsize=8)
a.text(60,5,'Death domain',ha='center',fontsize=8);a.text(320,5,'Kinase domain',ha='center',fontsize=8)

a=ax[0,1]
pae=np.load(OUT/'inputs'/'WT'/'pae.rank_0.npy',allow_pickle=False)
im=a.imshow(pae,vmin=0,vmax=30,cmap='viridis',origin='lower',extent=(.5,460.5,.5,460.5),rasterized=True)
a.set(xlabel='Residue',ylabel='Residue',title='B  Predicted aligned error\nWT rank 0')
cb=fig.colorbar(im,ax=a,shrink=.8,pad=.02);cb.set_label('PAE (Å)')
for b in (104.5,185.5):a.axhline(b,color='white',lw=.6,alpha=.8);a.axvline(b,color='white',lw=.6,alpha=.8)

def pairplot(a,domain,mut,title):
 labels=['WT-WT','WT-'+mut,mut+'-'+mut];colors=[COL['WT'],COL[mut],COL[mut]]
 for i,(lab,c) in enumerate(zip(labels,colors)):
  ys=np.array([float(r['target_backbone_RMSD_A']) for r in rows if r['domain']==domain and r['group_pair']==lab])
  # Deterministic x-offsets for visibility, not an inferential distribution.
  xs=i+np.linspace(-.15,.15,len(ys));a.scatter(xs,ys,color=c,s=24,alpha=.7,edgecolor='white',lw=.3)
  a.hlines(np.median(ys),i-.24,i+.24,color='black',lw=1.5)
  a.text(i,max(ys)+.07,f'median {np.median(ys):.2f} Å',ha='center',fontsize=8)
 a.set_xticks(range(3),['WT within\n10 pairs',f'WT vs {mut}\n25 pairs',f'{mut} within\n10 pairs'])
 a.set(ylabel='Local backbone RMSD (Å)',title=title,ylim=(0,1.65 if domain=='DD' else 1.3))
 a.grid(axis='y',alpha=.15);a.set_axisbelow(True)
pairplot(ax[0,2],'DD','Q29P','C  Q29P local backbone comparison\nResidues 24-34; death-domain fit')

a=ax[1,0]
for g in ('WT','Q29P'):
 sel=[r for r in tors if r['group']==g and r['residue']=='29']
 a.scatter([float(r['phi_deg']) for r in sel],[float(r['psi_deg']) for r in sel],c=COL[g],s=55,label=g,edgecolor='white',lw=.6,zorder=3)
q=next(r for r in tors if r['group']=='Q29P' and r['rank']=='0' and r['residue']=='29')
a.annotate('Q29P rank 0',xy=(float(q['phi_deg']),float(q['psi_deg'])),xytext=(-130,155),arrowprops={'arrowstyle':'-','color':'#444'},fontsize=9)
a.annotate('Q29P ranks 1-4',xy=(-87,15),xytext=(-165,-35),arrowprops={'arrowstyle':'-','color':'#444'},fontsize=9)
a.set(xlim=(-180,180),ylim=(-180,180),xlabel='Phi (degrees)',ylabel='Psi (degrees)',title='D  Residue 29\nMain-chain torsions')
a.axhline(0,color='#ddd',lw=.8);a.axvline(0,color='#ddd',lw=.8);a.legend(frameon=False,loc='lower right');a.set_xticks([-180,-90,0,90,180]);a.set_yticks([-180,-90,0,90,180])
pairplot(ax[1,1],'KD','D320Y','E  D320Y local backbone comparison\nResidues 315-325; kinase-domain fit')

a=ax[1,2]
for i,partner in enumerate((265,267,324)):
 for k,g in enumerate(('WT','D320Y')):
  ys=[float(r['sidechain_sidechain_min_A']) for r in dist if r['group']==g and r['target']=='320' and r['partner']==str(partner)]
  center=i+(-.17 if k==0 else .17)
  a.scatter(center+np.linspace(-.055,.055,5),ys,c=COL[g],s=32,edgecolor='white',lw=.4,label=g if i==0 else None)
  a.hlines(np.median(ys),center-.09,center+.09,color=COL[g],lw=2)
a.set_xticks(range(3),['M265','N267','T324']);a.set(ylabel='Nearest side-chain heavy atoms (Å)',title='F  Residue 320\nIntradomain side-chain distances',ylim=(2.7,6.9));a.legend(frameon=False,ncol=2,loc='upper left');a.grid(axis='y',alpha=.15)
fig.suptitle('IRAK4 Chai-1 monomer predictions: first-run descriptive analysis',fontsize=16,fontweight='bold',y=.97)
fig.text(.5,.025,'Five ranked samples per genotype; seed IDs were not provided. Pairwise comparisons share models and are not independent replicates.\nRMSDs use N, CA, C and O after fitting a shared domain core. Distances describe geometry, not binding energies or kinase activity.',ha='center',fontsize=9,color='#444')
fig.savefig(F/'IRAK4_Chai_quantitative.png',dpi=220)
fig.savefig(F/'IRAK4_Chai_quantitative.svg')
plt.close(fig)
print(F/'IRAK4_Chai_quantitative.png')
