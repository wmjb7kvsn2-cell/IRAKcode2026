"""PyMOL views of rigidly aligned prediction coordinates; no remodeling."""
from pathlib import Path
from pymol import cmd
O=Path(__file__).resolve().parents[1];A=O/'aligned_structures';P=O/'figures'
def init():
 cmd.reinitialize();cmd.bg_color('white');cmd.set('orthoscopic',1);cmd.set('ray_shadows',0);cmd.set('antialias',2);cmd.set('specular',.15)
 cmd.set('ray_opaque_background',1);cmd.set('cartoon_fancy_helices',1);cmd.set('stick_radius',.16)
 cmd.set('label_color','black');cmd.set('label_size',18);cmd.set('label_font_id',7);cmd.set('label_outline_color','white')
 cmd.set_color('wtblue',[.157,.459,.647]);cmd.set_color('qorange',[.84,.48,.15]);cmd.set_color('qgreen',[.18,.60,.46]);cmd.set_color('dmagenta',[.63,.29,.55])
def load(name,file,color,region):
 cmd.load(str(A/file),name);cmd.remove(name+' and (not chain A or hydro)');cmd.hide('everything',name)
 cmd.remove(f'{name} and not ({region})');cmd.show('cartoon',name);cmd.color(color,name);cmd.set('cartoon_transparency',.25,name)
def stick(sel,color):
 cmd.show('sticks',sel);cmd.color(color,sel+' and elem C');cmd.color('red',sel+' and elem O');cmd.color('blue',sel+' and elem N');cmd.color('yelloworange',sel+' and elem S')
init()
load('wt','DD_WT_rank0.pdb','wtblue','resi 20-104')
load('q0','DD_Q29P_rank0.pdb','qorange','resi 20-104')
load('q1','DD_Q29P_rank1.pdb','qgreen','resi 20-104')
for obj,col in [('wt','wtblue'),('q0','qorange'),('q1','qgreen')]:
 stick(f'{obj} and resi 29',col)
 cmd.set('cartoon_transparency',0,f'{obj} and resi 24-34')
cmd.orient('wt and resi 22-36');cmd.turn('y',30);cmd.turn('z',-20);cmd.zoom('(wt or q0 or q1) and resi 24-34',5)
cmd.hide('cartoon','all');cmd.show('ribbon','all');cmd.set('ribbon_width',3)
cmd.hide('ribbon','not resi 20-45');cmd.zoom('(wt or q0 or q1) and resi 20-45',3)
cmd.png(str(P/'Q29P_local_pymol.png'),width=1300,height=1000,dpi=300,ray=1)
init()
load('wt','KD_WT_rank0.pdb','wtblue','resi 255-275+307-331')
load('dy','KD_D320Y_rank0.pdb','dmagenta','resi 255-275+307-331')
for obj,col in [('wt','wtblue'),('dy','dmagenta')]:
 for i in (265,320,324):stick(f'{obj} and resi {i}',col)
cmd.hide('cartoon','all');cmd.show('ribbon','all and resi 315-325');cmd.set('ribbon_width',3)
cmd.label('wt and resi 265 and name CA','"M265"');cmd.label('wt and resi 324 and name CA','"T324"')
cmd.label('dy and resi 320 and name OH','"Y320"')
cmd.set('label_position',(1.5,1.5,1.5))
cmd.set('label_position',(3,3,0),'wt and resi 265 and name CA')
cmd.set('label_position',(-3,-3,0),'wt and resi 324 and name CA')
cmd.orient('dy and resi 320 and name CG+CD1+CD2+CE1+CE2+CZ');cmd.zoom('(wt or dy) and resi 265+320+324',5)
cmd.png(str(P/'D320Y_local_pymol.png'),width=1300,height=1000,dpi=300,ray=1)
cmd.quit()
