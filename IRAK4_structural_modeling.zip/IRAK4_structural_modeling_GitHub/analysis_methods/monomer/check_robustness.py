"""Alignment sensitivity and geometric checks independent of main summary."""
from pathlib import Path
import json,itertools,argparse
import numpy as np
from Bio.PDB import MMCIFParser
from Bio.PDB.MMCIF2Dict import MMCIF2Dict
from analyze_chai import OUT,DOMAINS,TARGETS,BB,atoms,fit,rmsd,writecsv,stats

ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,required=True);args=ap.parse_args()
inp=args.inputs
models=[]
for g in ('WT','Q29P','D320Y'):
 for rank in range(5):
  p=inp/g/f'pred.rank_{rank}.cif'
  s=MMCIFParser(QUIET=True).get_structure(g,str(p));d=MMCIF2Dict(str(p))
  models.append({'group':g,'rank':rank,'res':{r.id[1]:r for r in s[0]['A']},'conf':{int(i):float(v) for i,v in zip(d['_ma_qa_metric_local.label_seq_id'],d['_ma_qa_metric_local.metric_value'])}})
rows=[]
for domain,(lo,hi) in DOMAINS.items():
 target=list(range(TARGETS[domain][0],TARGETS[domain][1]+1))
 for cutoff in (0,75,80,90):
  core=[i for i in range(lo,hi+1) if i not in target and all(m['conf'][i]>=cutoff for m in models)]
  for a,b in itertools.combinations(models,2):
   if a['group']!='WT':continue
   R,t=fit(atoms(b,core),atoms(a,core))
   rows.append({'domain':domain,'core_pLDDT_cutoff':cutoff,'core_n':len(core),'group_pair':a['group']+'-'+b['group'],'rank1':a['rank'],'rank2':b['rank'],'local_BB_RMSD_A':rmsd(atoms(b,target,BB)@R+t,atoms(a,target,BB))})
writecsv('alignment_sensitivity.csv',rows)
summary=[]
for domain in DOMAINS:
 for cutoff in (0,75,80,90):
  for label in ('WT-WT','WT-Q29P','WT-D320Y'):
   vals=[r['local_BB_RMSD_A'] for r in rows if r['domain']==domain and r['core_pLDDT_cutoff']==cutoff and r['group_pair']==label]
   summary.append({'domain':domain,'cutoff':cutoff,'group_pair':label,**stats(vals)})
writecsv('alignment_sensitivity_summary.csv',summary)
geoms=[]
for m in models:
 for i in list(range(24,35))+list(range(315,326)):
  r=m['res'][i]
  triple=float(np.dot(np.cross(r['N'].coord-r['CA'].coord,r['C'].coord-r['CA'].coord),r['CB'].coord-r['CA'].coord)) if 'CB' in r else None
  row={'group':m['group'],'rank':m['rank'],'residue':i,'resname':r.resname,'N_CA_A':float(np.linalg.norm(r['N'].coord-r['CA'].coord)),'CA_C_A':float(np.linalg.norm(r['CA'].coord-r['C'].coord)),'C_O_A':float(np.linalg.norm(r['C'].coord-r['O'].coord)),'CA_chirality_signed_volume_A3':triple}
  if r.resname=='PRO':row['Pro_N_CD_ring_bond_A']=float(np.linalg.norm(r['N'].coord-r['CD'].coord))
  geoms.append(row)
writecsv('local_geometry.csv',geoms)
print('Q29P Pro29 ring N-CD and chirality:')
for r in geoms:
 if r['group']=='Q29P' and r['residue']==29:print(r)
print('RMSD sensitivity:')
for r in summary:
 if (r['domain']=='DD' and r['group_pair'] in ('WT-WT','WT-Q29P')) or (r['domain']=='KD' and r['group_pair'] in ('WT-WT','WT-D320Y')):print(r)
