"""Assemble reproducible first-run deliverables and prospective sequence inputs."""
from pathlib import Path
import json,csv,shutil,sys,platform,hashlib,zipfile,importlib.metadata
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from Bio.PDB import MMCIFParser
from Bio.SeqUtils import seq1

O=Path(__file__).resolve().parents[1]
j=json.loads((O/'data/summary.json').read_text())
def stat(v,nd=2):return f"{v['median']:.{nd}f} ({v['min']:.{nd}f}–{v['max']:.{nd}f})"

# Both Q29P rank 0 and a member of the four-sample group are displayed.
fig,ax=plt.subplots(1,2,figsize=(13,6.5))
fig.subplots_adjust(left=.02,right=.98,top=.85,bottom=.2,wspace=.04)
for a,name in zip(ax,['Q29P_local_pymol.png','D320Y_local_pymol.png']):
 a.imshow(plt.imread(O/'figures'/name));a.axis('off')
ax[0].set_title('A  Q29P: two sampled local conformations\nCα traces, residues 20-45; residue 29 in sticks',fontsize=11,fontweight='bold')
ax[1].set_title('B  D320Y: local packing comparison\nCα traces, residues 315-325; selected residues in sticks',fontsize=11,fontweight='bold')
ax[0].legend(handles=[Line2D([0],[0],color='#2875A5',lw=3,label='WT rank 0'),Line2D([0],[0],color='#D67A26',lw=3,label='Q29P rank 0'),Line2D([0],[0],color='#2E9975',lw=3,label='Q29P rank 1')],loc='upper center',bbox_to_anchor=(.5,-.03),ncol=3,frameon=False,fontsize=9)
ax[1].legend(handles=[Line2D([0],[0],color='#2875A5',lw=3,label='WT rank 0'),Line2D([0],[0],color='#A0498C',lw=3,label='D320Y rank 0')],loc='upper center',bbox_to_anchor=(.5,-.03),ncol=2,frameon=False,fontsize=9)
fig.suptitle('IRAK4 Chai-1 predicted local structures',fontsize=16,fontweight='bold',y=.98)
fig.text(.5,.035,'Original prediction coordinates were rigidly aligned by domain; no mutation modeling or relaxation was performed.\nThese monomer structures do not establish Myddosome affinity, protein stability or kinase activation.',ha='center',fontsize=9,color='#444')
fig.savefig(O/'figures/IRAK4_Chai_local_structures.png',dpi=240);plt.close(fig)

seqs={}
for g in ['WT','Q29P','D320Y']:
 chain=MMCIFParser(QUIET=True).get_structure(g,str(O/f'inputs/{g}/pred.rank_0.cif'))[0]['A']
 seqs[g]=''.join(seq1(r.resname) for r in chain)
nextdir=O/'next_step_sequences';nextdir.mkdir(exist_ok=True)
def fasta(name,s):
 (nextdir/(name+'.fasta')).write_text('>'+name+'\n'+'\n'.join(s[i:i+70] for i in range(0,len(s),70))+'\n')
for g,s in seqs.items():fasta('IRAK4_'+g+'_full_length',s)
for g in ['WT','Q29P']:fasta('IRAK4_DD_'+g+'_res4-106',seqs[g][3:106])
for g in ['WT','D320Y']:fasta('IRAK4_KD_'+g+'_res186-454',seqs[g][185:454])
root=O.parents[1]
refdir=O/'reference_sequences';refdir.mkdir(exist_ok=True)
for fn in ['Q99836.fasta','O43187.fasta']:
 if not (refdir/fn).exists():shutil.copy2(root/'output/IRAK4_structure/source'/fn,refdir/fn)
for name,fn,lo,hi in [('MyD88_DD_res20-117','Q99836.fasta',20,117),('IRAK2_DD_res2-112_native_R50','O43187.fasta',2,112)]:
 s=''.join(x.strip() for x in (refdir/fn).read_text().splitlines() if not x.startswith('>'))
 if name.startswith('IRAK2'):assert s[49]=='R'
 fasta(name,s[lo-1:hi])
assert seqs['Q29P'][3:106][25]=='P' and seqs['D320Y'][185:454][134]=='Y'
notes='''# 后续预测输入说明

这些文件仅为准备好的序列，尚未提交预测。不需要立即运行全部任务。

## 优先顺序

1. 如已有 Protenix 同设置 WT、D320Y、Q29P 全长单体结果，先进行跨模型核对，避免重复计算。尚未运行时可先各一个相同 seed、相同样本数，再决定扩展。
2. D320Y 可增加一对独立激酶结构域预测：WT 与 D320Y，均采用186–454，共269 aa，输入中的第135位对应全长D320/Y320。此举用于检查全长模型中不确定的DD–KD相对位置是否影响局部预测；不是活性测定。
3. Q29P 优先考虑WT/Q29P Myddosome death-domain复合物。单体不能预测该界面的真实改变。如果先检查局部采样，也可运行4–106的WT/Q29P DD单体，但其结果仍不能替代界面分析。

## Myddosome复合物建议设计

每个复合物任务输入3种蛋白实体，分别设置Copies；两组仅改变IRAK4实体。

| 组分 | 文件 | Copies | 每条长度 |
|---|---|---:|---:|
| MyD88 DD | MyD88_DD_res20-117.fasta | 6 | 98 |
| IRAK4 DD WT 或 Q29P | IRAK4_DD_WT_res4-106.fasta 或 IRAK4_DD_Q29P_res4-106.fasta | 4 | 103 |
| IRAK2 DD | IRAK2_DD_res2-112_native_R50.fasta | 4 | 111 |

总计14条链、1444个残基；是否支持该规模，以服务器限制为准。两组均使用相同的MSA、模板和采样策略，不添加未经实验支持的接触约束。
Q29P组4个IRAK4 DD拷贝均为Q29P；这是隔离变异效应的纯变异体比较，不模拟患者等位基因混合。
IRAK4片段第26位对应全长Q29/P29；IRAK2保留天然R50。参考实验结构3MOP中的IRAK2含工程化R50W，需区分输入序列与实验构建体背景。
同源链存在置换等价性，后续比较需按结构拓扑映射对应界面，不能仅依赖链字母。

## 提交与保存

复制FASTA的纯氨基酸序列至网页；单体Copies=1，复合物按上表设置。任务名应包含组别、片段边界和run/seed。
保存所有结构、置信度、任务参数、MSA/模板命中及seed信息（若能下载）。同一seed的多个扩散样本不作为独立生物学重复。
'''
(nextdir/'README.md').write_text(notes)

# Descriptive contact frequencies, restricted to the annotated target domain.
contacts=list(csv.DictReader((O/'data/local_contacts_4p5A.csv').open()))
freq=[]
for g in seqs:
 for target in (29,320):
  selected=[r for r in contacts if r['group']==g and int(r['target'])==target and r['within_target_domain']=='True']
  for partner in sorted(set(int(r['partner']) for r in selected)):
   rr=[r for r in selected if int(r['partner'])==partner]
   freq.append({'group':g,'target':target,'partner':partner,'partner_resname':rr[0]['partner_resname'],'samples_with_contact_of_5':len(rr),'sample_ranks':','.join(r['rank'] for r in rr),'observed_min_A':min(float(r['min_sidechain_to_partner_heavy_A']) for r in rr),'observed_max_A':max(float(r['min_sidechain_to_partner_heavy_A']) for r in rr)})
with (O/'data/intradomain_contact_sample_counts.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=freq[0].keys());w.writeheader();w.writerows(freq)

qualityrows='\n'.join('| '+g+' | '+ ' | '.join(stat(j['quality'][g][k],1 if k.startswith('pLDDT') else 2) for k in ['pLDDT_29','pLDDT_320','pLDDT_DD_mean','pLDDT_KD_mean','PAE_DD_KD_median_A'])+' |' for g in seqs)
pairrows=[]
for domain,labels in [('DD',['WT-WT','WT-Q29P','Q29P-Q29P','WT-D320Y']),('KD',['WT-WT','WT-D320Y','D320Y-D320Y','WT-Q29P'])]:
 for lab in labels:pairrows.append(f"| {domain} | {lab} | {stat(j['pairwise'][domain][lab])} | {j['pairwise'][domain][lab]['n_pairs']} |")
distrows='\n'.join(f"| {p} | {stat(j['distances']['WT'][str(p)]['sidechain_sidechain_min_A'])} | {stat(j['distances']['D320Y'][str(p)]['sidechain_sidechain_min_A'])} |" for p in [265,267,324])
report=f'''# IRAK4 Chai-1 首轮单体结构分析

分析日期：2026-10-24。范围：用户上传的WT、Q29P、D320Y各1个Chai-1网页任务，每组5个rank结构，共15个预测结构。

## 主要结论

本批次预测支持两个变异位点附近存在局部主链及接触重排的计算观察。D320Y的315–325位局部变化在该任务5个样本中较一致；Q29P的24–34位发生主链调整，但其最高排名结构与其余4个样本形成不同局部构象，尚不能指定唯一突变构象。以上是同一任务内的采样一致性，不是跨seed验证或功能证据。

完整蛋白DD–KD相对位置的PAE约26 Å，因此未使用全长叠合或跨结构域接触进行机制解释。没有进行新的结构预测、坐标优化、分子动力学、ΔΔG计算或结合亲和力计算。

## 输入核查和可追溯信息

15/15结构均为单条A链、460个连续标准氨基酸；Q29P和D320Y分别仅有预期的一处替换。没有把两种变异放在同一条链。每个任务均包含5个CIF、5个评分JSON、5个460×460的PAE矩阵和1个MSA深度PDF。
参数截图及用户说明：protein、Copies=1、Chain A、MMseqs2 MSA启用、模板启用、未指定人为约束。截图是参数设置依据，ZIP未包含原始请求、实际MSA序列或模板命中，无法从导出文件核实三组MSA/模板是否逐条相同。精确checkpoint、软件版本、seed编号和完整推理参数未提供，不作推定。rank不是seed。

已查看三组MSA深度图，整体覆盖分布相似，DD的覆盖相对激酶核心区域较浅；未从图片推算精确序列数或有效序列数Neff。缺少原始MSA，因此不能核实实际同源序列集合完全相同，也不能据覆盖差异单独解释局部构象变化。

评分JSON中的ipTM=0属于单体输出，不能解释为界面失败。has_inter_chain_clashes=false仅指链间碰撞，不代表分子内部完整几何检查通过。本次各文件aggregate_score均约等于0.2×pTM，不能把约0.13的aggregate_score单独当作低质量结构或稳定性指标。

## 结构置信度

下表为5个样本中位数（最小–最大）；pLDDT来自CIF明确定义的逐残基QA指标，并已核对与CA原子的B字段相同。没有将不同原子的B字段简单平均成逐残基置信度。

| 组别 | 29位pLDDT | 320位pLDDT | DD平均pLDDT | KD平均pLDDT | DD–KD区块PAE中位数 Å |
|---|---:|---:|---:|---:|---:|
{qualityrows}

较低的Q29P位点pLDDT提示原子级解释需谨慎；这不是蛋白失稳的证据。结构域内PAE约2–3 Å，与结构域间高PAE形成对照，故分别比较两个结构域。

## 叠合和局部主链比较

按UniProt Q9NWZ3缓存注释，以20–104为DD、186–454为KD。预定局部分析窗口分别为24–34和315–325。使用结构域共同CA核心作刚体最小二乘叠合：排除对应局部窗口，并仅纳入15个模型中pLDDT均≥80的残基，得到DD 70个、KD 195个核心残基。局部RMSD对N、CA、C、O主链原子计算，不比较不同残基的全部侧链原子。

同组5个样本产生10个唯一两两比较；WT与突变体产生25个交叉比较。比较共享模型，彼此并非独立重复，未进行t检验或报告生物学n。结果为Å，中位数（范围）。

| 结构域拟合 | 比较组 | 局部主链RMSD Å | 比较数 |
|---|---|---:|---:|
{chr(10).join(pairrows)}

结果在改变叠合核心置信度阈值（不筛选、75、80、90）时维持同方向的中位数差异；Q29P在更严格且更小的核心下，分布范围存在一定重叠，不能宣称所有设置下完全分离。用Biopython SVDSuperimposer对两组rank0结果交叉核对，局部RMSD与主程序差值均<0.000003 Å。

## Q29P 局部构象

WT Q29的phi为+53.2至+60.5度。Q29P五个模型的phi均转为负值，但存在两类局部几何：rank0为phi=-49.5、psi=133.5度；rank1–4为phi约-88.9至-82.6、psi约8.3至17.3度。不能只保留rank1–4，也不能把最高排名rank0当作已经确立的唯一真实构象。
Pro29的N–CD闭环键长为1.463–1.486 Å，28–29肽键omega绝对值均>171度，未见该肽键cis构象。当前结果实现了允许主链改变的建模，比此前直接换侧链更适合这一位点；但没有运行完整MolProbity/Ramachandran概率评估，不能因此宣称整套模型已通过完整立体化学验证。
本分析不能从单体得出IRAK4–IRAK2结合减弱、特定界面氢键丢失或Myddosome解聚结论。

## D320Y 局部构象与接触

315–325位主链变化在本批次样本中较一致。以下距离定义为320位侧链重原子与对应残基侧链重原子之间的最短距离；同一对残基的最近原子种类可因替换而不同，不能将距离变化直接视为作用能变化。

| 对应残基 | WT Å | D320Y Å |
|---|---:|---:|
{distrows}

320位至M265最近侧链距离的分布有重叠，两组均可出现接近；D320Y的320–M265 CA–CA距离反而由WT中位数4.59增至4.79 Å。这更适合描述为侧链体积和局部堆积改变，不能称为证明了新生稳定相互作用。320位至T324的侧链距离增加，提示接触模式重排，但未计算氢键供受体角度或能量，不写成已证明氢键丢失。
局部接触CSV包含全蛋白的诊断性接触，并已逐行标注是否位于同一注释结构域；机制讨论仅使用结构域内接触。跨结构域及连接区接触因DD–KD相对位置高PAE而不作解释。

## 几何检查的边界

使用Amber残基共价拓扑排除相隔≤3条共价键的原子对，并对突变位点侧链进行重原子范德华重叠诊断。碳、氮、氧、硫半径分别为1.70、1.55、1.52、1.80 Å；>0.8 Å重叠作为本次严重碰撞筛查阈值。两位点均未发现超过该阈值的侧链重叠；这不是MolProbity clashscore。部分较小重叠涉及不确定的跨结构域接近，已保留原始结果而不解释为变异失稳。局部主链键长、CA手性符号、Pro闭环及肽键构象见独立CSV。

## 下一步建议

1. **先交叉核对已有Protenix结果。** 若WT、D320Y、Q29P的匹配设置结果已完成，直接分析现有全部样本；如尚未运行，先相同seed各一轮，再按收敛情况扩展多seed。跨模型一致性不等于独立实验验证，置信度分值也不宜跨模型直接排名。
2. **D320Y优先增加独立KD的WT/变异体对照。** 使用相同186–454片段、MSA/模板和采样策略，检查局部差异是否在去除不确定的DD–KD相对位置后仍出现。这比直接依据单体模型启动大型MD更适合作为当前低成本核验。
3. **Q29P重点补充WT/Q29P Myddosome DD复合物。** 14条链、1444 aa的6:4:4设计和片段已准备在next_step_sequences。先检查WT能否形成合理装配，再对突变界面做链拓扑映射及置信度检查。若整体装配不可靠，停止作界面能量或亲和力结论。必要时先用DD单体配对检查两类局部构象是否重复出现。
4. **经重复采样、跨模型及完整几何质控后定稿。** 目前支持“预测的局部重排”；不支持“稳定活性态”“GOF结构证明”或“已解释IL-6/IFN偏向”。ΔΔG或MD仅在有明确待检验问题、结构质量足够且计算方案一致时追加。

## Preliminary Methods wording

Full-length human IRAK4 WT, Q29P and D320Y sequences were modeled separately using the Chai-1 web server with MMseqs2-based multiple sequence alignments and structural templates enabled, without user-specified restraints. Each input contained one protein chain, and five ranked structures were analyzed per sequence. Per-residue pLDDT and predicted aligned error were extracted from the exported CIF and NumPy files. Death-domain (residues 20–104) and kinase-domain (residues 186–454) coordinates were aligned separately using common C-alpha cores, excluding the prespecified local windows (residues 24–34 and 315–325, respectively) and retaining core residues with pLDDT of at least 80 in all 15 models. Local backbone RMSDs were calculated over N, C-alpha, C and O atoms for all within-group and WT–variant model pairs. Backbone torsions, selected intradomain side-chain distances and local heavy-atom overlaps were examined. Comparisons were descriptive; ranked structures and model pairs were not treated as independent biological replicates. The exported results did not specify random seed identities or the precise model checkpoint.

这段仅描述已完成工作；正式投稿前应尽量补齐预测日期、服务器版本/任务记录及可获取的seed信息。未进行的MD、能量计算和界面预测不得写入已完成方法。

## 图注草稿

**Quantitative comparison.** Chai-1 predictions of full-length IRAK4 WT, Q29P and D320Y were analyzed using five ranked samples per sequence. (A) Mean and range of per-residue pLDDT. (B) PAE matrix for WT rank0, illustrating uncertain DD–KD relative placement. (C,E) Local backbone RMSDs after separate domain-core alignment; each point represents a model-pair comparison and black lines indicate medians. Comparisons share models and do not constitute independent replicates. (D) Residue29 phi/psi angles, including both sampled Q29P conformations. (F) Nearest side-chain heavy-atom distances from residue320 to M265, N267 and T324; each point represents one predicted model. Distances describe static geometry and do not establish interaction energies or kinase activation.

**Local structural views.** Original prediction coordinates were rigidly aligned by the corresponding domain cores. The Q29P panel displays WT rank0 together with Q29P ranks0 and1 to represent both observed local conformations. The D320Y panel displays WT and D320Y rank0; sampling consistency is documented in the quantitative panel. C-alpha traces provide local backbone context and selected residues are shown as sticks. No coordinate relaxation or new mutation modeling was performed.

## 文件与复现

- inputs：三组原始导出文件，未改变坐标或置信度。
- data：逐模型质量、输入序列审计、配对RMSD、逐残基位移、二面角、接触和几何结果；分析参数定义和摘要。
- aligned_structures：仅刚体变换的PDB，用于作图；精确测量基于原始CIF，非截断精度的PDB。
- figures：定量PNG/SVG、局部结构对比PNG和PyMOL面板。
- next_step_sequences：后续全长、结构域和复合物片段；均未提交预测。
- scripts：分析与作图脚本。

Re-run from this directory with a compatible Python environment:

```bash
python scripts/analyze_chai.py --inputs inputs
python scripts/check_robustness.py --inputs inputs
python scripts/plot_results.py
python scripts/render_local_structures.py
python scripts/package_analysis.py
```

package_analysis.py prepares prospective fragments using supplied reference_sequences. The provided next_step_sequences directory already contains all resulting FASTA files; these can be used without rerunning that packaging step. Analysis scripts do not require network access or a structure-prediction engine. See environment.json for the analysis environment, which is distinct from the unknown server inference environment.

## 方法学参考

- Chai-1官方仓库：https://github.com/chaidiscovery/chai-lab
- Cooray等2023，Frontiers in Immunology，doi:10.3389/fimmu.2023.1231749。
- IRAK4参考序列和结构域：UniProt Q9NWZ3。
- Myddosome结构背景：PDB 3MOP；其IRAK2工程化变异与天然序列须区分。
'''
(O/'IRAK4_Chai_run1_analysis.md').write_text(report)

env={'analysis_python':sys.version,'platform':platform.platform(),'analysis_date':'2026-10-24','inference_engine':'Chai-1 webserver, exact checkpoint and random seeds not supplied','versions':{}}
for pkg in ['numpy','biopython','matplotlib','openmm','pymol-open-source']:
 try:env['versions'][pkg]=importlib.metadata.version(pkg)
 except importlib.metadata.PackageNotFoundError:pass
(O/'environment.json').write_text(json.dumps(env,indent=2))
print('Report and prospective inputs prepared:',O)
