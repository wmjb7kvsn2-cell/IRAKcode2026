"""Descriptive analysis of uploaded Chai-1 monomer samples; no hypothesis tests.

Usage: python scripts/analyze_chai.py --inputs /path/to/extracted_inputs
No predictions, mutations, relaxation or coordinate optimization are performed.
"""
from pathlib import Path
import argparse, json, csv, hashlib, itertools, sys
import numpy as np
from Bio.PDB import MMCIFParser, PDBParser, PDBIO
from Bio.PDB.MMCIF2Dict import MMCIF2Dict
from Bio.SeqUtils import seq1
from Bio.PDB.vectors import calc_dihedral, Vector
from openmm.app import ForceField

OUT = Path(__file__).resolve().parents[1]
GROUPS = ['WT', 'Q29P', 'D320Y']
DOMAINS = {'DD': (20,104), 'KD': (186,454)}
TARGETS = {'DD': (24,34), 'KD': (315,325)}
BB = ('N','CA','C','O')
RADII = {'C':1.70, 'N':1.55, 'O':1.52, 'S':1.80}

def writecsv(name,rows):
    if not rows: return
    keys=list(dict.fromkeys(k for row in rows for k in row))
    with (OUT/'data'/name).open('w',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)

def atoms(model, ids, names=('CA',)):
    return np.array([model['res'][i][n].coord for i in ids for n in names],dtype=float)

def fit(mobile,reference):
    a=mobile.mean(0);b=reference.mean(0)
    u,s,vt=np.linalg.svd((mobile-a).T@(reference-b))
    z=np.eye(3);z[2,2]=np.linalg.det(u@vt)
    r=u@z@vt;t=b-a@r
    return r,t

def rmsd(x,y):return float(np.sqrt(np.mean(np.sum((x-y)**2,axis=1))))

def torsion(m,ids):
    return float(np.degrees(calc_dihedral(*[Vector(m['res'][i][a].coord) for i,a in ids])))

def sc(m,i):return [a for a in m['res'][i] if a.element!='H' and a.name not in BB+('OXT',)]

def mindist(a,b):
    if not a or not b:return float('nan'),'',''
    xyz=np.array([x.coord for x in a]);uvw=np.array([x.coord for x in b])
    ds=np.linalg.norm(xyz[:,None]-uvw[None,:],axis=2);i,j=np.unravel_index(ds.argmin(),ds.shape)
    return float(ds[i,j]),a[i].name,b[j].name

def stats(a):
    a=np.asarray(a,dtype=float)
    return {'median':float(np.median(a)),'min':float(a.min()),'max':float(a.max())}

def clash_audit(m,target,templates):
    aa=[a for r in m['res'].values() for a in r if a.element in RADII]
    key={(a.parent.id[1],a.name):k for k,a in enumerate(aa)}
    graph=[set() for _ in aa]
    def edge(x,y):
        if x in key and y in key:
            u,v=key[x],key[y];graph[u].add(v);graph[v].add(u)
    for i,res in m['res'].items():
        tpl=templates['HIE' if res.resname=='HIS' else res.resname]
        for u,v in tpl.bonds:edge((i,tpl.atoms[u].name),(i,tpl.atoms[v].name))
        if i+1 in m['res']:edge((i,'C'),(i+1,'N'))
    excluded={}
    for k in [key[(target,a.name)] for a in sc(m,target)]:
        seen={k};wave={k}
        for _ in range(3):
            wave={j for i in wave for j in graph[i]}-seen;seen|=wave
        excluded[k]=seen
    rows=[]
    for k,ex in excluded.items():
        a=aa[k]
        for j,b in enumerate(aa):
            if j in ex:continue
            d=float(np.linalg.norm(a.coord-b.coord));overlap=RADII[a.element]+RADII[b.element]-d
            lo,hi=DOMAINS['DD' if target==29 else 'KD']
            if overlap>0.4:rows.append({'group':m['group'],'rank':m['rank'],'target':target,'atom1':a.name,'res2':b.parent.id[1],'resname2':b.parent.resname,'atom2':b.name,'distance_A':d,'vdw_overlap_A':overlap,'within_target_domain':lo<=b.parent.id[1]<=hi})
    return rows

def main(inp):
    for p in ('data','figures','aligned_structures'):(OUT/p).mkdir(exist_ok=True)
    models=[];seqrows=[];confrows=[];manifest=[]
    parser=MMCIFParser(QUIET=True)
    for g in GROUPS:
        for rank in range(5):
            p=inp/g/f'pred.rank_{rank}.cif';s=parser.get_structure(g,str(p));chains=list(s[0])
            assert len(chains)==1 and chains[0].id=='A'
            res={r.id[1]:r for r in chains[0] if r.id[0]==' '}
            assert list(res)==list(range(1,461))
            sequence=''.join(seq1(r.resname) for r in res.values())
            d=MMCIF2Dict(str(p))
            conf={int(i):float(v) for i,v in zip(d['_ma_qa_metric_local.label_seq_id'],d['_ma_qa_metric_local.metric_value'])}
            # Chai's per-residue QA metric is explicitly labelled pLDDT in the CIF.
            assert len(conf)==460 and max(abs(conf[i]-res[i]['CA'].bfactor) for i in res)<0.01
            pae=np.load(inp/g/f'pae.rank_{rank}.npy',allow_pickle=False)
            assert pae.shape==(460,460) and np.isfinite(pae).all()
            score=json.loads((inp/g/f'scores.rank_{rank}.json').read_text())
            m={'group':g,'rank':rank,'res':res,'structure':s,'seq':sequence,'conf':conf,'pae':pae,'score':score,'path':p};models.append(m)
            for f in sorted((inp/g).iterdir()):
                if rank==0:manifest.append({'group':g,'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size})
            seqrows.append({'group':g,'rank':rank,'chain':'A','length':len(res),'residue29':sequence[28],'residue320':sequence[319]})
            row={'group':g,'rank':rank,**score,'pLDDT_all_mean':float(np.mean(list(conf.values()))),'pLDDT_29':conf[29],'pLDDT_320':conf[320]}
            for domain,(lo,hi) in DOMAINS.items():
                ids=np.arange(lo,hi+1)-1
                a=pae[np.ix_(ids,ids)];off=a[~np.eye(len(ids),dtype=bool)]
                row[f'pLDDT_{domain}_mean']=float(np.mean([conf[i+1] for i in ids]))
                row[f'PAE_{domain}_offdiag_median_A']=float(np.median(off))
                lo2,hi2=TARGETS[domain];row[f'pLDDT_{domain}_target_mean']=float(np.mean([conf[i] for i in range(lo2,hi2+1)]))
            d_ids=np.arange(20,105)-1;k_ids=np.arange(186,455)-1
            row['PAE_DD_KD_median_A']=float(np.median(np.r_[pae[np.ix_(d_ids,k_ids)].ravel(),pae[np.ix_(k_ids,d_ids)].ravel()]))
            confrows.append(row)
    wt=models[0]['seq']
    for m,row in zip(models,seqrows):
        dif=[f'{a}{i+1}{b}' for i,(a,b) in enumerate(zip(wt,m['seq'])) if a!=b]
        row['differences_vs_WT']=';'.join(dif)
        assert dif==({'WT':[],'Q29P':['Q29P'],'D320Y':['D320Y']}[m['group']])
    writecsv('sequence_audit.csv',seqrows);writecsv('model_quality.csv',confrows)
    writecsv('source_manifest.csv',manifest)

    cores={}
    for domain,(lo,hi) in DOMAINS.items():
        tlo,thi=TARGETS[domain]
        cores[domain]=[i for i in range(lo,hi+1) if not tlo<=i<=thi and all(m['conf'][i]>=80 for m in models)]
    (OUT/'data'/'alignment_definition.json').write_text(json.dumps({'annotated_domains':DOMAINS,'target_windows':TARGETS,'fit_atom':'CA','evaluation_atoms':list(BB),'core_min_pLDDT_in_all_15_models':80,'cores':cores,'sample_unit':'one uploaded job per genotype, five ranked samples; seed identities not supplied'},indent=2))
    pairrows=[]
    for a,b in itertools.combinations(models,2):
        label=f"{a['group']}-{b['group']}"
        for domain,core in cores.items():
            r,t=fit(atoms(b,core),atoms(a,core));lo,hi=TARGETS[domain];ids=list(range(lo,hi+1))
            row={'group_pair':label,'group1':a['group'],'rank1':a['rank'],'group2':b['group'],'rank2':b['rank'],'domain':domain,'core_n_res':len(core),'core_CA_RMSD_A':rmsd(atoms(b,core)@r+t,atoms(a,core)),'target_CA_RMSD_A':rmsd(atoms(b,ids)@r+t,atoms(a,ids)),'target_backbone_RMSD_A':rmsd(atoms(b,ids,BB)@r+t,atoms(a,ids,BB))}
            pairrows.append(row)
    writecsv('all_pairwise_comparisons.csv',pairrows)
    # Coordinates are rigidly transformed only; original models remain unchanged.
    displacement=[]
    ref=models[0]
    for domain,core in cores.items():
        for m in models:
            r,t=fit(atoms(m,core),atoms(ref,core))
            for i in range(1,461):
                delta=np.linalg.norm(m['res'][i]['CA'].coord@r+t-ref['res'][i]['CA'].coord)
                displacement.append({'group':m['group'],'rank':m['rank'],'domain_fit':domain,'residue':i,'CA_displacement_vs_WT_rank0_A':float(delta),'pLDDT':m['conf'][i]})
            import copy
            s=copy.deepcopy(m['structure'])
            for a in s.get_atoms():a.coord=a.coord@r+t
            io=PDBIO();io.set_structure(s);io.save(str(OUT/'aligned_structures'/f"{domain}_{m['group']}_rank{m['rank']}.pdb"))
    writecsv('aligned_per_residue.csv',displacement)

    tors=[];distrows=[];contactrows=[];clashrows=[]
    templates=ForceField('amber14-all.xml')._templates
    for m in models:
        for i in list(range(24,35))+list(range(315,326)):
            tors.append({'group':m['group'],'rank':m['rank'],'residue':i,'resname':m['res'][i].resname,'phi_deg':torsion(m,[(i-1,'C'),(i,'N'),(i,'CA'),(i,'C')]),'psi_deg':torsion(m,[(i,'N'),(i,'CA'),(i,'C'),(i+1,'N')]),'preceding_omega_deg':torsion(m,[(i-1,'CA'),(i-1,'C'),(i,'N'),(i,'CA')]),'preceding_CN_bond_A':float(np.linalg.norm(m['res'][i-1]['C'].coord-m['res'][i]['N'].coord))})
        for target in (29,320):
            clashrows.extend(clash_audit(m,target,templates))
            for i,res in m['res'].items():
                if abs(i-target)<=2:continue
                d,a,b=mindist(sc(m,target),[x for x in res if x.element!='H'])
                lo,hi=DOMAINS['DD' if target==29 else 'KD']
                if d<=4.5:contactrows.append({'group':m['group'],'rank':m['rank'],'target':target,'partner':i,'partner_resname':res.resname,'min_sidechain_to_partner_heavy_A':d,'target_atom':a,'partner_atom':b,'within_target_domain':lo<=i<=hi})
        for target,partners in ((320,(265,267,324)),(29,(27,28,30,31,32,62,65))):
            for j in partners:
                d,a,b=mindist(sc(m,target),sc(m,j))
                dh,ah,bh=mindist(sc(m,target),[x for x in m['res'][j] if x.element!='H'])
                distrows.append({'group':m['group'],'rank':m['rank'],'target':target,'partner':j,'target_resname':m['res'][target].resname,'partner_resname':m['res'][j].resname,'sidechain_sidechain_min_A':d,'target_sc_atom':a,'partner_sc_atom':b,'sidechain_partner_heavy_min_A':dh,'target_atom':ah,'partner_atom':bh,'CA_CA_A':float(np.linalg.norm(m['res'][target]['CA'].coord-m['res'][j]['CA'].coord))})
    writecsv('local_torsions.csv',tors);writecsv('selected_distances.csv',distrows);writecsv('local_contacts_4p5A.csv',contactrows);writecsv('local_vdw_overlaps.csv',clashrows)
    summary={'sequence_validation':'15/15 pass; 460 residues; single A chain; correct single variants','cores_n':{k:len(v) for k,v in cores.items()},'pairwise':{},'quality':{},'torsions':{},'distances':{}}
    for domain in cores:
        summary['pairwise'][domain]={}
        for label in sorted(set(p['group_pair'] for p in pairrows)):
            vals=[p['target_backbone_RMSD_A'] for p in pairrows if p['domain']==domain and p['group_pair']==label]
            summary['pairwise'][domain][label]={'n_pairs':len(vals),**stats(vals)}
    for g in GROUPS:
        summary['quality'][g]={k:stats([r[k] for r in confrows if r['group']==g]) for k in ('ptm','pLDDT_29','pLDDT_320','pLDDT_DD_mean','pLDDT_KD_mean','PAE_DD_offdiag_median_A','PAE_KD_offdiag_median_A','PAE_DD_KD_median_A')}
        summary['torsions'][g]={str(i):{k:stats([r[k] for r in tors if r['group']==g and r['residue']==i]) for k in ('phi_deg','psi_deg','preceding_omega_deg','preceding_CN_bond_A')} for i in (29,320)}
        summary['distances'][g]={str(j):{k:stats([r[k] for r in distrows if r['group']==g and r['target']==320 and r['partner']==j]) for k in ('sidechain_sidechain_min_A','CA_CA_A')} for j in (265,267,324)}
    summary['clash_audit']={'definition':'sidechain target to all heavy atoms; standard vdW radii; exclude atoms within 3 covalent bonds using Amber residue topology; diagnostic only, not MolProbity clashscore','rows_gt_0p4A':len(clashrows),'severe_gt_0p8A':len([r for r in clashrows if r['vdw_overlap_A']>0.8]),'max_overlap_A':max([r['vdw_overlap_A'] for r in clashrows] or [0])}
    (OUT/'data'/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,required=True);args=ap.parse_args();main(args.inputs)
