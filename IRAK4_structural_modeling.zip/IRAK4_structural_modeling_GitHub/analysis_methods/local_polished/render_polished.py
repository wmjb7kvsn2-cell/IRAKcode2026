"""Render exact, rigidly aligned Chai-1 coordinate comparisons.

Labels are composed separately. Landmark-only passes recover screen positions
from the same camera for accurate leaders and displacement annotations.
No mutation modeling, relaxation or local magnification is performed.
"""
from pathlib import Path
import json,csv,shutil
import numpy as np
from PIL import Image
from Bio.PDB import PDBParser,PDBIO
from pymol import cmd

O=Path(__file__).resolve().parents[1]
SOURCE=O/'source_data'
SOURCE.mkdir(exist_ok=True)
for filename in ['selected_distances.csv','local_torsions.csv','aligned_per_residue.csv']:
 if not (SOURCE/filename).exists():shutil.copy2(O.parent/'IRAK4_Chai_run1'/'data'/filename,SOURCE/filename)
A=O/'coordinates';R=O/'renders';S=O/'sessions'
for d in (A,R,S):d.mkdir(exist_ok=True)
W,H=2100,1540
COL={'wt':(0.16,.44,.65),'q0':(.88,.43,.20),'q1':(.13,.56,.48),'dy':(.64,.31,.57)}
parser=PDBParser(QUIET=True)
models={}
for name,file in [('qwt','DD_WT_rank0.pdb'),('q0','DD_Q29P_rank0.pdb'),('q1','DD_Q29P_rank1.pdb'),('dwt','KD_WT_rank0.pdb'),('dy','KD_D320Y_rank0.pdb')]:
 source=A/('aligned_'+file)
 if not source.exists():shutil.copy2(O.parent/'IRAK4_Chai_run1'/'aligned_structures'/file,source)
 models[name]=parser.get_structure(name,str(source))
def xyz(name,res,atom):return models[name][0]['A'][res][atom].coord.astype(float)
def unit(v):return v/np.linalg.norm(v)
qx=unit(xyz('q0',29,'CA')-xyz('qwt',29,'CA'))
qv=xyz('qwt',34,'CA')-xyz('qwt',24,'CA');qy=unit(qv-qx*np.dot(qv,qx));qz=np.cross(qx,qy)
dx=unit(xyz('dy',320,'OH')-xyz('dy',320,'CG'))
dv=xyz('dy',320,'CD1')-xyz('dy',320,'CD2');dy=unit(dv-dx*np.dot(dv,dx))
if np.dot(xyz('dy',265,'CA')-xyz('dy',320,'CA'),dy)<0:dy=-dy
dz=np.cross(dx,dy)
bases={'Q':np.array([qx,qy,qz]),'D':np.array([dx,dy,dz])}
for name,st in models.items():
 b=bases['Q' if name.startswith('q') else 'D']
 assert abs(np.linalg.det(b)-1)<1e-5
 for a in st.get_atoms():a.coord=a.coord@b.T
 io=PDBIO();io.set_structure(st);io.save(str(A/(name+'_view.pdb')))

def base():
 cmd.reinitialize();cmd.viewport(W,H);cmd.bg_color('white')
 for k,v in [('orthoscopic',1),('ray_shadows',0),('antialias',2),('specular',.15),('ray_opaque_background',1),('cartoon_fancy_helices',1),('cartoon_smooth_loops',1),('cartoon_sampling',24),('cartoon_tube_radius',.17),('stick_radius',.15),('sphere_scale',.14),('depth_cue',0),('ray_trace_fog',0)]:cmd.set(k,v)
 for n,c in COL.items():cmd.set_color(n,c)
 cmd.set_color('context',(.79,.82,.85));cmd.set_color('neighbor',(.49,.54,.59));cmd.set_color('neighbor_light',(.69,.72,.75));cmd.set_color('nitrogen',(.15,.26,.64));cmd.set_color('oxygen',(.83,.19,.22));cmd.set_color('sulfur',(.84,.64,.12))
def load(name,region):
 cmd.load(str(A/(name+'_view.pdb')),name);cmd.remove(f'{name} and not ({region})');cmd.hide('everything',name);cmd.dss(name)
def context(obj,exclude):
 cmd.show('cartoon',obj);cmd.color('context',obj);cmd.set('cartoon_transparency',.35,obj)
 cmd.hide('cartoon',f'{obj} and ({exclude})')
def local(obj,res,color):
 sel=f'{obj} and resi {res}';cmd.show('cartoon',sel);cmd.cartoon('tube',sel);cmd.color(color,sel);cmd.set('cartoon_transparency',0,sel)
def sticks(obj,res,color,balls=False):
 sel=f'{obj} and resi {res}';cmd.show('sticks',sel);cmd.color(color,sel+' and elem C');cmd.color('nitrogen',sel+' and elem N');cmd.color('oxygen',sel+' and elem O');cmd.color('sulfur',sel+' and elem S')
 if balls:cmd.show('spheres',sel)
def point(obj,res,atom):return np.array(cmd.get_atom_coords(f'{obj} and resi {res} and name {atom}'))
def avg(obj,res,atoms):return np.mean([point(obj,res,a) for a in atoms],axis=0)
def render(name,anchors):
 cmd.png(str(R/(name+'.png')),width=W,height=H,dpi=300,ray=1)
 cmd.save(str(S/(name+'.pse')))
 view=cmd.get_view()
 # Single marker at a time avoids occlusion bias in close correspondence pairs.
 cmd.hide('everything','all');cmd.set('ambient',1);cmd.set('direct',0);cmd.set('specular',0)
 points={}
 for key,p in anchors.items():
  cmd.pseudoatom('_landmark',pos=list(map(float,p)),vdw=.075);cmd.color('red','_landmark');cmd.show('spheres','_landmark');cmd.set('sphere_scale',1,'_landmark');cmd.set_view(view)
  path=R/(name+'_'+key+'_landmark.png');cmd.png(str(path),width=W//2,height=H//2,ray=1)
  arr=np.array(Image.open(path).convert('RGB'));mask=(arr[:,:,0]>120)&(arr[:,:,1]<120)&(arr[:,:,2]<120)
  yy,xx=np.where(mask)
  if len(xx)<2:raise RuntimeError('Landmark missing: '+name+' '+key)
  points[key]=[float(xx.mean()/(W//2)),float(1-yy.mean()/(H//2))]
  cmd.delete('_landmark');path.unlink()
 return {'anchors':points,'camera':list(view)}

meta={'coordinate_provenance':'Existing domain-aligned rank models; subsequent transforms are common rigid rotations only. Measurement labels use original-CIF analysis tables.','view_basis':{k:v.tolist() for k,v in bases.items()},'panels':{}}

# A common camera for both Q29P conformations.
base()
for n in ('qwt','q0','q1'):load(n,'resi 18-48')
cmd.zoom('(all and resi 26-32 and name CA) or (all and resi 29)',3.2);qview=cmd.get_view()
for panel,mut,col in [('Q_rank0','q0','q0'),('Q_rank1','q1','q1')]:
 base();load('qwt','resi 18-48');load(mut,'resi 18-48')
 context('qwt','resi 24-34');local('qwt','24-34','wt');local(mut,'24-34',col)
 sticks('qwt','29','wt',True);sticks(mut,'29',col,True)
 for obj,c in [('qwt','wt'),(mut,col)]:
  cmd.show('spheres',f'{obj} and resi 29 and name CA');cmd.set('sphere_scale',.22,f'{obj} and resi 29 and name CA');cmd.color(c,f'{obj} and resi 29 and name CA')
 cmd.set_view(qview)
 anchors={'wt_site':avg('qwt',29,['CG','CD','OE1','NE2']),'mut_site':avg(mut,29,['CB','CG','CD']),'wt_CA':point('qwt',29,'CA'),'mut_CA':point(mut,29,'CA'),'P28':point('qwt',28,'CA'),'E30':point('qwt',30,'CA')}
 meta['panels'][panel]=render(panel,anchors)

# Common camera and scale for WT, D320Y and overlay.
base()
for n in ('dwt','dy'):load(n,'resi 255-275+307-331')
cmd.zoom('all and resi 265+320+324',4.0);dview=cmd.get_view()
distrows=list(csv.DictReader((SOURCE/'selected_distances.csv').open()))
for panel,visible in [('D_WT',['dwt']),('D_mut',['dy']),('D_overlay',['dwt','dy'])]:
 base()
 for n in visible:load(n,'resi 255-275+307-331')
 context(visible[0],'resi 315-325')
 for n in visible:
  c='wt' if n=='dwt' else 'dy';local(n,'315-325',c);sticks(n,'320',c,True)
  sticks(n,'265+324','neighbor' if n==visible[0] else 'neighbor_light')
  cmd.show('spheres',f'{n} and resi 320 and name CA');cmd.set('sphere_scale',.22,f'{n} and resi 320 and name CA');cmd.color(c,f'{n} and resi 320 and name CA')
 anchors={}
 for n in visible:
  anchors[n+'_site']=avg(n,320,['CG','OD1','OD2'] if n=='dwt' else ['CG','CD1','CD2','CE1','CE2','CZ'])
  anchors[n+'_CA']=point(n,320,'CA')
 anchors['M265']=point(visible[0],265,'SD');anchors['T324']=point(visible[0],324,'OG1')
 if len(visible)==1:
  g='WT' if visible[0]=='dwt' else 'D320Y';n=visible[0]
  for partner in (265,324):
   row=next(r for r in distrows if r['group']==g and r['rank']=='0' and r['target']=='320' and r['partner']==str(partner))
   s1=f'{n} and resi 320 and name '+row['target_sc_atom'];s2=f'{n} and resi {partner} and name '+row['partner_sc_atom']
   cmd.distance('distance_'+str(partner),s1,s2);cmd.hide('labels','distance_'+str(partner));cmd.set('dash_color','grey40','distance_'+str(partner));cmd.set('dash_width',2,'distance_'+str(partner));cmd.set('dash_gap',.2,'distance_'+str(partner));cmd.set('dash_length',.14,'distance_'+str(partner))
   anchors['distance_'+str(partner)]=(point(n,320,row['target_sc_atom'])+point(n,partner,row['partner_sc_atom']))/2
 cmd.set_view(dview);meta['panels'][panel]=render(panel,anchors)

# Original-CIF derived statistics, not rounded-PDB measurements.
tors=list(csv.DictReader((SOURCE/'local_torsions.csv').open()))
disp=list(csv.DictReader((SOURCE/'aligned_per_residue.csv').open()))
meta['Q29_torsions']={g+'_'+str(rank):next(r for r in tors if r['group']==g and int(r['rank'])==rank and r['residue']=='29') for g,rank in [('WT',0),('Q29P',0),('Q29P',1)]}
meta['site_displacements']={}
for g,rank,dom,pos in [('Q29P',0,'DD',29),('Q29P',1,'DD',29),('D320Y',0,'KD',320)]:
 row=next(r for r in disp if r['group']==g and int(r['rank'])==rank and r['domain_fit']==dom and int(r['residue'])==pos)
 meta['site_displacements'][g+'_'+str(rank)]=float(row['CA_displacement_vs_WT_rank0_A'])
meta['D320_distances']={g+'_'+str(p):next(r for r in distrows if r['group']==g and r['rank']=='0' and r['target']=='320' and r['partner']==str(p)) for g in ['WT','D320Y'] for p in [265,324]}
(O/'figure_metadata.json').write_text(json.dumps(meta,indent=2))
print('Five coordinate views and annotation landmarks rendered:',O)
cmd.quit()
