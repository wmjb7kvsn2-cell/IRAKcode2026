"""Publication-style labels on coordinate renderings; annotations remain vector."""
from pathlib import Path
import json
import io,os
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from matplotlib.lines import Line2D
import numpy as np

O=Path(__file__).resolve().parents[1]
M=json.loads((O/'figure_metadata.json').read_text())
WT='#286FA6';Q0='#E07033';Q1='#218F7A';DY='#A34F91';INK='#243646';GRAY='#6A7681'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'svg.fonttype':'none','figure.facecolor':'white'})

def load(ax,name):
 ax.imshow(plt.imread(O/'renders'/(name+'.png')));ax.axis('off')
 return M['panels'][name]['anchors']
def callout(ax,text,point,label,color=INK,ha='left',size=10):
 ax.annotate(text,xy=point,xycoords='axes fraction',xytext=label,textcoords='axes fraction',ha=ha,va='center',fontsize=size,color=color,fontweight='medium',bbox={'boxstyle':'round,pad=.25','fc':'white','ec':'none','alpha':.96},arrowprops={'arrowstyle':'-','lw':1.05,'color':color,'shrinkA':3,'shrinkB':3,'connectionstyle':'arc3,rad=0'})
def position_offset(ax,p1,p2,text,label):
 mid=np.mean([p1,p2],axis=0)
 ax.annotate('',xy=p2,xycoords='axes fraction',xytext=p1,textcoords='axes fraction',arrowprops={'arrowstyle':'<->','lw':1.2,'color':'#29333C','mutation_scale':8,'shrinkA':0,'shrinkB':0})
 callout(ax,text,mid,label,INK,ha='center',size=9)
def heading(ax,letter,title,subtitle):
 ax.text(.005,1.035,letter,transform=ax.transAxes,fontsize=15,fontweight='bold',color=INK,va='bottom')
 ax.text(.085,1.043,title,transform=ax.transAxes,fontsize=12,fontweight='bold',color=INK,va='bottom')
 ax.text(.085,1.005,subtitle,transform=ax.transAxes,fontsize=9,color=GRAY,va='bottom')
def qpanel(ax,rank,letter):
 name='Q_rank'+str(rank);p=load(ax,name);col=Q0 if rank==0 else Q1
 heading(ax,letter,f'WT / Q29P rank {rank}','Matched death-domain alignment; identical view and scale')
 callout(ax,'Q29 · WT',p['wt_site'],(.07,.64),WT,size=11)
 callout(ax,f'P29 · rank {rank}',p['mut_site'],(.94,.63),col,ha='right',size=11)
 position_offset(ax,p['wt_CA'],p['mut_CA'],f"Cα29 position difference\n{M['site_displacements']['Q29P_'+str(rank)]:.2f} Å (3D)",(.77,.22))
 # A focus marker, not a probability or confidence ellipse.
 center=np.mean([p['wt_CA'],p['mut_CA']],axis=0)
 ax.add_patch(Ellipse(center,width=.17,height=.20,transform=ax.transAxes,fill=False,ec='#9AA6AE',lw=.9,ls=(0,(3,3)),zorder=2))
 if rank==0:
  callout(ax,'P28',p['P28'],(.12,.22),GRAY,size=9)
  callout(ax,'E30',p['E30'],(.84,.85),GRAY,size=9)
 t=M['Q29_torsions'];a=t['WT_0'];b=t['Q29P_'+str(rank)]
 ax.text(.02,-.055,f"WT Q29   φ {float(a['phi_deg']):+.1f}°   ψ {float(a['psi_deg']):+.1f}°",transform=ax.transAxes,color=WT,fontsize=10,va='top')
 ax.text(.02,-.115,f"Q29P P29   φ {float(b['phi_deg']):+.1f}°   ψ {float(b['psi_deg']):+.1f}°",transform=ax.transAxes,color=col,fontsize=10,va='top')

def dpanel(ax,kind,letter):
 p=load(ax,'D_'+kind)
 title={'WT':'WT · rank 0','mut':'D320Y · rank 0','overlay':'WT / D320Y overlay'}[kind]
 heading(ax,letter,title,'Matched kinase-domain alignment; identical view and scale')
 callout(ax,'M265',p['M265'],(.90,.84),GRAY,ha='right',size=10)
 callout(ax,'T324',p['T324'],(.10,.13),GRAY,size=10)
 if kind=='overlay':
  callout(ax,'D320 · WT',p['dwt_site'],(.06,.36),WT,size=10)
  callout(ax,'Y320 · D320Y',p['dy_site'],(.97,.48),DY,ha='right',size=10)
  position_offset(ax,p['dwt_CA'],p['dy_CA'],f"Cα320 position difference\n{M['site_displacements']['D320Y_0']:.2f} Å (3D)",(.18,.75))
  ax.text(.02,-.065,'Asp → Tyr: side-chain size and local packing',transform=ax.transAxes,color=INK,fontsize=9,va='top')
  ax.text(.02,-.12,'Geometric differences; no interaction-energy inference',transform=ax.transAxes,color=GRAY,fontsize=8,va='top')
 else:
  group='WT' if kind=='WT' else 'D320Y';obj='dwt' if kind=='WT' else 'dy';col=WT if kind=='WT' else DY
  callout(ax,'D320 · Asp' if kind=='WT' else 'Y320 · Tyr',p[obj+'_site'],(.97,.43 if kind=='WT' else .48),col,ha='right',size=11)
  for partner,label in [(265,(.77,.67)),(324,(.78,.16))]:
   row=M['D320_distances'][group+'_'+str(partner)]
   callout(ax,f"{float(row['sidechain_sidechain_min_A']):.2f} Å",p['distance_'+str(partner)],label,INK,ha='center',size=10)
  r1=M['D320_distances'][group+'_265'];r2=M['D320_distances'][group+'_324']
  ax.text(.02,-.065,f"M265: {r1['target_sc_atom']}–{r1['partner_sc_atom']}   |   T324: {r2['target_sc_atom']}–{r2['partner_sc_atom']}",transform=ax.transAxes,color=GRAY,fontsize=8.5,va='top')
  ax.text(.02,-.12,'Dashed lines: nearest side-chain heavy-atom distances',transform=ax.transAxes,color=GRAY,fontsize=8,va='top')

def save(fig,name):
 buf=io.BytesIO();fig.savefig(buf,format='png',dpi=300,facecolor='white')
 data=buf.getvalue();Image.open(io.BytesIO(data)).verify()
 temp=O/(name+'.writing.png');temp.write_bytes(data);os.replace(temp,O/(name+'.png'))
 fig.savefig(O/(name+'.svg'),facecolor='white')
 plt.close(fig)

fig=plt.figure(figsize=(14,12.7))
fig.text(.04,.975,'IRAK4  |  Predicted local conformational differences',fontsize=19,fontweight='bold',color=INK,va='top')
fig.text(.04,.936,'Q29P',fontsize=13,fontweight='bold',color=INK);fig.text(.112,.936,'Backbone reorientation with two sampled conformations',fontsize=11,color=GRAY)
for rank,x,letter in [(0,.035,'A'),(1,.53,'B')]:qpanel(fig.add_axes([x,.56,.435,.34]),rank,letter)
fig.text(.04,.456,'D320Y',fontsize=13,fontweight='bold',color=INK);fig.text(.122,.456,'Side-chain replacement and local packing',fontsize=11,color=GRAY)
for x,kind,letter in [(.025,'WT','C'),(.353,'mut','D'),(.681,'overlay','E')]:dpanel(fig.add_axes([x,.135,.294,.265]),kind,letter)
fig.text(.04,.040,'Chai-1 monomers. Labels report the displayed ranked models, not five-sample medians. No coordinate deformation was applied.',fontsize=9,color=GRAY)
fig.text(.04,.020,'Arrows connect corresponding predicted Cα positions; they are not motion trajectories. Dashed lines do not assign hydrogen bonds.',fontsize=9,color=GRAY)
save(fig,'IRAK4_Chai_local_structures')

fig=plt.figure(figsize=(14,6.8))
fig.text(.04,.965,'Q29P  |  Predicted local backbone reorientation',fontsize=18,fontweight='bold',color=INK,va='top')
for rank,x,letter in [(0,.035,'A'),(1,.53,'B')]:qpanel(fig.add_axes([x,.18,.435,.65]),rank,letter)
fig.text(.04,.025,'Both Q29P rank 0 and rank 1 are shown to retain local conformational heterogeneity. Values refer to the displayed models.',fontsize=9,color=GRAY)
save(fig,'IRAK4_Q29P_local_polished')

fig=plt.figure(figsize=(14,5.7))
fig.text(.04,.965,'D320Y  |  Predicted local side-chain packing',fontsize=18,fontweight='bold',color=INK,va='top')
for x,kind,letter in [(.025,'WT','A'),(.353,'mut','B'),(.681,'overlay','C')]:dpanel(fig.add_axes([x,.19,.294,.62]),kind,letter)
fig.text(.04,.025,'WT and D320Y rank 0. Distances describe static geometry; they do not establish hydrogen bonds, binding energy or kinase activation.',fontsize=9,color=GRAY)
save(fig,'IRAK4_D320Y_local_polished')
print('Combined and individual PNG/SVG figures written:',O)
