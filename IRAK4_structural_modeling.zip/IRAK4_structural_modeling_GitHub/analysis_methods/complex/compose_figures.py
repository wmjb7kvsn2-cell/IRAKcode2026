"""Compose publication-style scientific figures from coordinate renderings/data.

PNG files are validated in memory and written atomically. SVGs contain embedded
raster structure renderings plus vector labels, axes and quantitative panels.
"""
from pathlib import Path
import csv,json,io,os
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch,Ellipse
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap
from PIL import Image

ROOT=Path(__file__).resolve().parents[1];F=ROOT/'figures';F.mkdir(exist_ok=True)
M=json.loads((ROOT/'figure_metadata.json').read_text())
BLUE='#286FA6';ORANGE='#E07038';GRAY='#6B7785';RED='#B94146';TEXT='#233348'
COMP={'MyD88':'#3D7DA6','IRAK4':'#DBA64A','IRAK2':'#786EAD'}
PAE=LinearSegmentedColormap.from_list('PAE',['#245D8C','#63A4B0','#D9E8DC','#F3D09A','#C86154'])
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelcolor':TEXT,'text.color':TEXT,'xtick.color':TEXT,'ytick.color':TEXT,'axes.edgecolor':'#A5AFBA','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.8,'svg.fonttype':'none'})

def read(name):return list(csv.DictReader((ROOT/'data'/name).open()))
QUALITY=read('model_quality.csv');REF=read('reference_comparison.csv');PAIR=read('chain_pair_metrics.csv');LOCAL=read('local_Q29_geometry.csv')

def title(fig,title,sub):
    fig.text(.035,.965,title,fontsize=19,fontweight='bold',va='top')
    fig.text(.035,.924,sub,fontsize=10.2,color=GRAY,va='top')

def panel(fig,box,letter,label):
    x,y,w,h=box;fig.text(x,y+h+.014,letter,fontsize=16,fontweight='bold');fig.text(x+.024,y+h+.016,label,fontsize=11,fontweight='bold')

def imagepanel(fig,name,box):
    ax=fig.add_axes(box);ax.imshow(Image.open(ROOT/'renders'/f'{name}.png'));ax.set_axis_off();return ax

def anchor(ax,name,key):return M['panels'][name]['anchors'][key]
def leader(ax,xy,text,at,color=TEXT,size=10):
    ax.annotate(text,xy=xy,xycoords='axes fraction',xytext=at,textcoords='axes fraction',fontsize=size,color=color,ha='left',va='center',arrowprops={'arrowstyle':'-','color':color,'linewidth':1.1,'connectionstyle':'angle3,angleA=0,angleB=90'},bbox={'boxstyle':'round,pad=.25','facecolor':'white','edgecolor':'none','alpha':.92})

def save(fig,name):
    for fmt in ['png','svg']:
        b=io.BytesIO();fig.savefig(b,format=fmt,dpi=300,facecolor='white')
        data=b.getvalue()
        if fmt=='png':Image.open(io.BytesIO(data)).verify()
        temp=F/(name+'.'+fmt+'.tmp');temp.write_bytes(data);os.replace(temp,F/(name+'.'+fmt))
    plt.close(fig);print('COMPOSED',name,flush=True)

def dots(ax,rows,field,nested=False,ylim=None,ylabel='',refline=None):
    for k,g in enumerate(['WT','Q29P']):
        color=[BLUE,ORANGE][k];rr=[r for r in rows if r['group']==g]
        med=[]
        for rank in range(5):
            vals=[float(r[field]) for r in rr if int(r['rank'])==rank]
            x=k+(rank-2)*.07
            if nested:
                xx=x+np.linspace(-.018,.018,len(vals));ax.scatter(xx,vals,s=17,color=color,alpha=.40,zorder=2,linewidths=0)
                value=float(np.median(vals));ax.scatter([x],[value],s=37,marker='D',color=color,edgecolors='white',linewidths=.5,zorder=3)
            else:
                value=vals[0];ax.scatter([x],[value],s=50,color=color,edgecolors='white',linewidths=.7,zorder=3)
                q=next(v for v in QUALITY if v['group']==g and int(v['rank'])==rank)
                if q['chai_clash_flag']=='True':ax.scatter([x],[value],marker='x',s=26,color='#3A2737',linewidths=1.1,zorder=4)
            med.append(value)
        ax.plot([k-.23,k+.23],[np.median(med)]*2,color=color,lw=2)
    if refline is not None:ax.axhline(refline,color=GRAY,lw=1,ls='--')
    ax.set_xlim(-.45,1.45);ax.set_xticks([0,1],['WT','Q29P']);ax.set_ylabel(ylabel);ax.grid(axis='y',color='#E6EAEE',lw=.7);ax.set_axisbelow(True)
    if ylim:ax.set_ylim(ylim)

def assembly():
    fig=plt.figure(figsize=(15,12.5));title(fig,'Myddosome DD assemblies: reference and Chai-1 candidates','Actual coordinates; representative rank 0 models. Common camera and scale within each view.')
    fig.legend(handles=[Patch(color=v,label=k) for k,v in COMP.items()]+[Line2D([],[],marker='o',color='none',markerfacecolor='#CC2933',label='IRAK4 Q29 / P29',markersize=7)],loc='upper left',bbox_to_anchor=(.035,.902),ncol=4,frameon=False,fontsize=10)
    labels=[('3MOP','Experimental reference, 3MOP'),('WT0','WT, rank 0'),('Q29P0','Q29P, rank 0')]
    for col,(n,label) in enumerate(labels):
        x=.035+col*.322
        for row,(side,y) in enumerate([('side',.477),('top',.092)]):
            box=[x,y,.292,.35];panel(fig,box,chr(65+row*3+col),label if row==0 else ['Reference: axial view','WT: axial view','Q29P: axial view'][col])
            name=n+'_'+side;ax=imagepanel(fig,name,box)
            if n=='Q29P0' and side=='side':
                for key in ['overlap_BE','overlap_CD']:
                    xy=anchor(ax,name,key);ax.add_patch(Ellipse(xy,.125,.115,fill=False,lw=1.4,ls='--',edgecolor=RED,transform=ax.transAxes))
                leader(ax,anchor(ax,name,'overlap_BE'),'Overlapping\nMyD88 copies',(.03,.12),RED,9)
    fig.text(.035,.045,'Red spheres mark the four IRAK4 29 sites. Dashed outlines mark spatially overlapping MyD88 copies, an unphysical prediction artifact.',fontsize=9.2)
    fig.text(.035,.024,'IRAK2 residues 95–112 are thin gray traces (unresolved in 3MOP). The reference contains IRAK2 R50W; both prediction groups contain native R50.',fontsize=9.1,color=GRAY)
    save(fig,'Fig1_Myddosome_assembly_comparison')

def block_pae(g,rank=0):
    arr=np.zeros((14,14));chain=read('chain_quality.csv')
    for row in chain:
        if row['group']==g and int(row['rank'])==rank:
            i=ord(row['chain'])-65;arr[i,i]=float(row['intra_PAE_median_A'])
    for row in PAIR:
        if row['group']==g and int(row['rank'])==rank:
            i,j=ord(row['chain1'])-65,ord(row['chain2'])-65;arr[i,j]=arr[j,i]=float(row['pair_PAE_median_A'])
    return arr

def confidence():
    fig=plt.figure(figsize=(15,10.8));title(fig,'Assembly diagnostics and sampling uncertainty','One submitted job per genotype, five ranked candidates. Crosses mark the original Chai interchain-clash flag.')
    boxes=[[.065,.65,.245,.215],[.39,.65,.245,.215],[.715,.65,.245,.215]]
    labels=[('A','Interface confidence (ipTM)'),('B','Deviation from 3MOP'),('C','Reference-contact retention')]
    for box,(letter,label) in zip(boxes,labels):panel(fig,box,letter,label)
    dots(fig.add_axes(boxes[0]),QUALITY,'ipTM',ylim=(.36,.445),ylabel='ipTM')
    dots(fig.add_axes(boxes[1]),REF,'reference_core_CA_RMSD_A',ylim=(5.8,12.7),ylabel='Core Cα RMSD (Å)')
    dots(fig.add_axes(boxes[2]),REF,'reference_contact_recall',ylim=(.43,.69),ylabel='Fraction of 3MOP contacts retained')
    im=None
    for g,box,letter in [('WT',[.055,.15,.285,.36],'D'),('Q29P',[.365,.15,.285,.36],'E')]:
        panel(fig,box,letter,g+' rank 0: median PAE by chain pair');ax=fig.add_axes(box)
        im=ax.imshow(block_pae(g),vmin=0,vmax=30,cmap=PAE,interpolation='nearest');ax.set_xticks(range(14),list('ABCDEFGHIJKLMN'),fontsize=8);ax.set_yticks(range(14),list('ABCDEFGHIJKLMN'),fontsize=8)
        for q in [5.5,9.5]:ax.axhline(q,color='white',lw=1.4);ax.axvline(q,color='white',lw=1.4)
        ax.set_xlabel('Original Chai chain ID',fontsize=9)
    cax=fig.add_axes([.09,.087,.53,.017]);fig.colorbar(im,cax=cax,orientation='horizontal',label='Predicted aligned error (Å); lower values indicate greater positional confidence')
    box=[.72,.16,.24,.345];panel(fig,box,'F','Ensemble structural spread');ax=fig.add_axes(box);pairs=read('ensemble_pairwise_RMSD.csv')
    for k,(a,b,label) in enumerate([('WT','WT','WT–WT'),('WT','Q29P','WT–Q29P'),('Q29P','Q29P','Q29P–Q29P')]):
        vals=[float(r['core_CA_RMSD_A']) for r in pairs if r['group1']==a and r['group2']==b]
        jitter=np.linspace(-.15,.15,len(vals));ax.scatter(k+jitter,vals,s=24,color=[BLUE,GRAY,ORANGE][k],alpha=.7);ax.plot([k-.22,k+.22],[np.median(vals)]*2,color=TEXT,lw=2)
    ax.set_xticks(range(3),['WT–WT','WT–Q29P','Q29P–Q29P'],rotation=20,ha='right',fontsize=9);ax.set_ylabel('Best copy-matched core Cα RMSD (Å)');ax.set_ylim(0,12);ax.grid(axis='y',color='#E6EAEE');ax.set_axisbelow(True)
    fig.text(.035,.035,'All fits enumerate 6! × 4! × 4! species-matched chain permutations. Reference-contact comparisons use common observed residues and exclude IRAK2 residue 50.',fontsize=9)
    fig.text(.035,.015,'Pairwise comparisons share models (10 within WT, 25 between groups, 10 within Q29P); they are descriptive and are not independent repeats.',fontsize=9,color=GRAY)
    save(fig,'Fig2_Myddosome_confidence_and_variability')

def sterics():
    fig=plt.figure(figsize=(14,10));title(fig,'Steric artifacts: overlapping MyD88 copies','The same failure mode occurs in WT candidates and in every Q29P candidate; it is not direct evidence of a mutation-induced assembly defect.')
    for g,rank,box,letter in [('WT',3,[.035,.46,.445,.37],'A'),('Q29P',0,[.525,.46,.445,.37],'B')]:
        panel(fig,box,letter,f'{g} rank {rank}: MyD88 B / E');name='overlap_'+g+str(rank);ax=imagepanel(fig,name,box)
        rr=next(r for r in PAIR if r['group']==g and int(r['rank'])==rank and r['chain1']=='B' and r['chain2']=='E')
        label=f"{int(rr['heavy_atom_pairs_lt1p5A'])} heavy-atom pairs < 1.5 Å"
        leader(ax,anchor(ax,name,'copy1'),label,(.03,.13),RED,10)
    fig.legend(handles=[Patch(color='#805CA8',label='MyD88 B'),Patch(color='#29A58A',label='MyD88 E')],loc='upper center',bbox_to_anchor=(.5,.457),ncol=2,frameon=False)
    box=[.065,.13,.56,.235];panel(fig,box,'C','Interchain heavy-atom proximity across all candidates');ax=fig.add_axes(box)
    values=[]
    for g in ['WT','Q29P']:
        for rank in range(5):values.append(sum(int(r['heavy_atom_pairs_lt1p5A']) for r in PAIR if r['group']==g and int(r['rank'])==rank))
    xx=np.r_[np.arange(5),np.arange(5)+6];ax.bar(xx,values,color=[BLUE]*5+[ORANGE]*5,width=.65)
    for x,v in zip(xx,values):ax.text(x,v+22,str(v),ha='center',fontsize=8.5)
    ax.set_xticks(xx,[str(i) for i in range(5)]*2);ax.set_xlabel('WT ranks 0–4                         Q29P ranks 0–4');ax.set_ylabel('Atom pairs separated by < 1.5 Å');ax.set_ylim(0,max(values)*1.2);ax.grid(axis='y',color='#E6EAEE');ax.set_axisbelow(True)
    box=[.735,.13,.23,.235];panel(fig,box,'D','Closest pair of MyD88 copies');ax=fig.add_axes(box)
    rows=read('MyD88_spatial_overlap.csv');mins=[]
    for g in ['WT','Q29P']:
        for rank in range(5):mins.append(dict(group=g,rank=str(rank),same_frame=min(float(r['CA_RMSD_same_frame_A']) for r in rows if r['group']==g and int(r['rank'])==rank)))
    dots(ax,mins,'same_frame',ylabel='Same-frame core Cα RMSD (Å)');ax.set_ylim(bottom=0)
    fig.text(.035,.053,'A–B: the two MyD88 chains retain their predicted positions; they have not been fitted to each other. Colors distinguish overlapping copies.',fontsize=9.1)
    fig.text(.035,.029,'The 1.5 Å count is an independent geometric diagnostic, not a MolProbity clashscore or the internal Chai clash criterion. Original Chai chain IDs are shown.',fontsize=9,color=GRAY)
    save(fig,'Fig3_Myddosome_steric_artifacts')

def local():
    fig=plt.figure(figsize=(14,10.6));title(fig,'Consistent local backbone differences predicted near IRAK4 Q29/P29','IRAK4 residues 24–34, aligned on a shared 51-residue high-confidence core outside this window. All residue labels use full-length numbering.')
    box=[.03,.45,.53,.405];panel(fig,box,'A','Local-chain medoid overlay');name='local_overlay';ax=imagepanel(fig,name,box)
    leader(ax,anchor(ax,name,'WT_CA'),'WT Q29',(.06,.79),BLUE,11);leader(ax,anchor(ax,name,'Q29P_CA'),'Q29P P29',(.67,.18),ORANGE,11)
    p=anchor(ax,name,'WT_CA');q=anchor(ax,name,'Q29P_CA');ax.annotate('',xy=q,xytext=p,xycoords='axes fraction',textcoords='axes fraction',arrowprops={'arrowstyle':'<->','color':TEXT,'lw':1.1})
    value=json.loads((ROOT/'data/local_medoid_annotation.json').read_text())['CA29_offset_A']
    ax.text(.04,.09,f'Cα29 correspondence offset: {value:.2f} Å',transform=ax.transAxes,fontsize=10,color=TEXT,bbox={'boxstyle':'round,pad=.3','facecolor':'#F1F4F7','edgecolor':'none'})
    box=[.65,.51,.315,.31];panel(fig,box,'B','Backbone dihedral angles at residue 29');ax=fig.add_axes(box)
    for g,color in [('WT',BLUE),('Q29P',ORANGE)]:
        rr=[r for r in LOCAL if r['group']==g];ax.scatter([float(r['phi_29_deg']) for r in rr],[float(r['psi_29_deg']) for r in rr],color=color,s=29,alpha=.65,label=g)
        for rank in range(5):
            sub=[r for r in rr if int(r['rank'])==rank];ax.scatter([np.median([float(r['phi_29_deg']) for r in sub])],[np.median([float(r['psi_29_deg']) for r in sub])],s=45,marker='D',edgecolors='white',linewidths=.6,color=color)
    rr=read('reference_Q29_torsions.csv');ax.scatter([float(r['phi_29_deg']) for r in rr],[float(r['psi_29_deg']) for r in rr],s=42,marker='*',color=GRAY,label='3MOP Q29')
    ax.text(-113,38,'P29: negative φ',color=ORANGE,fontsize=10);ax.text(13,57,'Q29: positive φ',color=BLUE,fontsize=10);ax.set_xlim(-120,90);ax.set_ylim(-8,69);ax.set_xlabel('φ (degrees)');ax.set_ylabel('ψ (degrees)');ax.legend(frameon=False,fontsize=9,loc='lower right');ax.grid(color='#E6EAEE',lw=.6);ax.set_axisbelow(True)
    box=[.065,.14,.49,.22];panel(fig,box,'C','Per-residue displacement from experimental IRAK4');ax=fig.add_axes(box);rows=read('local_per_residue.csv')
    for g,color in [('WT',BLUE),('Q29P',ORANGE)]:
        med=[];lo=[];hi=[]
        for i in range(20,105):
            vals=[float(r['CA_displacement_to_3MOP_G_A']) for r in rows if r['group']==g and int(r['residue'])==i];med.append(np.median(vals));lo.append(min(vals));hi.append(max(vals))
        ax.fill_between(range(20,105),lo,hi,color=color,alpha=.13,lw=0);ax.plot(range(20,105),med,color=color,lw=1.7,label=g)
    ax.axvspan(24,34,color='#E8DFCE',alpha=.45,zorder=0);ax.axvline(29,color=GRAY,ls=':',lw=1);ax.set_xlim(20,104);ax.set_ylim(bottom=0);ax.set_xlabel('IRAK4 residue (full-length numbering)');ax.set_ylabel('Cα displacement (Å)');ax.legend(frameon=False,ncol=2,fontsize=9);ax.grid(axis='y',color='#E6EAEE');ax.set_axisbelow(True)
    box=[.69,.14,.26,.22];panel(fig,box,'D','Confidence at the variant site');ax=fig.add_axes(box);dots(ax,LOCAL,'pLDDT_29',nested=True,ylabel='Residue 29 pLDDT',ylim=(65,82))
    fig.text(.035,.063,'Small points: four IRAK4 copies per candidate; diamonds: within-candidate medians. Shading in C spans all 20 model/copy values, not a confidence interval.',fontsize=9)
    fig.text(.035,.039,'Medoids: WT rank 3 / chain G; Q29P rank 4 / chain H. The extracted local folds are shown separately from the full-assembly steric limitations in Figs. 2–3.',fontsize=9,color=GRAY)
    fig.text(.035,.016,'The double-headed arrow marks a coordinate correspondence; it is not a measured motion trajectory. Local conformation changes do not establish altered signaling or binding.',fontsize=9,color=GRAY)
    save(fig,'Fig4_IRAK4_Q29P_local_conformation')

def interface():
    fig=plt.figure(figsize=(15,10));title(fig,'Exploratory geometry at the IRAK4–IRAK2 interface','Actual local subassemblies, rigidly aligned on the IRAK4 core. Distances and burial describe geometry within low-confidence predicted assemblies.')
    for col,g in enumerate(['3MOP','WT','Q29P']):
        box=[.035+col*.323,.48,.292,.35];panel(fig,box,chr(65+col),{'3MOP':'Experimental reference, 3MOP','WT':'WT rank 0','Q29P':'Q29P rank 0'}[g]);name='interface_'+g;ax=imagepanel(fig,name,box)
        leader(ax,anchor(ax,name,'site29'),'IRAK4 '+('P29' if g=='Q29P' else 'Q29'),(.02,.84),ORANGE if g=='Q29P' else BLUE,9.5)
        leader(ax,anchor(ax,name,'W63'),'IRAK2 W63',(.62,.12),COMP['IRAK2'],9.5)
        row=M['panels'][name]['distance_row'];distance=float(row['min_target_SC_partner_heavy_A'])
        leader(ax,anchor(ax,name,'distance'),f'{distance:.2f} Å\n'+row['target_atom']+'–'+row['partner_atom'],(.60,.77),TEXT,9.5)
    box=[.075,.15,.36,.225];panel(fig,box,'D','Residue 29 sidechain to IRAK2 W63');ax=fig.add_axes(box);rows=[r for r in read('Q29_interface_distances.csv') if r['partner_full_residue']=='63'];dots(ax,rows,'min_target_SC_partner_heavy_A',nested=True,ylabel='Minimum sidechain–heavy-atom distance (Å)',ylim=(2.2,5.3))
    box=[.58,.15,.35,.225];panel(fig,box,'E','Conditional two-chain geometric burial');ax=fig.add_axes(box);rows=read('IRAK4_IRAK2_pair_BSA.csv');dots(ax,rows,'pair_BSA_half_total_loss_A2',nested=True,ylabel='Pair buried surface area (Å²)',ylim=(390,570))
    fig.text(.035,.076,'Dashed lines show nearest heavy-atom separations, not assigned hydrogen bonds. Distance atom pairs differ because Gln and Pro have different sidechains.',fontsize=9)
    fig.text(.035,.052,'Burial = (SASA of the two isolated chains − SASA of the pair) / 2; IRAK4 4–106 and IRAK2 2–94. Probe 1.4 Å, 480 sphere points. Original chain mapping is supplied.',fontsize=9,color=GRAY)
    fig.text(.035,.028,'Reference IRAK2 carries engineered R50W; both prediction groups use native R50. These values are not binding energies and do not establish weaker binding or defective assembly.',fontsize=9,color=GRAY)
    save(fig,'Fig5_IRAK4_IRAK2_exploratory_interface')

def atlas():
    fig=plt.figure(figsize=(20,10));title(fig,'All ten predicted Myddosome DD candidates','One common orientation and scale. Red spheres mark the four IRAK4 Q29/P29 sites; original Chai clash flags are shown for every model.')
    for row,g in enumerate(['WT','Q29P']):
        for rank in range(5):
            x=.02+rank*.197;y=.49 if row==0 else .075;box=[x,y,.188,.34];ax=imagepanel(fig,'atlas_'+g+str(rank),box)
            q=next(v for v in QUALITY if v['group']==g and int(v['rank'])==rank)
            fig.text(x,y+.35,f'{g} rank {rank}',fontsize=12,fontweight='bold',color=BLUE if g=='WT' else ORANGE)
            label=f"ipTM {float(q['ipTM']):.3f}  |  clash flag: "+('YES' if q['chai_clash_flag']=='True' else 'NO')
            fig.text(x,y-.006,label,fontsize=9,color=RED if q['chai_clash_flag']=='True' else TEXT)
    fig.text(.025,.028,'A clash flag of NO does not certify complete stereochemical validity. Model ranks are candidate samples from one job per genotype, not independent experimental repeats.',fontsize=10,color=GRAY)
    save(fig,'FigS1_all_candidate_assemblies')

def pae_atlas():
    fig=plt.figure(figsize=(20,9.5));title(fig,'Predicted aligned error across every candidate','Full residue-by-residue PAE matrices. Chains retain their original Chai order; boundaries separate MyD88 (A–F), IRAK4 (G–J) and IRAK2 (K–N).')
    bounds=np.cumsum([0]+[98]*6+[103]*4+[111]*4);ticks=(bounds[:-1]+bounds[1:])/2
    im=None
    for row,g in enumerate(['WT','Q29P']):
        for rank in range(5):
            x=.035+rank*.193;y=.50 if row==0 else .12;ax=fig.add_axes([x,y,.168,.30]);p=np.load(ROOT/'inputs'/g/f'pae.rank_{rank}.npy',allow_pickle=False)
            im=ax.imshow(p,vmin=0,vmax=30,cmap=PAE,interpolation='nearest',rasterized=True);ax.set_xticks(ticks,list('ABCDEFGHIJKLMN'),fontsize=6.5);ax.set_yticks(ticks,list('ABCDEFGHIJKLMN'),fontsize=6.5)
            for q in [588-.5,1000-.5]:ax.axhline(q,color='white',lw=1);ax.axvline(q,color='white',lw=1)
            ax.set_title(f'{g} rank {rank}',fontsize=11,color=BLUE if g=='WT' else ORANGE,pad=7)
    cax=fig.add_axes([.30,.05,.40,.017]);fig.colorbar(im,cax=cax,orientation='horizontal',label='PAE (Å); low = blue, high = red')
    save(fig,'FigS2_all_candidate_PAE')

if __name__=='__main__':
    assembly();confidence();sterics();local();interface();atlas();pae_atlas()
