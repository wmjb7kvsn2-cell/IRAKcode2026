"""Coordinate-based descriptive analysis of two uploaded Chai-1 jobs.

No predictions, mutations, minimization, coordinate relaxation, or hypothesis
tests are performed. Chain permutation matching is exhaustive within species.
Run: PYTHONPATH=/path/to/extra/libs python scripts/analyze_complex.py
"""
from pathlib import Path
import argparse, copy, csv, hashlib, itertools, json, time
import numpy as np
from scipy.spatial import cKDTree
from Bio.PDB import MMCIFParser, PDBParser, PDBIO
from Bio.PDB.MMCIF2Dict import MMCIF2Dict
from Bio.SeqUtils import seq1
from Bio.PDB.vectors import Vector, calc_dihedral

ROOT=Path(__file__).resolve().parents[1]
CHAINS=list('ABCDEFGHIJKLMN')
SPECIES={c:('MyD88' if c in 'ABCDEF' else 'IRAK4' if c in 'GHIJ' else 'IRAK2') for c in CHAINS}
SETS=[list('ABCDEF'),list('GHIJ'),list('KLMN')]
OFFSET={'MyD88':19,'IRAK4':3,'IRAK2':1}
BOUNDS={'MyD88':(20,117),'IRAK4':(4,106),'IRAK2':(2,112)}
# Fixed structural comparison cores, selected before fitting and used for every
# structure. These are analysis ranges, not domain annotation boundaries.
CORE={'MyD88':list(range(25,111)),'IRAK4':list(range(20,101)),
      'IRAK2':[i for i in range(10,91) if i!=50]}
BB=('N','CA','C','O')

def writecsv(name,rows):
    rows=list(rows)
    if not rows:return
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with (ROOT/'data'/name).open('w',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)

def stats(x):
    a=np.array(x,dtype=float)
    return {'median':float(np.median(a)),'min':float(np.min(a)),'max':float(np.max(a))}

def fit(x,y):
    a=x.mean(0);b=y.mean(0)
    u,s,vt=np.linalg.svd((x-a).T@(y-b));z=np.eye(3);z[-1,-1]=np.linalg.det(u@vt)
    r=u@z@vt;return r,b-a@r

def rmsd(x,y):return float(np.sqrt(np.mean(np.sum((x-y)**2,axis=-1))))

def ca(m,c,ids):return np.array([m['res'][c][i]['CA'].coord for i in ids],dtype=float)

def points(m,c,ids,names=BB):
    return np.array([m['res'][c][i][n].coord for i in ids for n in names],dtype=float)

def load_model(group,rank):
    p=ROOT/'inputs'/group/f'pred.rank_{rank}.cif'
    structure=MMCIFParser(QUIET=True).get_structure(f'{group}_{rank}',str(p))
    d=MMCIF2Dict(str(p));res={};conf={};idx={};pos=0
    for c in structure[0]:
        res[c.id]={r.id[1]+OFFSET[SPECIES[c.id]]:r for r in c if r.id[0]==' '}
        conf[c.id]={i:float(r['CA'].bfactor) for i,r in res[c.id].items()}
        idx[c.id]=np.arange(pos,pos+len(res[c.id]));pos+=len(res[c.id])
    # Verify that the explicitly named local QA metric agrees with CA B factors.
    qa={}
    for c,i,v in zip(d['_ma_qa_metric_local.label_asym_id'],d['_ma_qa_metric_local.label_seq_id'],d['_ma_qa_metric_local.metric_value']):
        qa[(c,int(i)+OFFSET[SPECIES[c]])]=float(v)
    assert len(qa)==1444 and max(abs(qa[c,i]-conf[c][i]) for c in CHAINS for i in res[c])<.011
    pae=np.load(ROOT/'inputs'/group/f'pae.rank_{rank}.npy',allow_pickle=False)
    assert pae.shape==(1444,1444) and np.isfinite(pae).all()
    score=json.loads((ROOT/'inputs'/group/f'scores.rank_{rank}.json').read_text())
    return dict(group=group,rank=rank,structure=structure,res=res,conf=conf,idx=idx,pae=pae,score=score)

def load_reference():
    s=PDBParser(QUIET=True).get_structure('3MOP',str(ROOT/'reference/3MOP.pdb'))
    res={c:{r.id[1]:r for r in s[0][c] if r.id[0]==' ' and BOUNDS[SPECIES[c]][0]<=r.id[1]<=BOUNDS[SPECIES[c]][1]} for c in CHAINS}
    return dict(group='3MOP',rank=-1,structure=s,res=res)

def save_full_numbering(m,path,r=None,t=None,chain_mapping=None):
    s=copy.deepcopy(m['structure'])
    for c in list(s[0]):
        for atom in c.get_atoms():
            if r is not None:atom.coord=atom.coord@r+t
        if m['group']!='3MOP':
            # Rebuild ids through temporary values to avoid transient duplicates.
            offset=OFFSET[SPECIES[c.id]]
            for residue in reversed(list(c)):
                residue.id=(residue.id[0],residue.id[1]+offset,residue.id[2])
        for residue in list(c):
            if residue.id[0]!=' ' or residue.id[1] not in m['res'][c.id]:c.detach_child(residue.id)
    if chain_mapping:
        originals=list(s[0]);new=copy.deepcopy(s)
        for c in list(new[0]):new[0].detach_child(c.id)
        for c in originals:
            cc=copy.deepcopy(c);cc.detach_parent();cc.id=chain_mapping[c.id];new[0].add(cc)
        s=new
    io=PDBIO();io.set_structure(s);io.save(str(path))

def residue_atom_arrays(m,c,common=False):
    records=[]
    for i,res in m['res'][c].items():
        if common and (i not in COMMON[SPECIES[c]]):continue
        for a in res:
            if a.element in ('C','N','O','S'):records.append((i,a.name,a.element,a.coord))
    return records

def contacts(m,a,b,common=False,cutoff=5.):
    aa=residue_atom_arrays(m,a,common);bb=residue_atom_arrays(m,b,common)
    x=np.array([z[3] for z in aa],float);y=np.array([z[3] for z in bb],float)
    sparse=cKDTree(x).sparse_distance_matrix(cKDTree(y),cutoff,output_type='coo_matrix')
    rp={};atomclash=0;minrec=(float('inf'),None,None)
    for u,v,d in zip(sparse.row,sparse.col,sparse.data):
        i,j=aa[u][0],bb[v][0];rp[i,j]=min(rp.get((i,j),float('inf')),float(d))
        if d<1.5:atomclash+=1
        if d<minrec[0]:minrec=(float(d),aa[u][:3],bb[v][:3])
    return rp,atomclash,minrec

def mapped_key(a,i,b,j,mapping=None):
    if mapping:a,b=mapping[a],mapping[b]
    return (a,i,b,j) if a<b else (b,j,a,i)

def exhaustive_match(mobile,reference):
    """Exact best proper-rotation CA RMSD over all 6! x 4! x 4! permutations.

    Each species has the same matched residue count for all its copies, so the
    global centroid and squared coordinate norms do not depend on permutation.
    Enumerate covariance sums and obtain each optimal Kabsch objective by SVD.
    """
    x={c:ca(mobile,c,CORE[SPECIES[c]]) for c in CHAINS}
    y={c:ca(reference,c,CORE[SPECIES[c]]) for c in CHAINS}
    xx=np.concatenate(list(x.values()));yy=np.concatenate(list(y.values()))
    ax=xx.mean(0);ay=yy.mean(0)
    perms=[];sums=[]
    for ss in SETS:
        pp=list(itertools.permutations(ss));perms.append(pp)
        cov={(a,b):(x[a]-ax).T@(y[b]-ay) for a in ss for b in ss}
        sums.append(np.array([sum((cov[a,b] for a,b in zip(ss,p)),np.zeros((3,3))) for p in pp]))
    covs=(sums[0][:,None,None,:,:]+sums[1][None,:,None,:,:]+sums[2][None,None,:,:,:]).reshape(-1,3,3)
    # Batched singular values; determinant correction excludes mirror solutions.
    singular=np.linalg.svd(covs,compute_uv=False)
    objectives=singular.sum(1)-2*singular[:,-1]*(np.linalg.det(covs)<0)
    flat=int(np.argmax(objectives));ii=np.unravel_index(flat,(720,24,24))
    mapping={a:b for ss,pp,k in zip(SETS,perms,ii) for a,b in zip(ss,pp[k])}
    xpts=np.concatenate([x[c] for c in CHAINS]);ypts=np.concatenate([y[mapping[c]] for c in CHAINS])
    r,t=fit(xpts,ypts)
    val=rmsd(xpts@r+t,ypts)
    objective_rmsd=np.sqrt(max(0.,(np.sum((xx-ax)**2)+np.sum((yy-ay)**2)-2*objectives[flat])/len(xx)))
    assert abs(val-objective_rmsd)<1e-6
    return mapping,r,t,val

def do_qc(models,ref):
    seqrows=[];quality=[];chainrows=[];pairrows=[];manifest=[];all_contactrows=[]
    expected={}
    for sp,name in [('MyD88','MyD88_DD_res20-117.fasta'),('IRAK4','IRAK4_DD_WT_res4-106.fasta'),('IRAK2','IRAK2_DD_res2-112_native_R50.fasta')]:
        expected[sp]=''.join(x.strip() for x in (ROOT/'reference'/name).read_text().splitlines() if not x.startswith('>'))
    for m in models:
        g,rank=m['group'],m['rank'];score=m['score'];ids=m['idx'];p=m['pae']
        assert list(m['res'])==CHAINS
        for c in CHAINS:
            sp=SPECIES[c];seq=''.join(seq1(r.resname) for r in m['res'][c].values());exp=expected[sp]
            diff=[f'{a}{i+BOUNDS[sp][0]}{b}' for i,(a,b) in enumerate(zip(exp,seq)) if a!=b]
            assert len(seq)==len(exp) and diff==(['Q29P'] if g=='Q29P' and sp=='IRAK4' else [])
            seqrows.append(dict(group=g,rank=rank,chain=c,species=sp,length=len(seq),full_start=BOUNDS[sp][0],full_end=BOUNDS[sp][1],differences_vs_WT=';'.join(diff),sequence=seq))
            block=p[np.ix_(ids[c],ids[c])];off=~np.eye(len(block),dtype=bool)
            chainrows.append(dict(group=g,rank=rank,chain=c,species=sp,pLDDT_mean=np.mean(list(m['conf'][c].values())),pLDDT_Q29=m['conf'][c].get(29,np.nan) if sp=='IRAK4' else np.nan,chain_pTM=np.asarray(score['per_chain_ptm']).ravel()[CHAINS.index(c)],intra_PAE_median_A=np.median(block[off])))
        allids=np.repeat(np.arange(14),[len(m['res'][c]) for c in CHAINS]);inter=allids[:,None]!=allids[None,:]
        q=dict(group=g,rank=rank,aggregate_score=score['aggregate_score'],pTM=score['ptm'],ipTM=score['iptm'],chai_clash_flag=score['has_inter_chain_clashes'],pLDDT_mean=np.mean([v for c in CHAINS for v in m['conf'][c].values()]),inter_PAE_median_A=np.median(p[inter]),inter_PAE_lt10_fraction=np.mean(p[inter]<10))
        calculated=.2*score['ptm']+.8*score['iptm']-100*bool(score['has_inter_chain_clashes'])
        q['aggregate_formula_error']=abs(calculated-score['aggregate_score']);assert q['aggregate_formula_error']<1e-5
        pair_iptm=np.asarray(score['per_chain_pair_iptm']).reshape(14,14)
        clashmatrix=np.asarray(score['chain_chain_clashes']).reshape(14,14)
        for a,b in itertools.combinations(CHAINS,2):
            rp,nclash,minrec=contacts(m,a,b)
            contact_pairs=[(i,j) for (i,j),d in rp.items() if d<=4.5]
            ab=p[np.ix_(ids[a],ids[b])];ba=p[np.ix_(ids[b],ids[a])]
            cp=[]
            for i,j in contact_pairs:
                ai=i-BOUNDS[SPECIES[a]][0];bi=j-BOUNDS[SPECIES[b]][0]
                cp.extend([ab[ai,bi],ba[bi,ai]])
            row=dict(group=g,rank=rank,chain1=a,chain2=b,species1=SPECIES[a],species2=SPECIES[b],pair_type='-'.join(sorted([SPECIES[a],SPECIES[b]])),pair_ipTM_mean=.5*(pair_iptm[CHAINS.index(a),CHAINS.index(b)]+pair_iptm[CHAINS.index(b),CHAINS.index(a)]),pair_PAE_median_A=np.median(np.r_[ab.ravel(),ba.ravel()]),pair_PAE_lt10_fraction=np.mean(np.r_[ab.ravel(),ba.ravel()]<10),residue_contacts_3p5A=sum(d<=3.5 for d in rp.values()),residue_contacts_4p5A=len(contact_pairs),residue_contacts_5A=len(rp),heavy_atom_pairs_lt1p5A=nclash,chai_pair_clash_count=clashmatrix[CHAINS.index(a),CHAINS.index(b)],contact_PAE_median_A=np.median(cp) if cp else np.nan,min_heavy_distance_within5A=minrec[0] if np.isfinite(minrec[0]) else np.nan)
            pairrows.append(row)
            for (i,j),dist in rp.items():
                if dist<=4.5:
                    all_contactrows.append(dict(group=g,rank=rank,chain1=a,res1=i,chain2=b,res2=j,min_heavy_distance_A=dist))
        for species1,species2,label in [('MyD88','IRAK4','MyD88_IRAK4'),('IRAK4','IRAK2','IRAK4_IRAK2')]:
            ix=np.concatenate([ids[c] for c in CHAINS if SPECIES[c]==species1]);iy=np.concatenate([ids[c] for c in CHAINS if SPECIES[c]==species2])
            v=np.r_[p[np.ix_(ix,iy)].ravel(),p[np.ix_(iy,ix)].ravel()]
            q[f'{label}_PAE_median_A']=np.median(v);q[f'{label}_PAE_lt10_fraction']=np.mean(v<10)
        quality.append(q)
    for g in ['WT','Q29P']:
        for pth in sorted((ROOT/'inputs'/g).iterdir()):manifest.append(dict(group=g,file=pth.name,bytes=pth.stat().st_size,sha256=hashlib.sha256(pth.read_bytes()).hexdigest()))
    writecsv('sequence_audit.csv',seqrows);writecsv('model_quality.csv',quality);writecsv('chain_quality.csv',chainrows);writecsv('chain_pair_metrics.csv',pairrows);writecsv('residue_contacts_4p5A.csv',all_contactrows);writecsv('input_manifest.csv',manifest)
    summary={g:{k:stats([x[k] for x in quality if x['group']==g]) for k in ['pTM','ipTM','pLDDT_mean','inter_PAE_median_A','inter_PAE_lt10_fraction','MyD88_IRAK4_PAE_median_A','IRAK4_IRAK2_PAE_median_A']} for g in ['WT','Q29P']}
    for g in summary:summary[g]['clash_flagged_models']=sum(x['chai_clash_flag'] for x in quality if x['group']==g)
    (ROOT/'data/qc_summary.json').write_text(json.dumps(summary,indent=2))
    print('QC',json.dumps(summary),flush=True)
    return quality,chainrows,pairrows

def do_mapping(models,ref,all_pairs=True):
    mappingrows=[];matches={};refcontacts=set();allrefrows=[]
    for a,b in itertools.combinations(CHAINS,2):
        rp,_,_=contacts(ref,a,b,common=True)
        for (i,j),d in rp.items():
            if d<=4.5:refcontacts.add(mapped_key(a,i,b,j));allrefrows.append(dict(chain1=a,res1=i,chain2=b,res2=j,min_heavy_distance_A=d))
    writecsv('reference_contacts_4p5A.csv',allrefrows)
    for m in models:
        mapping,r,t,val=exhaustive_match(m,ref);key=(m['group'],m['rank']);matches[key]=(mapping,r,t,val)
        predcontacts=set()
        for a,b in itertools.combinations(CHAINS,2):
            rp,_,_=contacts(m,a,b,common=True)
            predcontacts|={mapped_key(a,i,b,j,mapping) for (i,j),d in rp.items() if d<=4.5}
        inter=refcontacts&predcontacts
        row=dict(group=m['group'],rank=m['rank'],reference_core_CA_RMSD_A=val,reference_contacts=len(refcontacts),predicted_contacts_common_residues=len(predcontacts),shared_reference_contacts=len(inter),reference_contact_recall=len(inter)/len(refcontacts),reference_contact_precision=len(inter)/len(predcontacts) if predcontacts else 0.,mapping=json.dumps(mapping,sort_keys=True))
        for sp1,sp2,label in [('MyD88','IRAK4','MyD88_IRAK4'),('IRAK4','IRAK2','IRAK4_IRAK2')]:
            def keep(k):return {SPECIES[k[0]],SPECIES[k[2]]}=={sp1,sp2}
            rr={k for k in refcontacts if keep(k)};pp={k for k in predcontacts if keep(k)}
            row[label+'_reference_contact_recall']=len(rr&pp)/len(rr)
            row[label+'_shared_contacts']=len(rr&pp);row[label+'_reference_contacts']=len(rr)
        mappingrows.append(row)
        save_full_numbering(m,ROOT/'coordinates'/f'{m["group"]}_rank{m["rank"]}_reference_fit.pdb',r,t,mapping)
        save_full_numbering(m,ROOT/'coordinates'/f'{m["group"]}_rank{m["rank"]}_aligned_original_chainIDs.pdb',r,t)
        print('REFERENCE_FIT',m['group'],m['rank'],round(val,3),'contact_recall',round(row['reference_contact_recall'],4),flush=True)
    save_full_numbering(ref,ROOT/'coordinates/3MOP_observed_input_segments.pdb')
    writecsv('reference_comparison.csv',mappingrows)
    # Pairwise ensemble spread: exact species-constrained copy permutations,
    # never independent biological replication or a significance test.
    pairrows=[]
    if all_pairs:
        for a,b in itertools.combinations(models,2):
            mapping,r,t,val=exhaustive_match(b,a)
            pairrows.append(dict(group1=a['group'],rank1=a['rank'],group2=b['group'],rank2=b['rank'],core_CA_RMSD_A=val,mapping_mobile_to_reference=json.dumps(mapping,sort_keys=True)))
            print('PAIR_FIT',a['group'],a['rank'],b['group'],b['rank'],round(val,3),flush=True)
        writecsv('ensemble_pairwise_RMSD.csv',pairrows)
    (ROOT/'data/assembly_matching_method.json').write_text(json.dumps(dict(method='Exhaustive species-constrained chain permutations and proper-rotation Kabsch fitting',n_permutations=720*24*24,fit_atom='CA',full_length_numbered_cores=CORE,n_core_atoms=sum(len(CORE[SPECIES[c]]) for c in CHAINS),common_contact_residues=COMMON,contact_cutoff_A=4.5,reference_background='3MOP IRAK2 R50W; exclude residue 50 and non-common/unobserved residues from reference contact comparison',sequence_numbering='All tables/PDB deliverables use full-length numbering; original CIFs retain fragment numbering'),indent=2))
    return mappingrows,matches

def do_local(models,ref):
    rr=[]
    allchains=[(m,c) for m in models for c in 'GHIJ']
    localcore=[i for i in range(20,105) if not 24<=i<=34 and all(m['conf'][c][i]>=80 for m,c in allchains)]
    assert len(localcore)>30
    base=ref;bc='G';ids=list(range(24,35));out=[]
    for m,c in allchains:
        r,t=fit(ca(m,c,localcore),ca(base,bc,localcore))
        def angle(records):return float(np.degrees(calc_dihedral(*[Vector(m['res'][c][i][a].coord) for i,a in records])))
        row=dict(group=m['group'],rank=m['rank'],chain=c,full_position=29,fragment_position=26,resname=m['res'][c][29].resname,pLDDT_29=m['conf'][c][29],phi_29_deg=angle([(28,'C'),(29,'N'),(29,'CA'),(29,'C')]),psi_29_deg=angle([(29,'N'),(29,'CA'),(29,'C'),(30,'N')]),preceding_omega_deg=angle([(28,'CA'),(28,'C'),(29,'N'),(29,'CA')]),core_CA_RMSD_to_3MOP_G_A=rmsd(ca(m,c,localcore)@r+t,ca(base,bc,localcore)),local_BB_RMSD_to_3MOP_G_A=rmsd(points(m,c,ids)@r+t,points(base,bc,ids)),CA29_shift_to_3MOP_G_A=np.linalg.norm(ca(m,c,[29])@r+t-ca(base,bc,[29])))
        out.append(row)
        rr.append((m,c,r,t,points(m,c,ids)@r+t))
    # Local-conformation medoid from all 20 copies in each uploaded job.
    selections={};chosen_ca={};chosen_bb={};perres=[];pairlocal=[]
    for g in ['WT','Q29P']:
        sub=[x for x in rr if x[0]['group']==g]
        distances=np.array([[rmsd(x[-1],y[-1]) for y in sub] for x in sub])
        k=int(np.argmin(distances.mean(1)));m,c,r,t,xyz=sub[k]
        selections[g]=dict(rank=m['rank'],chain=c,selection='Minimum mean local backbone RMSD to all 20 within-group aligned copies',mean_local_distance_A=float(distances[k].mean()))
        chosen_ca[g]=ca(m,c,[29])@r+t;chosen_bb[g]=xyz
        # Store one actual, rigidly transformed chain in a full-length-numbered PDB.
        import Bio.PDB
        s=copy.deepcopy(m['structure'])
        for ch in list(s[0]):
            if ch.id!=c:s[0].detach_child(ch.id)
        for residue in reversed(list(s[0][c])):residue.id=(' ',residue.id[1]+3,' ')
        for a in s.get_atoms():a.coord=a.coord@r+t
        io=PDBIO();io.set_structure(s);io.save(str(ROOT/'coordinates'/f'IRAK4_local_medoid_{g}.pdb'))
    (ROOT/'data/local_medoid_annotation.json').write_text(json.dumps(dict(CA29_offset_A=float(np.linalg.norm(chosen_ca['WT']-chosen_ca['Q29P'])),window_BB_RMSD_medoid_pair_A=rmsd(chosen_bb['WT'],chosen_bb['Q29P']),models=selections),indent=2))
    for m,c,r,t,xyz in rr:
        for i in range(4,107):
            perres.append(dict(group=m['group'],rank=m['rank'],chain=c,residue=i,CA_displacement_to_3MOP_G_A=np.linalg.norm(ca(m,c,[i])@r+t-ca(base,bc,[i])),pLDDT=m['conf'][c][i]))
    for ia,x in enumerate(rr):
        for y in rr[ia+1:]:
            pairlocal.append(dict(group1=x[0]['group'],rank1=x[0]['rank'],chain1=x[1],group2=y[0]['group'],rank2=y[0]['rank'],chain2=y[1],local_BB_RMSD_A=rmsd(x[-1],y[-1])))
    refrows=[]
    for c in 'GHIJ':
        def ang(records):return float(np.degrees(calc_dihedral(*[Vector(ref['res'][c][i][a].coord) for i,a in records])))
        refrows.append(dict(chain=c,phi_29_deg=ang([(28,'C'),(29,'N'),(29,'CA'),(29,'C')]),psi_29_deg=ang([(29,'N'),(29,'CA'),(29,'C'),(30,'N')])))
    writecsv('local_Q29_geometry.csv',out);writecsv('local_per_residue.csv',perres);writecsv('local_pairwise_RMSD.csv',pairlocal);writecsv('reference_Q29_torsions.csv',refrows)
    (ROOT/'data/local_alignment.json').write_text(json.dumps(dict(local_window_full_numbering=ids,fit_core_full_numbering=localcore,core_min_pLDDT_all40copies=80,n_core=len(localcore),reference='3MOP chain G',medoids=selections,independence='Four copies share a predicted assembly; five ranks share one submitted job per genotype. No independent-repeat inference.'),indent=2))
    print('LOCAL',json.dumps(dict(core_n=len(localcore),medoids=selections,summary={g:{k:stats([x[k] for x in out if x['group']==g]) for k in ['phi_29_deg','psi_29_deg','pLDDT_29','local_BB_RMSD_to_3MOP_G_A']} for g in ['WT','Q29P']})),flush=True)

def do_geometry_summary(models,ref,pairrows):
    rows=[]
    for m in models+[ref]:
        cc={c:ca(m,c,[i for i in CORE[SPECIES[c]]]) .mean(0) for c in CHAINS}
        xyz=np.array(list(cc.values()));rg=float(np.sqrt(np.mean(np.sum((xyz-xyz.mean(0))**2,axis=1))))
        row=dict(group=m['group'],rank=m['rank'],chain_centroid_Rg_A=rg)
        for sp in ['MyD88','IRAK4','IRAK2']:
            cs=np.array([cc[c] for c in CHAINS if SPECIES[c]==sp]);row[sp+'_centroid_spread_A']=float(np.sqrt(np.mean(np.sum((cs-cs.mean(0))**2,axis=1))))
        for sp1,sp2 in [('MyD88','IRAK4'),('IRAK4','IRAK2'),('MyD88','IRAK2')]:
            x=np.mean([cc[c] for c in CHAINS if SPECIES[c]==sp1],axis=0);y=np.mean([cc[c] for c in CHAINS if SPECIES[c]==sp2],axis=0)
            row[sp1+'_'+sp2+'_component_centroid_distance_A']=float(np.linalg.norm(x-y))
        rows.append(row)
    writecsv('assembly_geometry.csv',rows)

def main(stage):
    for p in ['data','coordinates']:(ROOT/p).mkdir(exist_ok=True)
    models=[load_model(g,k) for g in ['WT','Q29P'] for k in range(5)];ref=load_reference()
    global COMMON
    COMMON={sp:sorted(set.intersection(*[set(ref['res'][c]) for c in CHAINS if SPECIES[c]==sp])) for sp in ['MyD88','IRAK4','IRAK2']}
    COMMON['IRAK2']=[i for i in COMMON['IRAK2'] if i!=50]
    if stage in ('all','qc'):
        quality,chains,pairs=do_qc(models,ref);do_geometry_summary(models,ref,pairs)
    if stage in ('all','mapping'):do_mapping(models,ref)
    if stage in ('all','local'):do_local(models,ref)
    print('FINISHED',stage,flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--stage',choices=['all','qc','mapping','local'],default='all');a=ap.parse_args();main(a.stage)
