"""Local interface/steric diagnostics; all numbering is full-length numbering."""
from pathlib import Path
import copy,csv,json,sys
import numpy as np
from Bio.PDB.SASA import ShrakeRupley
from scipy.spatial import cKDTree
from openmm.app import ForceField
import analyze_complex as ac

ROOT=ac.ROOT

def min_atoms(a,b):
    if not a or not b:return (float('nan'),'','')
    d=np.linalg.norm(np.array([x.coord for x in a])[:,None,:]-np.array([x.coord for x in b])[None,:,:],axis=2)
    i,j=np.unravel_index(np.argmin(d),d.shape);return float(d[i,j]),a[i].name,b[j].name

def sidechain(res):return [a for a in res if a.element in ('C','N','O','S') and a.name not in ac.BB+('OXT',)]
def heavy(res):return [a for a in res if a.element in ('C','N','O','S')]

def local_clashes(m,c,templates):
    aa=[a for r in m['res'][c].values() for a in r if a.element in ('C','N','O','S')]
    key={(a.parent.id[1]+3,a.name):k for k,a in enumerate(aa)};graph=[set() for _ in aa]
    def edge(x,y):
        if x in key and y in key:
            i,j=key[x],key[y];graph[i].add(j);graph[j].add(i)
    for i,res in m['res'][c].items():
        tpl=templates['HIE' if res.resname=='HIS' else res.resname]
        for u,v in tpl.bonds:edge((i,tpl.atoms[u].name),(i,tpl.atoms[v].name))
        if i+1 in m['res'][c]:edge((i,'C'),(i+1,'N'))
    rad={'C':1.70,'N':1.55,'O':1.52,'S':1.80};pairs=[]
    for a in sidechain(m['res'][c][29]):
        k=key[29,a.name];seen={k};wave={k}
        for _ in range(3):wave={j for i in wave for j in graph[i]}-seen;seen|=wave
        for j,b in enumerate(aa):
            if j in seen:continue
            d=float(np.linalg.norm(a.coord-b.coord));overlap=rad[a.element]+rad[b.element]-d
            if overlap>.4:pairs.append(dict(group=m['group'],rank=m['rank'],chain=c,target_atom=a.name,partner_residue=b.parent.id[1]+3,partner_atom=b.name,distance_A=d,vdw_overlap_A=overlap))
    return pairs

def two_chain_bsa(m,c,d,sr):
    # Restrict to identical input-overlap spans. The experimental IRAK2 tail
    # beyond 94 is unresolved; reference R50W is retained and disclosed.
    s=copy.deepcopy(m['structure'])
    for ch in list(s[0]):
        if ch.id not in (c,d):s[0].detach_child(ch.id);continue
        offset=ac.OFFSET[ac.SPECIES[ch.id]] if m['group']!='3MOP' else 0
        lo,hi=(4,106) if ch.id==c else (2,94)
        for r in list(ch):
            if r.id[0]!=' ' or not lo<=r.id[1]+offset<=hi:ch.detach_child(r.id)
    isolated=[]
    for ch in s[0]:sr.compute(ch,level='C');isolated.append(ch.sasa)
    sr.compute(s[0],level='C')
    buried={ch.id:isolated[i]-ch.sasa for i,ch in enumerate(s[0])}
    return sum(buried.values())/2,buried[c],buried[d]

def main():
    models=[ac.load_model(g,k) for g in ['WT','Q29P'] for k in range(5)];ref=ac.load_reference()
    comparisons=list(csv.DictReader((ROOT/'data/reference_comparison.csv').open()))
    mappings={(r['group'],int(r['rank'])):json.loads(r['mapping']) for r in comparisons}
    templates=ForceField('amber14-all.xml')._templates
    sr=ShrakeRupley(probe_radius=1.4,n_points=480)
    contactrows=[];sterics=[];overlaps=[];localrows=[];sasarows=[]
    for m in models+[ref]:
        mapping=mappings.get((m['group'],m['rank']),{c:c for c in ac.CHAINS});inverse={b:a for a,b in mapping.items()}
        if m['group']!='3MOP':
            for a,b in __import__('itertools').combinations('ABCDEF',2):
                xa=ac.ca(m,a,list(range(25,111)));xb=ac.ca(m,b,list(range(25,111)))
                overlaps.append(dict(group=m['group'],rank=m['rank'],chain1=a,chain2=b,centroid_distance_A=np.linalg.norm(xa.mean(0)-xb.mean(0)),CA_RMSD_same_frame_A=ac.rmsd(xa,xb)))
            for c in 'GHIJ':
                sterics.extend(local_clashes(m,c,templates))
                res=m['res'][c][29]
                if res.resname=='PRO':
                    localrows.append(dict(group=m['group'],rank=m['rank'],chain=c,Pro29_N_CD_bond_A=np.linalg.norm(res['N'].coord-res['CD'].coord)))
        for rc,rd in zip('GHIJ','KLMN'):
            c,d=inverse[rc],inverse[rd]
            q=m['res'][c][29]
            for pos in [44,48,59,62,63]:
                other=m['res'][d][pos]
                dh,aq,ao=min_atoms(sidechain(q),heavy(other))
                ds,_,_=min_atoms(sidechain(q),sidechain(other))
                contactrows.append(dict(group=m['group'],rank=m['rank'],IRAK4_original_chain=c,IRAK2_original_chain=d,IRAK4_reference_position=rc,IRAK2_reference_position=rd,target_resname=q.resname,partner_full_residue=pos,partner_resname=other.resname,min_target_SC_partner_heavy_A=dh,target_atom=aq,partner_atom=ao,min_SC_SC_A=ds))
            # Stable hydrophobic reference-neighborhood contact, different from
            # the changed target chemistry; reported descriptively only.
            f=m['res'][c][25];w=m['res'][d][62]
            df,af,aw=min_atoms(sidechain(f),sidechain(w))
            bsa,b1,b2=two_chain_bsa(m,c,d,sr)
            sasarows.append(dict(group=m['group'],rank=m['rank'],IRAK4_original_chain=c,IRAK2_original_chain=d,IRAK4_reference_position=rc,IRAK2_reference_position=rd,pair_BSA_half_total_loss_A2=bsa,IRAK4_buried_SASA_A2=b1,IRAK2_buried_SASA_A2=b2,F25_W62_min_SC_distance_A=df,F25_atom=af,W62_atom=aw))
        print('INTERFACE_DONE',m['group'],m['rank'],flush=True)
    ac.writecsv('Q29_interface_distances.csv',contactrows);ac.writecsv('Q29_intra_chain_vdw_overlaps.csv',sterics);ac.writecsv('Pro29_ring_bond.csv',localrows);ac.writecsv('MyD88_spatial_overlap.csv',overlaps);ac.writecsv('IRAK4_IRAK2_pair_BSA.csv',sasarows)
    (ROOT/'data/interface_method.json').write_text(json.dumps(dict(pair_mapping='Use the globally optimum species-constrained mapping to the experimental G-K, H-L, I-M, J-N pairs',SASA_method='Biopython ShrakeRupley',SASA_probe_radius_A=1.4,SASA_sphere_points=480,IRAK4_full_range=[4,106],IRAK2_full_range=[2,94],BSA_definition='(SASA_IRAK4_alone + SASA_IRAK2_alone - SASA_two_chain_complex)/2; geometric two-chain burial, not binding energy',reference_background='3MOP retains IRAK2 R50W; WT/Q29P predictions both have native R50',sterics='Target sidechain vs same-chain heavy atoms; Amber bond graph excludes <=3 covalent bonds; vdW overlap diagnostic, not MolProbity clashscore',interpretation='Full Q29P assemblies have severe remote MyD88 copy overlap; pair distances/BSA are conditional geometric descriptions, not evidence of affinity or assembly function.'),indent=2))
    print('INTERFACES_FINISHED',flush=True)

if __name__=='__main__':main()
