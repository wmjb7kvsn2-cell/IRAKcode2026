"""Validate deliverables, preserve inputs byte-for-byte, and package this run."""
from pathlib import Path
import csv,hashlib,json,zipfile,ast
from PIL import Image
import analyze_complex as ac

R=ac.ROOT

def chosen(p):
    rel=p.relative_to(R)
    if '__pycache__' in rel.parts or p.name.endswith('_landmark.png'):return False
    if rel.parts[0]=='coordinates':
        return (p.name.endswith('_reference_fit.pdb') or p.name.endswith('_aligned_original_chainIDs.pdb') or p.name=='3MOP_observed_input_segments.pdb' or p.name.startswith('IRAK4_local_medoid_'))
    return p.name!='package_manifest.json'

def main():
    pngs=sorted((R/'figures').glob('*.png'));assert len(pngs)==7
    for p in pngs:
        with Image.open(p) as im:
            im.verify()
        assert p.with_suffix('.svg').is_file()
    for p in (R/'scripts').glob('*.py'):ast.parse(p.read_text())
    # Confirm preservation against the supplied original archive members.
    source_archive=R.parents[1]/'upload'
    checks=[]
    for group in ['WT','Q29P']:
        archive=source_archive/f'Myddosome_DD_{group}_run1.zip'
        if archive.exists():
            with zipfile.ZipFile(archive) as z:
                for name in z.namelist():
                    local=R/'inputs'/group/name
                    assert z.read(name)==local.read_bytes()
                    checks.append(dict(group=group,file=name,byte_identical=True))
    (R/'data/input_preservation_check.json').write_text(json.dumps(checks,indent=2))
    progress=json.loads((R/'notes/progress.json').read_text())
    progress.update(status='completed',completed=['All 140 chain-sequence checks','Ten-model and 910 chain-pair confidence/contact analysis','Exact copy-permuted comparisons to 3MOP and all 45 ensemble pairs','Independent component subassembly comparisons','All 40 local IRAK4 geometry analyses and selected sensitivity checks','Actual IRAK4-IRAK2 distances and conditional geometric SASA','Five main figures and two complete candidate atlases, PNG/SVG','English draft Methods/legends and Chinese report','Coordinate export, figure and original-input validation'],running=[],pending=[],resume='Start with Myddosome_Chai_run1_analysis.md and data/final_summary.json. All original inputs, derived numerical tables and rendering/analysis scripts are included. No new remote predictions were run. The next scientific decision is whether local-conformation evidence is sufficient for the revision, or whether experimental/template-guided interface work is needed.')
    progress['saved_result_identities']={'report':'libfile_ab5aee239cd0819183cd21f9e034d002','package':'libfile_92e6bbedcfb8819195a25fbbc3cb1d53'}
    (R/'notes/progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2))
    (R/'README.md').write_text('''# Myddosome Chai-1 WT/Q29P run 1 analysis

Start with **Myddosome_Chai_run1_analysis.md** (Chinese findings, limitations and next steps).
English draft Methods and legends are in **Figure_legends_and_methods.md**.

- `figures/`: five main and two complete-candidate figures; PNG (300 dpi) and SVG.
- `data/`: inspectable model/chain/interface tables, summaries and validation.
- `inputs/WT`, `inputs/Q29P`: all 32 original exported files, byte-preserved.
- `reference/`: original 3MOP PDB and canonical input fragment sequences.
- `coordinates/`: rigidly aligned, full-length-numbered exports and local medoids.
- `renders/`, `sessions/`: coordinate renderings and editable PyMOL sessions.
- `scripts/`: reproducible analysis, rendering, figure composition and packaging.
- `notes/progress.json`: completed work and continuation entry point.

The most consistent prediction is the local Q29/P29 backbone change. Every Q29P
full-assembly candidate and two WT candidates contain nonphysical MyD88-copy
overlap. Whole-assembly shape, confidence scores, distances and geometric burial
must not be interpreted as binding affinity, stability, assembly function or
signaling activity. One job per genotype and its candidate samples do not supply
independent biological replication.

See `environment.json` for analysis/rendering dependencies. Input Chai checkpoint,
seed IDs and exact template/MSA hits were not included in the server exports.

Reproduction order: analyze_complex.py, analyze_interfaces.py,
analyze_subassemblies.py, validate_analysis.py, render_figures.py,
compose_figures.py, build_report.py, package_results.py. Run the scripts with a
Python environment containing the dependencies listed in environment.json.
''')
    files=[p for p in sorted(R.rglob('*')) if p.is_file() and chosen(p)]
    manifest=[dict(file=str(p.relative_to(R)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
    (R/'package_manifest.json').write_text(json.dumps(manifest,indent=2))
    out=R.parent/'Myddosome_Chai_run1_analysis_package.zip'
    tmp=out.with_suffix('.zip.tmp')
    with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[R/'package_manifest.json']:z.write(p,p.relative_to(R.parent))
    tmp.replace(out)
    with zipfile.ZipFile(out) as z:assert z.testzip() is None
    print(json.dumps(dict(package=str(out),bytes=out.stat().st_size,files=len(files)+1,original_files_verified=len(checks),figures_png=len(pngs)),indent=2))

if __name__=='__main__':main()
