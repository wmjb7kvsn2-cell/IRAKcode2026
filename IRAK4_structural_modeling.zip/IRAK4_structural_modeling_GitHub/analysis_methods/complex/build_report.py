"""Build source-backed report, nested descriptive summaries, and figure legends."""
import csv,json,sys,platform,importlib.metadata
from pathlib import Path
import numpy as np
import analyze_complex as ac

R=ac.ROOT
def read(n):return list(csv.DictReader((R/'data'/n).open()))
def stat(rows,key,g):return ac.stats([float(r[key]) for r in rows if r['group']==g])
def nested(rows,key,g):
    return ac.stats([np.median([float(r[key]) for r in rows if r['group']==g and int(r['rank'])==k]) for k in range(5)])
def form(s,d=2):return f"{s['median']:.{d}f} ({s['min']:.{d}f}–{s['max']:.{d}f})"

def main():
    quality=read('model_quality.csv');reference=read('reference_comparison.csv');local=read('local_Q29_geometry.csv');dist=[r for r in read('Q29_interface_distances.csv') if r['partner_full_residue']=='63'];bsa=read('IRAK4_IRAK2_pair_BSA.csv');pairs=read('ensemble_pairwise_RMSD.csv');clashes=read('chain_pair_metrics.csv')
    summary={g:{'ipTM':stat(quality,'ipTM',g),'pTM':stat(quality,'pTM',g),'reference_core_RMSD_A':stat(reference,'reference_core_CA_RMSD_A',g),'reference_contact_recall':stat(reference,'reference_contact_recall',g),'MyD88_IRAK4_reference_contact_recall':stat(reference,'MyD88_IRAK4_reference_contact_recall',g),'IRAK4_IRAK2_reference_contact_recall':stat(reference,'IRAK4_IRAK2_reference_contact_recall',g),'phi29_nested_model_medians_deg':nested(local,'phi_29_deg',g),'psi29_nested_model_medians_deg':nested(local,'psi_29_deg',g),'pLDDT29_nested_model_medians':nested(local,'pLDDT_29',g),'local_BB_RMSD_to_3MOP_G_nested_A':nested(local,'local_BB_RMSD_to_3MOP_G_A',g),'29_W63_distance_nested_A':nested(dist,'min_target_SC_partner_heavy_A',g),'pair_BSA_nested_A2':nested(bsa,'pair_BSA_half_total_loss_A2',g),'clash_flagged_models':sum(r['chai_clash_flag']=='True' for r in quality if r['group']==g)} for g in ['WT','Q29P']}
    summary['ensemble_RMSD']={a+'-'+b:ac.stats([float(r['core_CA_RMSD_A']) for r in pairs if r['group1']==a and r['group2']==b]) for a,b in [('WT','WT'),('WT','Q29P'),('Q29P','Q29P')]}
    for g in ['WT','Q29P']:
        summary[g]['local_phi_all20_copies']=stat(local,'phi_29_deg',g);summary[g]['local_psi_all20_copies']=stat(local,'psi_29_deg',g)
    lp=read('local_pairwise_RMSD.csv')
    summary['local_pairwise_BB_RMSD_A']={a+'-'+b:ac.stats([float(r['local_BB_RMSD_A']) for r in lp if r['group1']==a and r['group2']==b]) for a,b in [('WT','WT'),('WT','Q29P'),('Q29P','Q29P')]}
    (R/'data/final_summary.json').write_text(json.dumps(summary,indent=2))
    table=[]
    fields=[('ipTM','ipTM',3),('pTM','pTM',3),('相对3MOP的核心Cα RMSD（Å）','reference_core_RMSD_A',2),('3MOP残基接触保留率','reference_contact_recall',3),('29位φ角（°）*','phi29_nested_model_medians_deg',1),('29位ψ角（°）*','psi29_nested_model_medians_deg',1),('29位pLDDT*','pLDDT29_nested_model_medians',1),('24–34局部主链RMSD，相对3MOP G（Å）*','local_BB_RMSD_to_3MOP_G_nested_A',2),('29位侧链–IRAK2 W63最短重原子距离（Å）*','29_W63_distance_nested_A',2),('条件性两链BSA（Å²）*','pair_BSA_nested_A2',1)]
    for label,key,d in fields:table.append(f'| {label} | {form(summary["WT"][key],d)} | {form(summary["Q29P"][key],d)} |')
    q0=next(r for r in clashes if r['group']=='Q29P' and r['rank']=='0' and r['chain1']=='B' and r['chain2']=='E')
    subs=json.loads((R/'data/subassembly_summary.json').read_text())
    subtable='\n'.join('| '+sp+' | '+form(subs['WT'][sp])+' | '+form(subs['Q29P'][sp])+' |' for sp in ['MyD88','IRAK4','IRAK2'])
    validation=json.loads((R/'data/validation.json').read_text()) if (R/'data/validation.json').exists() else {}
    content='''# Myddosome DD：IRAK4-WT 与 Q29P 的 Chai-1 预测比较

## 可以支持的结论

**本轮最一致的结果是 Q29P 对 IRAK4 29位附近主链构象的改变。整体复合物模型同时存在明显的预测质量限制，不能据此认定 Q29P 导致 Myddosome 组装障碍或结合减弱。**

- WT前三个候选模型没有被原始Chai评分标记大规模链间碰撞，并保留相当一部分3MOP实验结构中的接触；它们仍具有偏低的界面置信度。
- WT的rank 3、4和Q29P全部5个候选模型被Chai标记链间碰撞。主要问题是MyD88拷贝占据相近的空间位置，产生大量非物理的重原子重叠；这不是在P29侧链处发生的直接碰撞。
- WT全部20个IRAK4拷贝的Q29采用正φ角，Q29P全部20个拷贝的P29采用负φ角。局部主链改变与脯氨酸环状结构对构象的限制相符，但仍是预测结果。
- Q29/P29与IRAK2 W63的接触几何及对应两链的几何埋藏面积在本轮候选模型间有所不同。相关界面置信度偏低，且全复合物存在上述缺陷，因此只提出“局部界面几何可能重塑”的假说，不推断结合能、亲和力、组装效率或信号活性。

## 输入与样本核验

| 组分 | 全长编号范围 | 长度/链 | 拷贝数 | 原始Chai链ID |
|---|---|---:|---:|---|
| MyD88 DD | 20–117 | 98 | 6 | A–F |
| IRAK4 DD | 4–106 | 103 | 4 | G–J |
| IRAK2 DD | 2–112 | 111 | 4 | K–N |

每组一个提交任务、5个rank，共10个模型。所有模型均为14条链、1444个残基，140条链的长度及序列核验均通过。两组仅在IRAK4的全长29位不同；本次片段第26位对应Q29/P29。IRAK2两组均保留天然R50。

按用户确认，本轮protein输入、MMseqs2 MSA开启、templates开启、restraints关闭，其他采样设置相同。压缩包未包含seed编号、精确服务器checkpoint/软件版本、原始MSA、模板命中或完整任务请求；因此不能认定两组使用相同的具体MSA/模板，也不能把5个rank当作5次独立seed或生物学重复。

## 定量结果

下表为中位数（范围）。带*项目先对一个候选模型的4条IRAK4链/4个对应界面取中位数，再汇总5个模型；不是将20个拷贝作为20个独立重复。

| 指标 | WT | Q29P |
|---|---:|---:|
'''+ '\n'.join(table)+f'''
| 原始Chai链间碰撞标记 | 2/5 | 5/5 |

`data/`保留每个模型、每条链、每个界面的原始计算值；图内小点为各拷贝，大菱形为模型内中位数。没有进行显著性检验，也不将候选样本范围作为置信区间。

### 整体装配：部分参考接触被保留，但存在共同的预测失败模式

采用固定的核心Cα位点，同时穷举6!×4!×4!=414,720种同种蛋白拷贝置换，再进行仅含正旋转的Kabsch叠合。这样避免把任意链字母当作结构对应关系。

WT各候选模型相对3MOP的核心RMSD为{form(summary['WT']['reference_core_RMSD_A'])} Å，Q29P为{form(summary['Q29P']['reference_core_RMSD_A'])} Å。这里的全复合物RMSD不是29位的局部主链RMSD，也不是单个Cα的位移。

两组之间的25个候选模型对的核心RMSD为{form(summary['ensemble_RMSD']['WT-Q29P'])} Å；Q29P组内10个模型对为{form(summary['ensemble_RMSD']['Q29P-Q29P'])} Å，范围明显重叠。因此，整体候选模型之间的差别不能单独归因于突变。WT组内也有同样的MyD88重叠失败模式。

进一步将三个蛋白组分各自作为子装配，独立穷举其同种拷贝对应并刚性叠合到3MOP相同组分，得到以下核心Cα RMSD（Å，中位数及范围）：

| 子装配 | WT | Q29P |
|---|---:|---:|
{subtable}

本轮IRAK4和IRAK2四聚体子装配的参考偏差在两组相近；较大的组间区别集中在MyD88六聚体部分，但其中包含明确的预测重叠伪影，不能把它当作突变的远程结构效应。子装配的独立叠合会去掉组分间整体朝向差异，因此该指标与14链整体RMSD的含义不同。

以Q29P rank 0为例，原始链B/E这一对MyD88拷贝存在{int(q0['heavy_atom_pairs_lt1p5A'])}对距离小于1.5 Å的链间重原子。图3保留这些原始空间位置，以两种颜色直接显示重叠。不能将这种结构解释为真实“塌陷”“解聚”或失活，也不能将碰撞引起的接触数增多解释为结合增强。

PAE按具体原始链顺序读取，界面指标也单独保存。总体链间PAE会包含本来不相接触的链对，因此判断还结合了实际接触区PAE、链对ipTM、参考结构及几何重叠，而不是采用一个总体PAE阈值决定成败。即使WT rank 0–2未触发Chai的总体碰撞标记，也不等同于完整的全原子立体化学校验通过。

Chai的导出aggregate_score在本批数据中与`0.2×pTM + 0.8×ipTM − 100×clash_flag`复算相符。约−99.6的值包含碰撞惩罚，**不是能量、稳定性或亲和力**。本报告直接展示ipTM、PAE和碰撞标记，避免误读这个综合分数。

### 局部主链：29位构象改变较一致

两组的40条IRAK4链以共同51个核心残基叠合到3MOP链G；核心排除24–34窗口，并要求全部40个拷贝的核心残基pLDDT≥80。评价24–34的N、Cα、C、O主链原子，不直接混比Gln与Pro不同的侧链原子集合。

全部20个WT拷贝的φ角范围为{summary['WT']['local_phi_all20_copies']['min']:.1f}至{summary['WT']['local_phi_all20_copies']['max']:.1f}°；全部20个Q29P拷贝为{summary['Q29P']['local_phi_all20_copies']['min']:.1f}至{summary['Q29P']['local_phi_all20_copies']['max']:.1f}°。图4将局部叠合、真实φ/ψ分布、每残基位移和局部pLDDT放在一起。

在共同核心叠合坐标中，24–34窗口的WT–Q29P主链RMSD为{form(summary['local_pairwise_BB_RMSD_A']['WT-Q29P'])} Å；WT组内为{form(summary['local_pairwise_BB_RMSD_A']['WT-WT'])} Å，Q29P组内为{form(summary['local_pairwise_BB_RMSD_A']['Q29P-Q29P'])} Å。这些拷贝组合共享模型，数值高度相关，只描述本轮局部构象分布，不代表独立样本或统计显著性。

局部示意采用各组20个核心叠合后窗口构象的medoid，即与本组其他窗口的平均主链RMSD最小的实际拷贝；不是优化或重建的构象。选中WT rank 3/G与Q29P rank 4/H仅代表局部窗口，不代表它们的完整复合物可信。原始全复合物局限在图2–3同时展示。

局部核心pLDDT门槛为0、75、80时，局部RMSD差异方向一致；门槛90时仅剩1个共同核心残基，不足以确定刚性叠合，因此未报告该设置的RMSD。详细核验见`data/validation.json`。检查Pro29的N–CD环键和前一肽键ω角，并作排除3个以内共价键邻居的局部侧链非键合重叠检查；这些是局部诊断，**不是完整的MolProbity验证或构象概率评分**。

### IRAK4–IRAK2界面：可提出局部重塑假说，不能作功能定论

3MOP中IRAK4 29位邻近IRAK2的W63等残基。按经整体置换匹配的G–K、H–L、I–M、J–N四个位置，读取每个模型的实际IRAK4–IRAK2对应界面。界面图保持各模型两链的相对位置，只将两链整体按IRAK4核心刚性叠合。

本轮模型中，29位侧链至对应IRAK2 W63的最短重原子距离及两链BSA见上表。Gln和Pro的侧链化学组成和体积不同，因此距离变化部分反映残基本身的替换，不能据此声称丢失一条确定氢键。图内虚线仅标距离；被标注的最近原子对也可能是O–C或C–C，不是预先指定的供体/受体对。

BSA按`(SASA_IRAK4单链 + SASA_IRAK2单链 − SASA_两链)/2`定义，单位Å²。采用Shrake–Rupley、1.4 Å探针、480个球面点；限于IRAK4 4–106与IRAK2 2–94，以避免实验结构未解析的IRAK2尾部引入范围差异。它是给定两链位置下的几何埋藏，不包括结合自由能。选择性960点复核的结果见验证文件。

3MOP含IRAK2工程化R50W，而两组预测为天然R50。参考接触保留率采用双方共有可见残基，并排除IRAK2的50位；参考BSA仅作背景，因为其构建体序列仍不同。3MOP是3.4 Å的实验结构，原子间距离用于提出结构假说，也应受其分辨率和侧链不确定性约束。

## Figure索引与使用建议

| 文件 | 展示内容 | 建议用途 |
|---|---|---|
| Fig1_Myddosome_assembly_comparison | 3MOP、WT rank 0、Q29P rank 0的共同视角与轴向视图；29位和MyD88重叠标记 | 直观介绍预测装配及明显异常 |
| Fig2_Myddosome_confidence_and_variability | ipTM、参考RMSD/接触保留、链对PAE、组内与组间差异 | 判断整体装配解释的边界 |
| Fig3_Myddosome_steric_artifacts | WT/Q29P共享的MyD88重叠模式与全部候选的原子近距离统计 | 不把预测失败解释为突变机制 |
| Fig4_IRAK4_Q29P_local_conformation | 局部叠合、φ/ψ、残基位移与pLDDT | 本轮最可用的结构辅助结果 |
| Fig5_IRAK4_IRAK2_exploratory_interface | Q29/P29–W63实际局部界面、距离与条件性BSA | 探索性假说，需保留局限说明 |
| FigS1_all_candidate_assemblies | 全部10个候选的装配与碰撞标记 | 排除仅挑选单一漂亮模型的展示偏倚 |
| FigS2_all_candidate_PAE | 全部10个候选的完整PAE矩阵 | 置信度审阅 |

所有Figure提供300 dpi PNG和SVG；SVG中的3D结构为嵌入式栅格渲染，文字、标记、坐标轴及定量图为矢量。PyMOL会话、原始CIF/PAE/评分、全长编号坐标、数值表和脚本随包提供。原始输入保持不变，所有视图仅作刚性旋转。

## 对审稿回复的实际意义与下一步

1. **现在可使用的证据：**Q29P在多个候选中一致出现的局部主链改变，以及对应pLDDT、采样范围和方法说明。可与此前单体分析一起支持局部构象重塑的假说。
2. **整体复合物暂不用于证明功能：**保留图1–3作为模型质量与不确定性的完整记录；不将MyD88的非物理重叠写成Q29P导致的真实装配崩解。
3. **如果需要进一步的计算机制：**优先考虑在实验DD装配框架下，匹配WT/Q29P的局部界面建模与几何验证；若使用模板或约束，应两组一致，并保留突变附近的自由度。这类实验结构引导的建模也不能称为独立验证。
4. **如果需要证明组装或募集改变：**结合已有或可开展的IRAK4–IRAK2/MyD88相互作用、募集或复合物形成实验。ipTM、预测接触距离和BSA不能替代这些功能证据。

## 可供后续稿件采用的英文结果草稿

> Chai-1 predictions consistently indicated a local backbone rearrangement around IRAK4 residue 29. Across all four IRAK4 copies in each of five candidate models, WT Q29 adopted positive φ angles, whereas P29 adopted negative φ angles. Exploratory comparisons also suggested altered local geometry near the IRAK4–IRAK2 interface. However, all Q29P and two of five WT full-complex candidates contained severe spatial overlap between MyD88 copies, and interface confidence was limited. These predictions therefore support a hypothesis of local conformational remodeling but do not establish an effect on Myddosome assembly or binding affinity.

完整Methods和英文图注见`Figure_legends_and_methods.md`；正式写入稿件时需补充可获得的服务器版本、任务ID及采样参数，图号也需按最终稿调整。

## 复现与续作

在包含NumPy、SciPy、Biopython、OpenMM、PyMOL、Matplotlib、Pillow的Python环境中，从本目录的上层或任意工作目录运行：

```bash
python scripts/analyze_complex.py --stage all
python scripts/analyze_interfaces.py
python scripts/analyze_subassemblies.py
python scripts/validate_analysis.py
python scripts/render_figures.py
python scripts/compose_figures.py
python scripts/build_report.py
```

环境依赖版本记录于`environment.json`。`notes/progress.json`记录完成阶段和续作入口，`data/input_manifest.csv`记录原始文件校验值。原始两个ZIP中的32个文件均保留于`inputs/WT`与`inputs/Q29P`。

## 原始方法与参考来源

- Lin SC, Lo YC, Wu H. *Helical assembly in the MyD88–IRAK4–IRAK2 complex in TLR/IL-1R signalling.* Nature (2010). https://doi.org/10.1038/nature09121
- 实验结构3MOP，3.4 Å，6∶4∶4 DD装配：https://www.rcsb.org/structure/3MOP 。原始PDB的SEQADV明确记录IRAK2 R50W。
- Chai-1官方代码与方法入口：https://github.com/chaidiscovery/chai-lab 。本次具体预测来自用户提供的服务器导出文件，不是本地重新运行的预测。
'''
    (R/'Myddosome_Chai_run1_analysis.md').write_text(content)
    legends='''# Draft Methods and Figure Legends

## Structural prediction and analysis

Myddosome death-domain assemblies comprised six copies of human MyD88 residues 20–117, four copies of IRAK4 residues 4–106, and four copies of IRAK2 residues 2–112. The WT and Q29P assemblies differed only at IRAK4 residue 29; all four IRAK4 copies carried the designated allele. Both predictions used Chai-1 with MMseqs2 MSAs and templates enabled and user-specified restraints disabled, as reported by the operator. Five ranked candidates were exported for each of one submitted job per genotype. Exact seed identities, model checkpoint, software version and template/MSA hits were not included in the exports and should be added if retrievable.

All chain sequences and residue numbering were verified. Full-length residue numbering is used in derived tables and figures, while original CIFs retain fragment numbering. To compare assemblies with the experimental DD complex (PDB 3MOP), species-constrained chain correspondences were exhaustively enumerated over 6! × 4! × 4! permutations and evaluated by proper-rotation Kabsch fitting of Cα atoms. Analysis cores comprised MyD88 residues 25–110, IRAK4 residues 20–100 and IRAK2 residues 10–90 excluding residue 50 (1,160 Cα atoms per assembly). Component subassemblies were also evaluated with independent rigid fitting and exhaustive within-species copy matching. Reference-contact retention was evaluated using minimum interchain heavy-atom distances ≤4.5 Å over common experimentally observed residues, excluding IRAK2 residue 50 because 3MOP contains engineered R50W. Both prediction groups contained native IRAK2 R50.

Local IRAK4 comparisons used 51 shared core residues outside residues 24–34 with pLDDT ≥80 in all 40 predicted IRAK4 copies. The N, Cα, C and O atoms of residues 24–34 were evaluated after alignment to 3MOP chain G. Local representative conformers were actual within-group medoids of the aligned backbone windows. Per-chain dihedral angles, local confidence and displacement profiles were calculated directly from predicted coordinates. Four-copy medians were calculated for each candidate before reporting five-candidate descriptive summaries. No hypothesis tests were performed, and model/copy values were not treated as independent biological replicates.

Severe interchain proximity was independently summarized as the number of heavy-atom pairs separated by <1.5 Å, alongside the exported Chai clash flags. These counts are geometric diagnostics, not MolProbity clashscores. Conditional IRAK4–IRAK2 two-chain buried surface area was defined as half the difference between the summed isolated-chain SASA and pair SASA, using a 1.4 Å probe and 480-point Shrake–Rupley sampling over IRAK4 residues 4–106 and IRAK2 residues 2–94. Selected pairs were checked at 960 points. These measures describe the supplied geometry; they do not estimate binding energy or affinity. Structure images were rendered from unchanged coordinates with common rigid viewing transforms, cameras and scale within comparative views.

## Figure 1. Predicted Myddosome DD assemblies and experimental reference

Side and axial views of the experimentally determined Myddosome DD assembly (3MOP), WT rank 0 and Q29P rank 0. MyD88, IRAK4 and IRAK2 are blue, gold and purple, respectively. Red spheres mark the four IRAK4 Q29/P29 Cα atoms. Dashed outlines identify spatially overlapping MyD88 copies in the Q29P candidate. Comparative panels share a camera and scale within each view. IRAK2 residues 95–112, unresolved in 3MOP, are thin gray traces. The reference contains IRAK2 R50W; both prediction groups retain native R50. The overlapping copies are prediction artifacts and are not interpreted as a biological assembly phenotype.

## Figure 2. Confidence, reference agreement and ensemble variability

Candidate-level ipTM, copy-permuted core Cα RMSD to 3MOP and reference-contact retention are shown for all five candidates per genotype. Crosses identify exported Chai interchain-clash flags. Heatmaps show the median bidirectional PAE for each original chain pair in rank 0 candidates. Ensemble pairwise RMSDs use exhaustive species-constrained copy matching. Within-group and between-group pairs share model coordinates and are descriptive, not independent repeats or inferential tests.

## Figure 3. Nonphysical overlap between MyD88 copies

Contrasting colors show MyD88 chains B and E at their original predicted relative positions in WT rank 3 and Q29P rank 0. The chains were not fitted to one another. Severe interchain heavy-atom proximity (<1.5 Å) and the closest same-frame MyD88 core Cα RMSD are summarized for every candidate. This failure mode occurs in both genotypes and limits interpretation of whole-complex differences. Atom-pair counts are distinct from the internal Chai clash criterion and from MolProbity clashscores.

## Figure 4. Local IRAK4 conformation around Q29/P29

Local-chain medoids show the predicted backbone rearrangement at residues 24–34 after fitting on a shared 51-residue high-confidence core outside the evaluated window. WT and Q29P are blue and orange. The selected actual conformers are WT rank 3/chain G and Q29P rank 4/chain H; selection refers to the local window and does not validate their full assemblies. The double-headed arrow identifies a coordinate correspondence, not motion. Dihedral-angle distributions, per-residue displacement from experimental IRAK4 chain G and residue 29 pLDDT include all four IRAK4 copies per candidate. Small points represent copies and diamonds represent within-candidate medians. Profile shading spans all 20 model/copy values and is not a confidence interval. Experimental Q29 dihedrals from 3MOP chains G–J are included for context.

## Figure 5. Exploratory IRAK4–IRAK2 interface geometry

Experimental and actual rank-0 predicted local interfaces are shown after rigid alignment on the IRAK4 core. The corresponding 3MOP G–K position maps to original Chai chains J–M for WT rank 0 and G–M for Q29P rank 0. Dashed lines label the nearest residue-29 sidechain to IRAK2 W63 heavy-atom separation; atom identities differ between Gln and Pro, and no hydrogen-bond assignment is implied. All-copy separations and conditional two-chain geometric burial are shown. Predicted interface confidence is limited and all full Q29P assemblies contain remote MyD88 overlap; these panels illustrate an exploratory local-geometric hypothesis, not altered affinity or assembly function.

## Supplementary Figure 1. Complete candidate assembly atlas

All five candidates per genotype are shown at one common orientation and scale with their ipTM and original Chai clash flags. Red spheres mark IRAK4 Q29/P29. A negative clash flag is not a complete stereochemical validation.

## Supplementary Figure 2. Complete PAE atlas

All ten full residue-level PAE matrices are shown on the same 0–30 Å scale. Chains retain their original Chai order. Boundaries separate the six MyD88, four IRAK4 and four IRAK2 chains. These are confidence diagnostics, not affinity or energetic measurements.
'''
    (R/'Figure_legends_and_methods.md').write_text(legends)
    env={'python':sys.version,'platform':platform.platform(),'packages':{}}
    for name in ['numpy','scipy','biopython','matplotlib','pillow','openmm','pymol-open-source']:
        try:env['packages'][name]=importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:env['packages'][name]='not available as package metadata'
    (R/'environment.json').write_text(json.dumps(env,indent=2));print('REPORT_BUILT',flush=True)

if __name__=='__main__':main()
