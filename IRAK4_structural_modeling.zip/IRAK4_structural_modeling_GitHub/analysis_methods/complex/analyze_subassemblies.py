"""Decompose reference agreement into component subassemblies and local folds."""
import csv,json,itertools
import numpy as np
import analyze_complex as ac

R=ac.ROOT
def main():
    ref=ac.load_reference();rows=[];fold=[]
    fullmap={(r['group'],int(r['rank'])):json.loads(r['mapping']) for r in csv.DictReader((R/'data/reference_comparison.csv').open())}
    for g in ['WT','Q29P']:
        for rank in range(5):
            m=ac.load_model(g,rank)
            for species,ss in zip(['MyD88','IRAK4','IRAK2'],ac.SETS):
                ids=ac.CORE[species];x={c:ac.ca(m,c,ids) for c in ss};y={c:ac.ca(ref,c,ids) for c in ss}
                xa=np.concatenate(list(x.values()));ya=np.concatenate(list(y.values()));ax=xa.mean(0);ay=ya.mean(0)
                perms=list(itertools.permutations(ss));cov={(a,b):(x[a]-ax).T@(y[b]-ay) for a in ss for b in ss}
                cv=np.array([sum((cov[a,b] for a,b in zip(ss,p)),np.zeros((3,3))) for p in perms]);sv=np.linalg.svd(cv,compute_uv=False);score=sv.sum(1)-2*sv[:,-1]*(np.linalg.det(cv)<0);k=int(np.argmax(score));mp=dict(zip(ss,perms[k]));yp=np.concatenate([y[mp[c]] for c in ss]);rot,t=ac.fit(xa,yp)
                rows.append(dict(group=g,rank=rank,species=species,subassembly_core_CA_RMSD_to_3MOP_A=ac.rmsd(xa@rot+t,yp),n_matched_chains=len(ss),n_core_CA=len(xa),best_component_mapping=json.dumps(mp,sort_keys=True)))
                for c in ss:
                    rc=fullmap[g,rank][c];rot,t=ac.fit(x[c],y[rc]);fold.append(dict(group=g,rank=rank,chain=c,species=species,reference_chain=rc,single_chain_core_CA_RMSD_to_3MOP_A=ac.rmsd(x[c]@rot+t,y[rc])))
    ac.writecsv('component_subassembly_RMSD.csv',rows);ac.writecsv('single_chain_reference_RMSD.csv',fold)
    summary={g:{sp:ac.stats([r['subassembly_core_CA_RMSD_to_3MOP_A'] for r in rows if r['group']==g and r['species']==sp]) for sp in ['MyD88','IRAK4','IRAK2']} for g in ['WT','Q29P']}
    (R/'data/subassembly_summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
