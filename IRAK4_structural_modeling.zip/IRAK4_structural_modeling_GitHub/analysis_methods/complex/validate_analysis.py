"""Independent numerical and export checks, plus selected sensitivity analyses."""
import json,csv,sys
import numpy as np
from Bio.SVDSuperimposer import SVDSuperimposer
from Bio.PDB.SASA import ShrakeRupley
from Bio.PDB import PDBParser
import analyze_complex as ac
from analyze_interfaces import two_chain_bsa

R=ac.ROOT
def main():
    models=[ac.load_model(g,k) for g in ['WT','Q29P'] for k in range(5)];ref=ac.load_reference();report={}
    def read(name):return list(csv.DictReader((R/'data'/name).open()))
    maps={(r['group'],int(r['rank'])):json.loads(r['mapping']) for r in read('reference_comparison.csv')}
    check=[]
    for m in models:
        mp=maps[m['group'],m['rank']];x=np.concatenate([ac.ca(m,c,ac.CORE[ac.SPECIES[c]]) for c in ac.CHAINS]);y=np.concatenate([ac.ca(ref,mp[c],ac.CORE[ac.SPECIES[c]]) for c in ac.CHAINS]);rot,trans=ac.fit(x,y)
        fit=SVDSuperimposer();fit.set(y,x);fit.run();br,bt=fit.get_rotran();assert np.max(abs(br-rot))<1e-10 and np.max(abs(bt-trans))<1e-10
        p=PDBParser(QUIET=True).get_structure('out',str(R/'coordinates'/f'{m["group"]}_rank{m["rank"]}_reference_fit.pdb'))[0]
        assert len(list(p))==14
        xx=np.concatenate([np.array([p[mp[c]][i]['CA'].coord for i in ac.CORE[ac.SPECIES[c]]]) for c in ac.CHAINS]);err=float(np.max(abs(xx-(x@rot+trans))));assert err<.0006
        check.append(dict(group=m['group'],rank=m['rank'],max_coordinate_rounding_A=err,SVDSuperimposer_agrees=True))
    report['rigid_fits_and_PDB_exports']=check
    # Same local geometry evaluated with different confidence cutoffs.
    local=[]
    mc=[(m,c) for m in models for c in 'GHIJ']
    for cutoff in [0,75,80,90]:
        core=[i for i in range(20,105) if not 24<=i<=34 and all(m['conf'][c][i]>=cutoff for m,c in mc)]
        if len(core)<10:
            local.append(dict(cutoff=cutoff,n_core_residues=len(core),status='Insufficient shared core for a well-defined rigid fit; no RMSD reported'))
            continue
        vals={'WT':[],'Q29P':[]}
        for m,c in mc:
            rot,t=ac.fit(ac.ca(m,c,core),ac.ca(ref,'G',core));v=ac.rmsd(ac.points(m,c,list(range(24,35)))@rot+t,ac.points(ref,'G',list(range(24,35))));vals[m['group']].append(v)
        local.append(dict(cutoff=cutoff,n_core_residues=len(core),WT=ac.stats(vals['WT']),Q29P=ac.stats(vals['Q29P'])))
    report['local_core_sensitivity']=local
    # SASA discretization sensitivity, selected matched pair in each group.
    sasa=[]
    for g in ['WT','Q29P']:
        m=next(x for x in models if x['group']==g and x['rank']==0);inv={b:a for a,b in maps[g,0].items()};c,d=inv['G'],inv['K'];values={}
        for n in [480,960]:values[n]=two_chain_bsa(m,c,d,ShrakeRupley(probe_radius=1.4,n_points=n))[0]
        sasa.append(dict(group=g,rank=0,chain1=c,chain2=d,BSA_480_A2=values[480],BSA_960_A2=values[960],relative_difference=abs(values[480]-values[960])/values[960]))
    report['selected_SASA_resolution_check']=sasa
    ring=read('Pro29_ring_bond.csv');report['Pro29_N_CD_bond_A']=ac.stats([float(r['Pro29_N_CD_bond_A']) for r in ring])
    t=read('local_Q29_geometry.csv');report['Pro29_all_negative_phi']=all(float(r['phi_29_deg'])<0 for r in t if r['group']=='Q29P');report['WT29_all_positive_phi']=all(float(r['phi_29_deg'])>0 for r in t if r['group']=='WT');report['min_abs_preceding_omega_deg']=min(abs(float(r['preceding_omega_deg'])) for r in t)
    report['limits']='Selected local bond/overlap checks are not a full MolProbity or all-atom stereochemical validation. Confidence and geometric differences are descriptive; no significance tests.'
    (R/'data/validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
