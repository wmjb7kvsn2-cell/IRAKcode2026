"""PyMOL renderings of actual coordinates, with common rigid viewing transforms.

Global panels share camera and scale. The global alignment enumerates copy
permutations; displayed chain labels retain the original Chai identifiers.
Landmark-only passes provide exact projected annotation locations.
"""
from pathlib import Path
import csv,json,copy
import numpy as np
from PIL import Image
from Bio.PDB import PDBParser,PDBIO
from pymol import cmd
import analyze_complex as ac

R=ac.ROOT;P=R/'renders';S=R/'sessions';C=R/'coordinates'
for d in (P,S,C):d.mkdir(exist_ok=True)
W,H=1800,1800
COL={'MyD88':(.24,.49,.65),'IRAK4':(.86,.65,.29),'IRAK2':(.47,.43,.68),
     'WT':(.15,.44,.66),'Q29P':(.88,.40,.22),'reference':(.68,.72,.76),
     'copy1':(.50,.36,.66),'copy2':(.16,.65,.54),'target':(.80,.16,.20)}
meta={'panels':{},'coordinate_statement':'Original coordinates; only whole-structure rigid transformations and renumbering. No structural optimization or deformation.'}
parser=PDBParser(QUIET=True)

def unit(x):return x/np.linalg.norm(x)
def base(w=W,h=H):
    cmd.reinitialize();cmd.viewport(w,h);cmd.bg_color('white')
    for k,v in [('orthoscopic',1),('ray_shadows',0),('antialias',2),('specular',.12),('ray_opaque_background',1),('cartoon_fancy_helices',1),('cartoon_smooth_loops',1),('cartoon_sampling',20),('depth_cue',0),('ray_trace_fog',0),('cartoon_loop_radius',.18),('stick_radius',.15)]:cmd.set(k,v)
    for name,rgb in COL.items():cmd.set_color(name,rgb)
    cmd.set_color('nitrogen',(.18,.30,.66));cmd.set_color('oxygen',(.82,.18,.20));cmd.set_color('tail',(.78,.80,.82))

def save_rotation(src,dst,basis):
    st=parser.get_structure('x',str(src))
    for a in st.get_atoms():a.coord=a.coord@basis.T
    io=PDBIO();io.set_structure(st);io.save(str(dst))

def load(path,name):
    cmd.load(str(path),name);cmd.hide('everything',name);cmd.dss(name)

def component_style(obj,targets=True):
    cmd.show('cartoon',obj)
    for species,chains in [('MyD88','A+B+C+D+E+F'),('IRAK4','G+H+I+J'),('IRAK2','K+L+M+N')]:cmd.color(species,f'{obj} and chain {chains}')
    tail=f'{obj} and chain K+L+M+N and resi 95-112'
    cmd.color('tail',tail);cmd.cartoon('tube',tail);cmd.set('cartoon_tube_radius',.08,tail)
    if targets:
        ss=f'{obj} and chain G+H+I+J and resi 29 and name CA'
        cmd.show('spheres',ss);cmd.set('sphere_scale',.48,ss);cmd.color('target',ss)

def point(obj,chain,res,atom='CA'):
    return np.array(cmd.get_atom_coords(f'{obj} and chain {chain} and resi {res} and name {atom}'))

def render(name,anchors=None,w=W,h=H,session=True):
    cmd.png(str(P/(name+'.png')),width=w,height=h,dpi=300,ray=1)
    if session:cmd.save(str(S/(name+'.pse')))
    view=cmd.get_view();points={}
    if anchors:
        cmd.hide('everything','all');cmd.set('ambient',1);cmd.set('direct',0);cmd.set('specular',0)
        for key,pos in anchors.items():
            cmd.pseudoatom('_landmark',pos=list(map(float,pos)),vdw=.12);cmd.color('red','_landmark');cmd.show('spheres','_landmark');cmd.set('sphere_scale',1,'_landmark');cmd.set_view(view)
            fp=P/(name+'_'+key+'_landmark.png');cmd.png(str(fp),width=w//2,height=h//2,ray=1)
            arr=np.array(Image.open(fp).convert('RGB'));mask=(arr[:,:,0]>120)&(arr[:,:,1]<120)&(arr[:,:,2]<120);yy,xx=np.where(mask)
            if len(xx)<2:raise RuntimeError('Missing landmark '+name+' '+key)
            points[key]=[float(xx.mean()/(w//2)),float(1-yy.mean()/(h//2))]
            cmd.delete('_landmark')
    meta['panels'][name]={'anchors':points,'camera':list(view),'size':[w,h]}
    print('RENDERED',name,flush=True)

ref=parser.get_structure('ref',str(C/'3MOP_observed_input_segments.pdb'))[0]
centers={c:np.mean([ref[c][i]['CA'].coord for i in ac.CORE[ac.SPECIES[c]]],axis=0) for c in ac.CHAINS}
yy=unit(np.mean([centers[c] for c in 'KLMN'],axis=0)-np.mean([centers[c] for c in 'ABCDEF'],axis=0))
xx=centers['G']-centers['I'];xx=unit(xx-yy*np.dot(xx,yy));zz=np.cross(xx,yy)
basis=np.array([xx,yy,zz]);assert abs(np.linalg.det(basis)-1)<1e-5
top=np.array([xx,zz,-yy]);meta['assembly_basis']={'side':basis.tolist(),'top':top.tolist()}
sources={'3MOP':C/'3MOP_observed_input_segments.pdb'}
for g in ['WT','Q29P']:
    for rank in range(5):sources[g+str(rank)]=C/f'{g}_rank{rank}_aligned_original_chainIDs.pdb'
for n,src in sources.items():
    for side,b in [('side',basis),('top',top)]:save_rotation(src,C/f'view_{n}_{side}.pdb',b)

# Global reference/representative comparisons: one camera for all panels in a view.
for side in ['side','top']:
    base()
    for n in ['3MOP','WT0','Q29P0']:load(C/f'view_{n}_{side}.pdb',n)
    cmd.zoom('all and name CA and not (chain K+L+M+N and resi 95-112)',5);view=cmd.get_view()
    for n in ['3MOP','WT0','Q29P0']:
        base();load(C/f'view_{n}_{side}.pdb',n);component_style(n);cmd.set_view(view)
        anchors={'site29':point(n,'G',29)}
        if n=='Q29P0':
            anchors['overlap_BE']=(point(n,'B',65)+point(n,'E',65))/2
            anchors['overlap_CD']=(point(n,'C',65)+point(n,'D',65))/2
        render(n+'_'+side,anchors)
    # All ranks shown with a shared scale; no per-panel reorientation.
    if side=='side':
        for g in ['WT','Q29P']:
            for rank in range(5):
                n=g+str(rank);base(1200,1200);load(C/f'view_{n}_{side}.pdb',n);component_style(n);cmd.set_view(view)
                render('atlas_'+n,w=1200,h=1200,session=False)

# Actual overlapping MyD88 copies, shown in contrasting colors. No fitting of
# the two copies to each other: the collision is retained exactly as predicted.
for g,rank,c1,c2 in [('WT',3,'B','E'),('Q29P',0,'B','E')]:
    n=g+str(rank);base(1800,1300);load(C/f'view_{n}_side.pdb',n)
    cmd.remove(f'{n} and not chain {c1}+{c2}');cmd.show('cartoon',n)
    cmd.color('copy1',f'{n} and chain {c1}');cmd.color('copy2',f'{n} and chain {c2}');cmd.set('cartoon_transparency',.18,f'{n} and chain {c2}')
    cmd.zoom(n,4);render('overlap_'+n,{'copy1':point(n,c1,65),'copy2':point(n,c2,65)},w=1800,h=1300)

# Local IRAK4 backbone comparison. Medoids are selected objectively across all
# 20 copies per group, fitted outside residues 24-34 using the same 51-residue core.
st={g:parser.get_structure(g,str(C/f'IRAK4_local_medoid_{g}.pdb')) for g in ['WT','Q29P']}
cid={g:list(st[g][0])[0].id for g in st}
def localxyz(g,i,atom='CA'):return st[g][0][cid[g]][i][atom].coord.astype(float)
lx=unit(localxyz('Q29P',29)-localxyz('WT',29));v=localxyz('WT',34)-localxyz('WT',24);ly=unit(v-lx*np.dot(v,lx));lz=np.cross(lx,ly);lb=np.array([lx,ly,lz])
for g in st:
    save_rotation(C/f'IRAK4_local_medoid_{g}.pdb',C/f'local_view_{g}.pdb',lb)
save_rotation(C/'3MOP_observed_input_segments.pdb',C/'local_view_3MOP.pdb',lb)
base(2100,1600)
for g in ['WT','Q29P']:
    load(C/f'local_view_{g}.pdb',g);cmd.remove(f'{g} and not resi 18-48')
    cmd.show('cartoon',g);cmd.cartoon('tube',g);cmd.set('cartoon_tube_radius',.14,g);cmd.color(g,g)
    cmd.show('sticks',f'{g} and resi 29');cmd.color('nitrogen',f'{g} and resi 29 and elem N');cmd.color('oxygen',f'{g} and resi 29 and elem O')
    cmd.show('spheres',f'{g} and resi 29 and name CA');cmd.set('sphere_scale',.23,f'{g} and resi 29 and name CA')
cmd.zoom('all and resi 26-32',4.5)
render('local_overlay',{'WT_CA':point('WT',cid['WT'],29),'Q29P_CA':point('Q29P',cid['Q29P'],29),'P28':point('WT',cid['WT'],28),'E30':point('WT',cid['WT'],30)},w=2100,h=1600)

# Conditional IRAK4--IRAK2 interface geometry: actual rank-0 subassemblies.
# Rigid alignment is by the IRAK4 core only; no relative chain motion is applied.
maps={}
for row in csv.DictReader((R/'data/reference_comparison.csv').open()):maps[row['group'],int(row['rank'])]=json.loads(row['mapping'])
refmodel=ac.load_reference();core=json.loads((R/'data/local_alignment.json').read_text())['fit_core_full_numbering']
pairfiles={};pairs={}
for g in ['3MOP','WT','Q29P']:
    m=refmodel if g=='3MOP' else ac.load_model(g,0)
    mapping={c:c for c in ac.CHAINS} if g=='3MOP' else maps[g,0];inv={b:a for a,b in mapping.items()};c,d=inv['G'],inv['K'];pairs[g]=(c,d)
    rr,tt=ac.fit(ac.ca(m,c,core),ac.ca(refmodel,'G',core));fp=C/f'interface_{g}_fitted.pdb';ac.save_full_numbering(m,fp,rr,tt)
    pairfiles[g]=fp
# Face the sidechain interface, preserving depth and all coordinates.
r29=refmodel['res']['G'][29];w63=refmodel['res']['K'][63]
iv=unit(w63['CG'].coord-r29['CA'].coord);jv=r29['CA'].coord-refmodel['res']['G'][25]['CA'].coord;jv=unit(jv-iv*np.dot(jv,iv));kv=np.cross(iv,jv);ib=np.array([iv,jv,kv])
for g,pth in pairfiles.items():save_rotation(pth,C/f'interface_view_{g}.pdb',ib)
base(1800,1500)
for g in pairfiles:
    load(C/f'interface_view_{g}.pdb',g);c,d=pairs[g]
    cmd.remove(f'{g} and not ((chain {c} and resi 20-40) or (chain {d} and resi 54-69))')
cmd.zoom('all and (resi 29 or resi 62-63)',4.5);iview=cmd.get_view()
drows=list(csv.DictReader((R/'data/Q29_interface_distances.csv').open()))
for g in pairfiles:
    base(1800,1500);load(C/f'interface_view_{g}.pdb',g);c,d=pairs[g]
    cmd.remove(f'{g} and not ((chain {c} and resi 20-40) or (chain {d} and resi 54-69))');cmd.show('cartoon',g);cmd.color('reference',g);cmd.set('cartoon_transparency',.25,g)
    col='reference' if g=='3MOP' else g
    for ch,res,color in [(c,'29',col),(d,'63','IRAK2')]:
        sel=f'{g} and chain {ch} and resi {res}';cmd.show('sticks',sel);cmd.color(color,sel+' and elem C');cmd.color('nitrogen',sel+' and elem N');cmd.color('oxygen',sel+' and elem O')
    row=next(x for x in drows if x['group']==g and int(x['rank'])==(-1 if g=='3MOP' else 0) and x['IRAK4_reference_position']=='G' and x['partner_full_residue']=='63')
    a1=row['target_atom'];a2=row['partner_atom'];s1=f'{g} and chain {c} and resi 29 and name {a1}';s2=f'{g} and chain {d} and resi 63 and name {a2}'
    cmd.distance('distance',s1,s2);cmd.hide('labels','distance');cmd.set('dash_color','grey45','distance');cmd.set('dash_width',2,'distance');cmd.set('dash_gap',.18,'distance');cmd.set('dash_length',.13,'distance')
    cmd.set_view(iview)
    render('interface_'+g,{'site29':point(g,c,29,'CG' if g!='Q29P' else 'CB'),'W63':point(g,d,63,'CZ3'),'distance':(point(g,c,29,a1)+point(g,d,63,a2))/2},w=1800,h=1500)
    meta['panels']['interface_'+g]['distance_row']=row

(R/'figure_metadata.json').write_text(json.dumps(meta,indent=2));print('ALL_RENDERINGS_FINISHED',flush=True)
cmd.quit()
