"""Publication figures with genuinely editable vector molecular geometry.

No images are embedded in SVG/PDF. Source measurements are preserved in
source_data, with figure-specific CSVs under source_data/figure_panels.
"""
from pathlib import Path
import argparse,csv,json,io,os,copy
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle,Ellipse
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.text import Text
from matplotlib.collections import QuadMesh
from PIL import Image
import vector_structures as vs

ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'source_data';F=ROOT/'figures';PAN=ROOT/'panels'
W,Q,D=vs.WT,vs.Q29P,vs.D320Y;COL={'WT':W,'Q29P':Q,'D320Y':D};BLACK='#202B36';GRAY='#6C7780'
PAE=LinearSegmentedColormap.from_list('pae_accessible',['#245D83','#6CA5AC','#DDE5D0','#ECD09A','#C2715A'])
FORMATS=['png','svg','pdf']
plt.rcParams.update({'font.family':'Nimbus Sans','font.size':7,'axes.labelsize':7,'axes.titlesize':7.5,'axes.linewidth':.65,'axes.edgecolor':'#84909A','axes.labelcolor':BLACK,'text.color':BLACK,'xtick.color':BLACK,'ytick.color':BLACK,'xtick.labelsize':6.5,'ytick.labelsize':6.5,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'ps.fonttype':42,'legend.fontsize':6.5,'lines.linewidth':1.1})

def read(scope,name):
    with (SRC/scope/name).open() as f:return list(csv.DictReader(f))
def export(name,rows):
    rows=list(rows)
    if not rows:return
    p=SRC/'figure_panels'/name;keys=list(dict.fromkeys(k for r in rows for k in r))
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)

MON_Q=read('monomer','model_quality.csv');MON_P=read('monomer','all_pairwise_comparisons.csv');TOR=read('monomer','local_torsions.csv');DIST=read('monomer','selected_distances.csv')
CX_Q=read('complex','model_quality.csv');CX_PAIRS=read('complex','chain_pair_metrics.csv');CX_REF=read('complex','reference_comparison.csv');CX_LOCAL=read('complex','local_Q29_geometry.csv')
MON_META=json.loads((ROOT/'reference/monomer_figure_metadata.json').read_text());CX_META=json.loads((ROOT/'reference/complex_figure_metadata.json').read_text())
M={n:vs.load_pdb(ROOT/'coordinates/monomer'/f'{n}_view.pdb') for n in ['qwt','q0','q1','dwt','dy']}
CX={g+str(k):vs.load_pdb(ROOT/'coordinates/complex'/f'{g}_rank{k}_aligned_original_chainIDs.pdb') for g in ['WT','Q29P'] for k in range(5)}
CX['3MOP']=vs.load_pdb(ROOT/'coordinates/complex/3MOP_observed_input_segments.pdb')

def panel(fig,box,letter,title):
    x,y,w,h=box;fig.text(x-.025,y+h+.016,letter,fontsize=10,fontweight='bold');fig.text(x+.005,y+h+.019,title,fontsize=7.5,fontweight='bold')
def axat(fig,box):return fig.add_axes(box)
def grid(ax):ax.grid(axis='y',color='#E5E9EC',lw=.45);ax.set_axisbelow(True)
def foot(fig,text):fig.text(.035,.012,text,fontsize=6.1,color=GRAY)

def save(fig,name,png_only=False,directory=F):
    directory.mkdir(exist_ok=True)
    for text in fig.findobj(match=Text):text.set_text(text.get_text().replace('–','-').replace('—','-'))
    for mesh in fig.findobj(match=QuadMesh):
        mesh.set_edgecolor('face');mesh.set_linewidth(.05);mesh.set_antialiased(False)
    for fmt in (['png'] if png_only else FORMATS):
        buf=io.BytesIO();fig.savefig(buf,format=fmt,dpi=600 if name=='Figure_8' else 450,facecolor='white')
        data=buf.getvalue()
        if fmt=='png':Image.open(io.BytesIO(data)).verify()
        if fmt=='svg':
            assert b'<image' not in data and b'<text' in data
        tmp=directory/(name+'.'+fmt+'.tmp');tmp.write_bytes(data);os.replace(tmp,directory/(name+'.'+fmt))
    plt.close(fig);print('FIGURE',name,flush=True)

def q_scene(fig,box,mut='q1',labels=True):
    ax=axat(fig,box);pr=[];focus=[]
    for name,color in [('qwt',W),(mut,Q)]:
        mol=M[name];pr+=vs.trace_primitives(mol,'A',18,48,color,highlight=(24,34),radius=.13)
        pr+=vs.residue_primitives(mol,'A',29,color,radius=.085);pr.append(vs.ca_marker(mol,'A',29,color,.18))
        focus += [vs.xyz(mol,'A',i) for i in range(24,35)] + list(mol['A'][29]['atoms'].values())
    bounds=vs.bounds_for(focus,pad=2.0);vs.draw_scene(ax,pr,bounds)
    if labels:
        vs.label(ax,vs.xyz(M['qwt'],'A',29,'CD'),'WT Q29',(.02,.83))
        vs.label(ax,vs.xyz(M[mut],'A',29,'CG'),'Q29P P29',(.69,.13))
    return ax

def d_scene(fig,box,show=('dwt','dy'),labels=True,distances=False):
    ax=axat(fig,box);pr=[];focus=[]
    for name in show:
        mol=M[name];color=W if name=='dwt' else D
        pr+=vs.trace_primitives(mol,'A',307,331,color,highlight=(315,325),radius=.13)
        pr+=vs.residue_primitives(mol,'A',320,color,radius=.085);pr.append(vs.ca_marker(mol,'A',320,color,.18))
        focus += [vs.xyz(mol,'A',i) for i in range(315,326)]+list(mol['A'][320]['atoms'].values())
    for residue in [265,324]:
        # Neighbor atoms from the first displayed actual model, without moving
        # them to accommodate the other model.
        pr+=vs.residue_primitives(M[show[0]],'A',residue,'#7D8B96',radius=.075,balls=False)
        focus+=list(M[show[0]]['A'][residue]['atoms'].values())
    bounds=vs.bounds_for(focus,pad=2.1);vs.draw_scene(ax,pr,bounds)
    if labels:
        if not distances and 'dwt' in show:vs.label(ax,vs.xyz(M['dwt'],'A',320,'CG'),'WT D320',(.01,.49))
        if not distances and 'dy' in show:vs.label(ax,vs.xyz(M['dy'],'A',320,'CZ'),'D320Y Y320',(.74,.13))
        vs.label(ax,vs.xyz(M[show[0]],'A',265,'SD'),'M265',(.71,.74))
        vs.label(ax,vs.xyz(M[show[0]],'A',324,'OG1'),'T324',(.08,.09))
    if distances and len(show)==1:
        name=show[0];group='WT' if name=='dwt' else 'D320Y'
        for partner,at in [(265,(.38,.90)),(324,(.72,.56))]:
            row=next(r for r in DIST if r['group']==group and r['rank']=='0' and r['target']=='320' and int(r['partner'])==partner)
            p=vs.xyz(M[name],'A',320,row['target_sc_atom']);q=vs.xyz(M[name],'A',partner,row['partner_sc_atom'])
            assert abs(np.linalg.norm(p-q)-float(row['sidechain_sidechain_min_A']))<.004
            vs.distance(ax,p,q);mid=(p+q)/2
            ax.text(mid[0]+.35,mid[1]+.35,f"{float(row['sidechain_sidechain_min_A']):.2f} Å",fontsize=6.5,zorder=25,bbox={'boxstyle':'round,pad=.1','fc':'white','ec':'none','alpha':.92})
    return ax

def rmsd_rows(ax,comparisons):
    exportrows=[]
    for y,(domain,comparison,label,color) in enumerate(comparisons):
        rows=[r for r in MON_P if r['domain']==domain and r['group_pair']==comparison];vals=[float(r['target_backbone_RMSD_A']) for r in rows]
        yy=y+np.linspace(-.14,.14,len(vals));ax.scatter(vals,yy,s=9,color=color,alpha=.60,linewidths=0)
        med=np.median(vals);ax.plot([min(vals),max(vals)],[y,y],color=color,lw=.75);ax.plot([med,med],[y-.23,y+.23],color=BLACK,lw=1.3)
        ax.text(1.16,y,f'{med:.2f}',va='center',ha='left',fontsize=6.7)
        exportrows += [dict(display_row=label,**r) for r in rows]
    ax.set_yticks(range(len(comparisons)),[r[2] for r in comparisons]);ax.set_ylim(len(comparisons)-.5,-.5);ax.set_xlim(0,1.13);ax.set_xlabel('Local backbone RMSD (Å)');ax.grid(axis='x',color='#E5E9EC',lw=.45);ax.set_axisbelow(True)
    return exportrows

def split_bounds(kind):
    names=['qwt','q1'] if kind=='Q29P' else ['dwt','dy'];points=[]
    for name in names:
        mol=M[name]
        points += [vs.xyz(mol,'A',i) for i in (range(24,35) if kind=='Q29P' else range(315,326))]
        for residue in ([29] if kind=='Q29P' else [320,265,324]):points+=list(mol['A'][residue]['atoms'].values())
    return vs.bounds_for(points,pad=2.4)

def q_single_scene(fig,box,name,bounds=None):
    mol=M[name];color=W if name=='qwt' else Q;ax=axat(fig,box)
    pr=vs.trace_primitives(mol,'A',18,48,color,highlight=(24,34),radius=.15)
    pr+=vs.residue_primitives(mol,'A',29,color,radius=.095)
    pr.append(vs.ca_marker(mol,'A',29,color,.19));vs.draw_scene(ax,pr,bounds or split_bounds('Q29P'))
    vs.label(ax,vs.xyz(mol,'A',29,'CG'),'Q29' if name=='qwt' else 'P29',(.04,.58),size=7.4)
    return ax

def d_single_scene(fig,box,name,bounds=None):
    mol=M[name];color=W if name=='dwt' else D;group='WT' if name=='dwt' else 'D320Y';ax=axat(fig,box)
    pr=vs.trace_primitives(mol,'A',307,331,color,highlight=(315,325),radius=.15)
    pr+=vs.residue_primitives(mol,'A',320,color,radius=.095)
    pr.append(vs.ca_marker(mol,'A',320,color,.19))
    for residue in [265,324]:pr+=vs.residue_primitives(mol,'A',residue,'#788996',radius=.085,balls=False)
    vs.draw_scene(ax,pr,bounds or split_bounds('D320Y'))
    vs.label(ax,vs.xyz(mol,'A',320,'CG'),'D320' if name=='dwt' else 'Y320',(.02,.44),size=7.4)
    vs.label(ax,vs.xyz(mol,'A',265,'SD'),'M265',(.73,.80),size=7.2)
    vs.label(ax,vs.xyz(mol,'A',324,'OG1'),'T324',(.05,.07),size=7.2)
    for partner in [265,324]:
        row=next(r for r in DIST if r['group']==group and r['rank']=='0' and r['target']=='320' and int(r['partner'])==partner)
        p=vs.xyz(mol,'A',320,row['target_sc_atom']);q=vs.xyz(mol,'A',partner,row['partner_sc_atom'])
        assert abs(np.linalg.norm(p-q)-float(row['sidechain_sidechain_min_A']))<.004
        vs.distance(ax,p,q);mid=(p+q)/2
        ax.text(mid[0]+.45,mid[1]+.25,f"{float(row['sidechain_sidechain_min_A']):.2f} Å",fontsize=7,zorder=25,bbox={'boxstyle':'round,pad=.1','fc':'white','ec':'none','alpha':.94})
    return ax

def split_pair(fig,kind,box,subtitles=True):
    x,y,w,h=box;bounds=split_bounds(kind)
    names=['qwt','q1'] if kind=='Q29P' else ['dwt','dy']
    for j,name in enumerate(names):
        b=[x+j*w*.53,y,w*.47,h];color=W if j==0 else (Q if kind=='Q29P' else D)
        (q_single_scene if kind=='Q29P' else d_single_scene)(fig,b,name,bounds)
        if subtitles:
            title=('WT  |  rank 0' if j==0 else ('Q29P  |  rank 1' if kind=='Q29P' else 'D320Y  |  rank 0'))
            fig.text(b[0]+b[2]/2,y+h+.008,title,ha='center',fontsize=8,color=color,fontweight='bold')
        if kind=='Q29P':
            group='WT' if name=='qwt' else 'Q29P';rank='0' if name=='qwt' else '1'
            row=next(r for r in TOR if r['group']==group and r['rank']==rank and r['residue']=='29')
            fig.text(b[0]+b[2]/2,y-.012,f"φ {float(row['phi_deg']):+.1f}°   ψ {float(row['psi_deg']):+.1f}°",ha='center',fontsize=7.1,color=color)

def main_figure(png_only=False):
    fig=plt.figure(figsize=(7.205,8.35))
    box=[.08,.88,.85,.065];panel(fig,box,'A','IRAK4 domains and variant positions');ax=axat(fig,box);ax.set_axis_off();ax.set_xlim(-8,470);ax.set_ylim(-.55,1.2)
    ax.add_patch(Rectangle((1,0),459,.25,color='#DDE2E6',ec='none'));ax.add_patch(Rectangle((20,0),84,.25,color='#B8D0DE',ec='none'));ax.add_patch(Rectangle((186,0),268,.25,color='#D9C9DC',ec='none'))
    ax.text(62,.125,'DD',ha='center',va='center',fontsize=7);ax.text(320,.125,'Kinase domain',ha='center',va='center',fontsize=7)
    for x,name,color in [(29,'Q29P',Q),(320,'D320Y',D)]:ax.plot([x,x],[.27,.64],color=color,lw=1.2);ax.scatter([x],[.26],s=12,color=color,zorder=3);ax.text(x,.78,name,ha='center',va='center',fontsize=7)
    ax.text(1,-.27,'1',fontsize=6.7);ax.text(460,-.27,'460',ha='right',fontsize=6.7)
    b=[.055,.565,.89,.245];panel(fig,b,'B','Death domain around residue 29');split_pair(fig,'Q29P',b)
    b=[.055,.265,.89,.225];panel(fig,b,'C','Kinase domain around residue 320');split_pair(fig,'D320Y',b)
    fig.text(.07,.235,'Dashed lines: minimum sidechain-to-sidechain distances; not assigned hydrogen bonds.',fontsize=6.2,color=GRAY)
    b=[.20,.064,.69,.12];panel(fig,b,'D','Local comparisons across all candidate pairs')
    rows=rmsd_rows(axat(fig,b),[('DD','WT-WT','DD 24–34: WT–WT',W),('DD','WT-Q29P','DD 24–34: WT–Q29P',Q),('KD','WT-WT','KD 315–325: WT–WT',W),('KD','WT-D320Y','KD 315–325: WT–D320Y',D)])
    export('Figure_8D.csv',rows)
    export('Figure_8B_angles.csv',[r for r in TOR if r['residue']=='29' and ((r['group']=='WT' and r['rank']=='0') or (r['group']=='Q29P' and r['rank']=='1'))])
    export('Figure_8C_distances.csv',[r for r in DIST if r['target']=='320' and r['rank']=='0' and r['group'] in ['WT','D320Y'] and r['partner'] in ['265','324']])
    foot(fig,'Within each pair: same view and scale. D: median and range; candidate pairs share models; no inferential test.')
    save(fig,'Figure_8',png_only)

def binned_pae(group):
    # Raw files are recovered from the original saved analysis package.
    frozen=SRC/'figure_panels'/('S7_PAE_'+group+'.csv')
    if frozen.exists():
        rows=list(csv.DictReader(frozen.open()));a=np.zeros((46,46))
        for row in rows:a[(int(row['row_bin_start'])-1)//10,(int(row['column_bin_start'])-1)//10]=float(row['median_then_binned_PAE_A'])
        return a
    base=ROOT/'prediction_outputs/monomer'/group
    if not base.exists():base=ROOT.parents[1]/'recovered_chai_integration/analysis/IRAK4_Chai_run1/inputs'/group
    p=np.median(np.array([np.load(base/f'pae.rank_{k}.npy',allow_pickle=False) for k in range(5)]),axis=0)
    bins=p.reshape(46,10,46,10).mean(axis=(1,3))
    export('S7_PAE_'+group+'.csv',[dict(row_bin_start=i*10+1,column_bin_start=j*10+1,median_then_binned_PAE_A=bins[i,j]) for i in range(46) for j in range(46)])
    return bins

def supplementary_7(png_only=False):
    fig=plt.figure(figsize=(7.205,8.10))
    b=[.08,.79,.86,.145];panel(fig,b,'A','Confidence profiles of the full-length monomer predictions');ax=axat(fig,b)
    rows=[r for r in read('monomer','aligned_per_residue.csv') if r['domain_fit']=='DD'];export('S7A.csv',rows)
    for g in ['WT','Q29P','D320Y']:
        mat=np.array([[float(r['pLDDT']) for r in rows if r['group']==g and int(r['rank'])==k] for k in range(5)])
        assert mat.shape==(5,460);ax.fill_between(range(1,461),mat.min(0),mat.max(0),color=COL[g],alpha=.14,lw=0);ax.plot(range(1,461),np.median(mat,axis=0),color=COL[g],label=g,lw=1)
    for lo,hi in [(20,104),(186,454)]:ax.axvspan(lo,hi,color='#E8ECEF',alpha=.4,zorder=0)
    for x in [29,320]:ax.axvline(x,color=GRAY,ls=':',lw=.65)
    ax.set_xlim(1,460);ax.set_ylim(0,100);ax.set_ylabel('pLDDT');ax.set_xlabel('IRAK4 residue');ax.legend(frameon=False,ncol=3,loc='lower right',fontsize=6.5);grid(ax)
    im=None
    for col,g in enumerate(['WT','Q29P','D320Y']):
        b=[.055+col*.32,.405,.265,.245];panel(fig,b,chr(66+col),g+' median PAE');ax=axat(fig,b);im=ax.pcolormesh(np.arange(47),np.arange(47),binned_pae(g),cmap=PAE,vmin=0,vmax=30,shading='flat',rasterized=False);ax.invert_yaxis();ax.set_aspect('equal')
        ax.set_xticks([0,10,20,30,40,46],['1','100','200','300','400','460'],fontsize=5.8);ax.set_yticks([0,10,20,30,40,46],['1','100','200','300','400','460'],fontsize=5.8)
        for x in [10.4,18.6]:ax.axvline(x,color='white',lw=.7);ax.axhline(x,color='white',lw=.7)
    cax=fig.add_axes([.24,.365,.52,.012]);cb=fig.colorbar(im,cax=cax,orientation='horizontal',label='PAE (Å); 10-residue bins after candidate median');cb.solids.set_rasterized(False)
    b=[.075,.10,.385,.17];panel(fig,b,'E','Confidence at the two evaluated sites');ax=axat(fig,b);xs=[];labels=[]
    for j,pos in enumerate([29,320]):
        for k,g in enumerate(['WT','Q29P','D320Y']):
            x=k+j*4;vals=[float(r[f'pLDDT_{pos}']) for r in MON_Q if r['group']==g];ax.scatter(x+np.linspace(-.10,.10,5),vals,color=COL[g],s=16,linewidths=0);ax.plot([x-.22,x+.22],[np.median(vals)]*2,color=COL[g],lw=1.3);xs.append(x);labels.append(g)
    ax.set_xticks(xs,labels,rotation=40,ha='right',fontsize=6);ax.set_ylabel('pLDDT');ax.set_ylim(65,98);ax.axvline(3,color='#D9DFE4',lw=.8);ax.text(.12,.04,'Residue 29',transform=ax.transAxes,fontsize=6.5);ax.text(.64,.04,'Residue 320',transform=ax.transAxes,fontsize=6.5);grid(ax);export('S7E.csv',MON_Q)
    b=[.62,.10,.29,.17];panel(fig,b,'F','Evaluated and opposite-site windows');rows=rmsd_rows(axat(fig,b),[('DD','WT-WT','DD WT–WT',W),('DD','WT-Q29P','DD WT–Q29P',Q),('DD','WT-D320Y','DD WT–D320Y',D),('KD','WT-WT','KD WT–WT',W),('KD','WT-Q29P','KD WT–Q29P',Q),('KD','WT-D320Y','KD WT–D320Y',D)]);export('S7F.csv',rows)
    foot(fig,'Five ranked candidates per sequence; profiles show median and full range. DD–KD placement has high PAE.')
    save(fig,'Supplementary_Figure_S7',png_only)

def supplementary_8(png_only=False):
    fig=plt.figure(figsize=(7.205,8.10))
    for col,mut in enumerate(['q0','q1']):
        b=[.04+col*.51,.67,.43,.25];panel(fig,b,chr(65+col),'Q29P '+('rank 0 alternative' if mut=='q0' else 'rank 1, shared by ranks 1–4'));ax=q_scene(fig,b,mut)
        row=next(r for r in TOR if r['group']=='Q29P' and r['rank']==('0' if mut=='q0' else '1') and r['residue']=='29');fig.text(b[0]+.01,b[1]-.016,f"P29 φ {float(row['phi_deg']):+.1f}°; ψ {float(row['psi_deg']):+.1f}°",fontsize=6.4)
    b=[.085,.385,.36,.17];panel(fig,b,'C','Residue 29 dihedral angles');ax=axat(fig,b);rows=[r for r in TOR if r['residue']=='29' and r['group'] in ['WT','Q29P']]
    for g in ['WT','Q29P']:
        rr=[r for r in rows if r['group']==g];ax.scatter([float(r['phi_deg']) for r in rr],[float(r['psi_deg']) for r in rr],s=23,color=COL[g],label=g,edgecolors='white',linewidths=.5)
    rr=next(r for r in rows if r['group']=='Q29P' and r['rank']=='0');ax.annotate('rank 0',xy=(float(rr['phi_deg']),float(rr['psi_deg'])),xytext=(-105,139),arrowprops={'arrowstyle':'-','lw':.6},fontsize=6.5)
    ax.set_xlim(-120,90);ax.set_ylim(-5,155);ax.set_xlabel('φ (degrees)');ax.set_ylabel('ψ (degrees)');ax.legend(frameon=False,loc='upper right');ax.grid(color='#E5E9EC',lw=.45);ax.set_axisbelow(True);export('S8C.csv',rows)
    b=[.60,.385,.34,.17];panel(fig,b,'D','Kinase-site sidechain proximity');ax=axat(fig,b);rows=[r for r in DIST if r['target']=='320' and r['group'] in ['WT','D320Y']]
    for j,partner in enumerate([265,267,324]):
        for k,g in enumerate(['WT','D320Y']):
            vals=[float(r['sidechain_sidechain_min_A']) for r in rows if r['group']==g and int(r['partner'])==partner];x=j+(k-.5)*.25;ax.scatter(x+np.linspace(-.045,.045,5),vals,color=COL[g],s=17,linewidths=0);ax.plot([x-.10,x+.10],[np.median(vals)]*2,color=COL[g],lw=1.25)
    ax.set_xticks(range(3),['M265','N267','T324']);ax.set_ylabel('Minimum SC–SC distance (Å)');ax.set_ylim(3,6.8);grid(ax);export('S8D.csv',rows)
    for col,name in enumerate(['dwt','dy']):
        b=[.04+col*.51,.06,.43,.235];panel(fig,b,chr(69+col),('WT D320' if name=='dwt' else 'D320Y Y320')+' local geometry');d_scene(fig,b,(name,),distances=True)
    foot(fig,'Dashed lines are measured separations, not assigned hydrogen bonds. Shorter distances do not establish stronger interactions.')
    save(fig,'Supplementary_Figure_S8',png_only)

def complex_models():
    basis=np.array(CX_META['assembly_basis']['side'])
    return {n:vs.transform(m,basis.T) for n,m in CX.items()}

def complex_scene(fig,box,mol,bounds,mark_clash=False):
    ax=axat(fig,box);pr=[]
    for c in sorted(mol):
        sp='MyD88' if c in 'ABCDEF' else 'IRAK4' if c in 'GHIJ' else 'IRAK2';color={'MyD88':'#377BA0','IRAK4':'#C99A43','IRAK2':'#8276AC'}[sp]
        lo,hi=min(mol[c]),max(mol[c]);pr+=vs.trace_primitives(mol,c,lo,hi,color,radius=.33,samples=5,highlight=(lo,94) if sp=='IRAK2' else None)
        if sp=='IRAK4':pr.append(vs.ca_marker(mol,c,29,'#BD4448',.75))
    vs.draw_scene(ax,pr,bounds,fast=True,shadow=False)
    if mark_clash:
        p=(vs.xyz(mol,'B',65)+vs.xyz(mol,'E',65))/2;ax.add_patch(Ellipse(p[:2],12,12,fill=False,ec='#B54848',lw=.8,ls='--',zorder=15))
        vs.label(ax,p,'MyD88 overlap',(.01,.10),size=6.1)
    return ax

def group_dots(ax,rows,key,nested=False,ylabel='',ylim=None,clash=False):
    for j,g in enumerate(['WT','Q29P']):
        sub=[r for r in rows if r['group']==g];med=[]
        for k in range(5):
            vals=[float(r[key]) for r in sub if int(r['rank'])==k];x=j+(k-2)*.065
            if nested:
                ax.scatter(x+np.linspace(-.015,.015,len(vals)),vals,color=COL[g],s=8,alpha=.40,linewidths=0);v=float(np.median(vals));ax.scatter([x],[v],marker='D',s=16,color=COL[g],edgecolors='white',linewidths=.35,zorder=3)
            else:
                v=vals[0];ax.scatter([x],[v],s=21,color=COL[g],edgecolors='white',linewidths=.4,zorder=3)
            if clash:
                q=next(r for r in CX_Q if r['group']==g and int(r['rank'])==k)
                if q['chai_clash_flag']=='True':ax.scatter([x],[v],marker='x',color=BLACK,s=13,linewidths=.65,zorder=4)
            med.append(v)
        ax.plot([j-.22,j+.22],[np.median(med)]*2,color=COL[g],lw=1.4)
    ax.set_xticks([0,1],['WT','Q29P']);ax.set_xlim(-.4,1.4);ax.set_ylabel(ylabel);grid(ax)
    if ylim:ax.set_ylim(ylim)

def chain_pae(g):
    a=np.zeros((14,14));rows=read('complex','chain_quality.csv')
    for r in rows:
        if r['group']==g and r['rank']=='0':i=ord(r['chain'])-65;a[i,i]=float(r['intra_PAE_median_A'])
    for r in CX_PAIRS:
        if r['group']==g and r['rank']=='0':i=ord(r['chain1'])-65;j=ord(r['chain2'])-65;a[i,j]=a[j,i]=float(r['pair_PAE_median_A'])
    export('S9_PAE_'+g+'.csv',[dict(chain1=chr(65+i),chain2=chr(65+j),median_PAE_A=a[i,j]) for i in range(14) for j in range(14)])
    return a

def supplementary_9(png_only=False):
    fig=plt.figure(figsize=(7.205,8.30));models=complex_models();focus=[]
    for n in ['3MOP','WT0','Q29P0']:
        for c in models[n]:focus.extend(vs.xyz(models[n],c,i) for i in models[n][c] if 'CA' in models[n][c][i]['atoms'])
    bounds=vs.bounds_for(focus,pad=3.5)
    for col,(n,title) in enumerate([('3MOP','3MOP reference'),('WT0','WT rank 0'),('Q29P0','Q29P rank 0')]):
        b=[.04+col*.322,.66,.29,.27];panel(fig,b,chr(65+col),title);complex_scene(fig,b,models[n],bounds,mark_clash=n=='Q29P0')
    fig.legend(handles=[Line2D([],[],color='#377BA0',label='MyD88'),Line2D([],[],color='#C99A43',label='IRAK4'),Line2D([],[],color='#8276AC',label='IRAK2'),Line2D([],[],marker='o',color='none',markerfacecolor='#BD4448',label='Q29/P29',markersize=3)],loc='upper center',bbox_to_anchor=(.51,.654),ncol=4,frameon=False,handlelength=1.4,columnspacing=.8)
    b=[.075,.39,.23,.16];panel(fig,b,'D','Interface confidence');group_dots(axat(fig,b),CX_Q,'ipTM',ylabel='ipTM',ylim=(.36,.445),clash=True);export('S9D.csv',CX_Q)
    b=[.405,.39,.235,.16];panel(fig,b,'E','Severe atom overlap');ax=axat(fig,b);vals=[];rows=[]
    for g in ['WT','Q29P']:
        for k in range(5):v=sum(int(r['heavy_atom_pairs_lt1p5A']) for r in CX_PAIRS if r['group']==g and int(r['rank'])==k);vals.append(v);rows.append(dict(group=g,rank=k,heavy_atom_pairs_lt1p5A=v))
    xx=np.r_[np.arange(5),np.arange(5)+6];ax.bar(xx,vals,color=[W]*5+[Q]*5,width=.75);ax.set_xticks([2,8],['WT','Q29P']);ax.set_ylabel('Atom pairs <1.5 Å');ax.set_ylim(0,1500);grid(ax);export('S9E.csv',rows)
    b=[.735,.39,.23,.16];panel(fig,b,'F','Candidate variation');ax=axat(fig,b);rows=read('complex','ensemble_pairwise_RMSD.csv')
    for j,(g,h,label,col) in enumerate([('WT','WT','WT–WT',W),('WT','Q29P','WT–Q29P',GRAY),('Q29P','Q29P','Q29P–Q29P',Q)]):
        vals=[float(r['core_CA_RMSD_A']) for r in rows if r['group1']==g and r['group2']==h];ax.scatter(j+np.linspace(-.13,.13,len(vals)),vals,color=col,s=10,alpha=.6,linewidths=0);ax.plot([j-.2,j+.2],[np.median(vals)]*2,color=BLACK,lw=1.2)
    ax.set_xticks([0,1,2],['WT–WT','WT–Q29P','Q29P–Q29P'],rotation=35,ha='right',fontsize=5.8);ax.set_ylabel('Core Cα RMSD (Å)');ax.set_ylim(0,12);grid(ax);export('S9F.csv',rows)
    im=None
    for j,g in enumerate(['WT','Q29P']):
        b=[.115+j*.49,.075,.29,.23];panel(fig,b,chr(71+j),g+' rank 0 chain-pair PAE');ax=axat(fig,b);im=ax.pcolormesh(np.arange(15),np.arange(15),chain_pae(g),cmap=PAE,vmin=0,vmax=30,shading='flat',rasterized=False);ax.invert_yaxis();ax.set_aspect('equal');ax.set_xticks(np.arange(14)+.5,list('ABCDEFGHIJKLMN'),fontsize=5.2);ax.set_yticks(np.arange(14)+.5,list('ABCDEFGHIJKLMN'),fontsize=5.2)
        for x in [6,10]:ax.axvline(x,color='white',lw=.7);ax.axhline(x,color='white',lw=.7)
    cax=fig.add_axes([.27,.045,.46,.010]);cb=fig.colorbar(im,cax=cax,orientation='horizontal');cb.solids.set_rasterized(False);cb.ax.tick_params(labelsize=6,pad=2,length=2);fig.text(.75,.048,'PAE (Å)',fontsize=6.2)
    foot(fig,'× in D: Chai clash flag. All Q29P and two WT candidates have nonphysical MyD88-copy overlap.')
    save(fig,'Supplementary_Figure_S9',png_only)

def local_complex_models():
    out={g:vs.load_pdb(ROOT/'coordinates/complex'/f'IRAK4_local_medoid_{g}.pdb') for g in ['WT','Q29P']};cs={g:next(iter(out[g])) for g in out}
    x=vs.unit(vs.xyz(out['Q29P'],cs['Q29P'],29)-vs.xyz(out['WT'],cs['WT'],29));v=vs.xyz(out['WT'],cs['WT'],34)-vs.xyz(out['WT'],cs['WT'],24);y=vs.unit(v-x*np.dot(v,x));z=np.cross(x,y);b=np.array([x,y,z])
    return {g:vs.transform(m,b.T) for g,m in out.items()},cs

def interface_models():
    ref=CX['3MOP'];core=json.loads((SRC/'complex/local_alignment.json').read_text())['fit_core_full_numbering'];maps={(r['group'],int(r['rank'])):json.loads(r['mapping']) for r in CX_REF};out={};chains={}
    x=vs.unit(vs.xyz(ref,'K',63,'CG')-vs.xyz(ref,'G',29));v=vs.xyz(ref,'G',29)-vs.xyz(ref,'G',25);y=vs.unit(v-x*np.dot(v,x));z=np.cross(x,y);basis=np.array([x,y,z])
    for g in ['WT','Q29P']:
        mol=CX[g+'0'];inv={b:a for a,b in maps[g,0].items()};c,d=inv['G'],inv['K'];x=np.array([vs.xyz(mol,c,i) for i in core]);y=np.array([vs.xyz(ref,'G',i) for i in core]);rot,t=vs.fit(x,y);out[g]=vs.transform(vs.transform(mol,rot,t),basis.T);chains[g]=(c,d)
    return out,chains

def supplementary_10(png_only=False):
    fig=plt.figure(figsize=(7.205,8.10));mol,cs=local_complex_models();b=[.045,.67,.425,.25];panel(fig,b,'A','IRAK4 local folds within DD complexes');ax=axat(fig,b);pr=[];points=[]
    for g in ['WT','Q29P']:
        c=cs[g];pr+=vs.trace_primitives(mol[g],c,18,48,COL[g],highlight=(24,34),radius=.13);pr+=vs.residue_primitives(mol[g],c,29,COL[g],radius=.085);points.extend(vs.xyz(mol[g],c,i) for i in range(24,35));points.extend(mol[g][c][29]['atoms'].values())
    vs.draw_scene(ax,pr,vs.bounds_for(points,pad=2.0));vs.label(ax,vs.xyz(mol['WT'],cs['WT'],29,'CD'),'WT Q29',(.02,.82));vs.label(ax,vs.xyz(mol['Q29P'],cs['Q29P'],29,'CG'),'Q29P P29',(.66,.14))
    b=[.60,.70,.33,.19];panel(fig,b,'B','Residue 29 across prediction contexts');ax=axat(fig,b);exportrows=[]
    for j,(context,g) in enumerate([('Monomer','WT'),('Monomer','Q29P'),('Complex','WT'),('Complex','Q29P')]):
        if context=='Monomer':rows=[dict(group=r['group'],rank=r['rank'],phi_deg=float(r['phi_deg']),context=context) for r in TOR if r['residue']=='29' and r['group']==g]
        else:rows=[dict(group=r['group'],rank=r['rank'],chain=r['chain'],phi_deg=float(r['phi_29_deg']),context=context) for r in CX_LOCAL if r['group']==g]
        vals=[r['phi_deg'] for r in rows];ax.scatter(j+np.linspace(-.13,.13,len(vals)),vals,s=9,color=COL[g],alpha=.5,linewidths=0)
        for k in range(5):
            v=np.median([r['phi_deg'] for r in rows if int(r['rank'])==k]);ax.scatter([j+(k-2)*.05],[v],s=14,marker='D',color=COL[g],edgecolors='white',linewidths=.3,zorder=3)
        exportrows+=rows
    ax.set_xticks(range(4),['WT\nmono','Q29P\nmono','WT\ncomplex','Q29P\ncomplex'],fontsize=5.8);ax.set_ylim(-110,80);ax.set_ylabel('φ (degrees)');grid(ax);export('S10B.csv',exportrows)
    interfaces,pairs=interface_models();points=[]
    for g in interfaces:
        c,d=pairs[g];points+=list(interfaces[g][c][29]['atoms'].values())+list(interfaces[g][d][63]['atoms'].values())
    bounds=vs.bounds_for(points,pad=4)
    drows=[r for r in read('complex','Q29_interface_distances.csv') if r['partner_full_residue']=='63']
    for j,g in enumerate(['WT','Q29P']):
        b=[.045+j*.51,.345,.425,.23];panel(fig,b,chr(67+j),g+' rank 0 IRAK4–IRAK2 interface');ax=axat(fig,b);m=interfaces[g];c,d=pairs[g]
        pr=vs.trace_primitives(m,c,20,40,vs.CONTEXT,radius=.13)+vs.trace_primitives(m,d,54,69,vs.CONTEXT,radius=.13)
        pr+=vs.residue_primitives(m,c,29,COL[g],radius=.09)+vs.residue_primitives(m,d,63,'#8572AE',radius=.09);vs.draw_scene(ax,pr,bounds)
        row=next(r for r in drows if r['group']==g and r['rank']=='0' and r['IRAK4_reference_position']=='G');p=vs.xyz(m,c,29,row['target_atom']);q=vs.xyz(m,d,63,row['partner_atom']);assert abs(np.linalg.norm(p-q)-float(row['min_target_SC_partner_heavy_A']))<.005
        vs.distance(ax,p,q,f"{float(row['min_target_SC_partner_heavy_A']):.2f} Å",(.62,.81));vs.label(ax,vs.xyz(m,c,29,'CG'),'Q29' if g=='WT' else 'P29',(.03,.82));vs.label(ax,vs.xyz(m,d,63,'CZ3'),'IRAK2 W63',(.62,.12))
    b=[.09,.10,.35,.15];panel(fig,b,'E','29-site sidechain to IRAK2 W63');group_dots(axat(fig,b),drows,'min_target_SC_partner_heavy_A',nested=True,ylabel='Minimum distance (Å)',ylim=(2.2,5.2));export('S10E.csv',drows)
    b=[.60,.10,.33,.15];panel(fig,b,'F','Conditional pair burial');rows=read('complex','IRAK4_IRAK2_pair_BSA.csv');group_dots(axat(fig,b),rows,'pair_BSA_half_total_loss_A2',nested=True,ylabel='Pair BSA (Å²)',ylim=(390,570));export('S10F.csv',rows)
    foot(fig,'Exploratory geometry only. Dots: copies; diamonds: candidate medians. Distance/BSA are not affinity or assembly measurements.')
    save(fig,'Supplementary_Figure_S10',png_only)

def standalone_panels():
    PAN.mkdir(exist_ok=True)
    for name,kind in [('Figure_8B_Q29P','Q29P'),('Figure_8C_D320Y','D320Y')]:
        fig=plt.figure(figsize=(7.205,3.1));split_pair(fig,kind,[.035,.09,.93,.80]);buf=io.BytesIO();fig.savefig(buf,format='svg',facecolor='white');data=buf.getvalue();assert b'<image' not in data;(PAN/(name+'.svg')).write_bytes(data);plt.close(fig)
    for name,kind,model in [('Figure_8B_WT_Q29','Q29P','qwt'),('Figure_8B_Q29P_P29','Q29P','q1'),('Figure_8C_WT_D320','D320Y','dwt'),('Figure_8C_D320Y_Y320','D320Y','dy')]:
        fig=plt.figure(figsize=(3.5,3.1));(q_single_scene if kind=='Q29P' else d_single_scene)(fig,[.035,.07,.93,.84],model,split_bounds(kind));fig.text(.5,.96,{'qwt':'WT Q29 | rank 0','q1':'Q29P P29 | rank 1','dwt':'WT D320 | rank 0','dy':'D320Y Y320 | rank 0'}[model],ha='center',fontsize=9,fontweight='bold');buf=io.BytesIO();fig.savefig(buf,format='svg',facecolor='white');data=buf.getvalue();assert b'<image' not in data;(PAN/(name+'.svg')).write_bytes(data);plt.close(fig)
    fig=plt.figure(figsize=(3.8,3.0));q_scene(fig,[.025,.025,.95,.95],'q0');buf=io.BytesIO();fig.savefig(buf,format='svg',facecolor='white');(PAN/'Q29P_rank0_alternative.svg').write_bytes(buf.getvalue());plt.close(fig)
    print('Standalone editable panels written',flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--only',choices=['main','S7','S8','S9','S10']);ap.add_argument('--png-only',action='store_true');ap.add_argument('--vector-only',action='store_true');args=ap.parse_args()
    if args.vector_only:FORMATS=['svg','pdf']
    tasks={'main':main_figure,'S7':supplementary_7,'S8':supplementary_8,'S9':supplementary_9,'S10':supplementary_10}
    for name,fn in tasks.items():
        if args.only is None or args.only==name:fn(args.png_only)
    if not args.png_only:standalone_panels()
