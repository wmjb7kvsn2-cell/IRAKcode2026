"""Validate vector exports and the numerical claims used in the revision."""
from pathlib import Path
import collections,csv,json,xml.etree.ElementTree as ET
import numpy as np
import fitz

ROOT=Path(__file__).resolve().parents[1]

def read(scope,name):
    with (ROOT/'source_data'/scope/name).open() as f:return list(csv.DictReader(f))

def main():
    (ROOT/'notes').mkdir(exist_ok=True)
    report={'status':'pass','SVG':[],'PDF':[],'numerical_claims':[]}
    for p in sorted(list((ROOT/'figures').glob('*.svg'))+list((ROOT/'panels').glob('*.svg'))):
        tree=ET.parse(p);elements=list(tree.getroot().iter());ids=[x.attrib['id'] for x in elements if 'id' in x.attrib]
        images=[x for x in elements if x.tag.endswith('}image')];texts=[x for x in elements if x.tag.endswith('}text')]
        repeated=[k for k,n in collections.Counter(ids).items() if n>1]
        assert not images and texts and not repeated,(p.name,len(images),repeated[:3])
        report['SVG'].append({'file':str(p.relative_to(ROOT)),'embedded_images':0,'editable_text_nodes':len(texts),'duplicate_ids':0})
    pdfs=sorted((ROOT/'figures').glob('*.pdf'))
    combined=ROOT/'Chai_Supplementary_Figures_S7-S10.pdf'
    if combined.exists(): pdfs.append(combined)
    for p in pdfs:
        doc=fitz.open(p);images=sum(len(page.get_images(full=True)) for page in doc)
        assert images==0 and all(page.get_text().strip() for page in doc)
        report['PDF'].append({'file':str(p.relative_to(ROOT)),'pages':len(doc),'embedded_images':images,'fonts':[list(f) for f in doc[0].get_fonts()]})
    assert len(report['SVG'])==12 and len(report['PDF'])>=5
    pairs=read('monomer','all_pairwise_comparisons.csv')
    for domain,label,expected,n in [('DD','WT-Q29P',.8084297884256425,25),('DD','WT-WT',.3726157377028032,10),('KD','WT-D320Y',.8503510883782107,25),('KD','WT-WT',.16950337231585016,10)]:
        vals=[float(r['target_backbone_RMSD_A']) for r in pairs if r['domain']==domain and r['group_pair']==label]
        assert len(vals)==n and abs(float(np.median(vals))-expected)<1e-5
        report['numerical_claims'].append({'domain':domain,'comparison':label,'median_A':float(np.median(vals)),'range_A':[min(vals),max(vals)],'n_shared_model_pairs':n})
    quality=read('complex','model_quality.csv')
    report['complex_clash_flags']={g:sum(r['chai_clash_flag']=='True' for r in quality if r['group']==g) for g in ['WT','Q29P']}
    assert report['complex_clash_flags']=={'WT':2,'Q29P':5}
    local=read('complex','local_Q29_geometry.csv')
    assert all(float(r['phi_29_deg'])<0 for r in local if r['group']=='Q29P')
    assert all(float(r['phi_29_deg'])>0 for r in local if r['group']=='WT')
    report['visual_QA']={'main_and_supplementary_PNGs':'All five inspected','Word_pages':'Response/insertion text: four pages; legends: two pages, rendered and inspected','combined_supplement_PDF':'Four pages rendered and inspected'}
    (ROOT/'notes/integration_validation.json').write_text(json.dumps(report,indent=2))
    print(f"Validated {len(report['SVG'])} editable SVGs, {len(report['PDF'])} image-free PDFs and numerical claims.")

if __name__=='__main__':main()
