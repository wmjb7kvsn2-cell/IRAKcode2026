"""Reconstruct original analysis layouts without changing archived measurements.

After extracting Supplementary Data 1-3 to the same directory:
  python scripts/prepare_reanalysis.py
  python scripts/prepare_reanalysis.py --run

--run requires numpy, scipy, biopython and openmm. It performs coordinate
analysis only; it does not submit new Chai jobs or optimize any structure.
The exhaustive complex correspondence step can be computationally expensive.
"""
from pathlib import Path
import argparse,shutil,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');args=ap.parse_args()
    for scope,name in [('monomer','IRAK4_Chai_run1'),('complex','Myddosome_Chai_run1')]:
        source=ROOT/'prediction_outputs'/scope
        if not source.is_dir():raise SystemExit('Extract Supplementary Data 1-3 together first.')
        target=ROOT/'reproduced_analyses'/name
        for sub in ['scripts','data','inputs','reference','coordinates','figures','aligned_structures']:(target/sub).mkdir(parents=True,exist_ok=True)
        for p in (ROOT/'analysis_methods'/scope).glob('*.py'):shutil.copy2(p,target/'scripts'/p.name)
        shutil.copytree(ROOT/'source_data'/scope,target/'data',dirs_exist_ok=True)
        shutil.copytree(source,target/'inputs',dirs_exist_ok=True)
        if scope=='complex':shutil.copytree(ROOT/'reference',target/'reference',dirs_exist_ok=True)
        if args.run:
            commands=[['analyze_chai.py','--inputs',str(target/'inputs')],['check_robustness.py','--inputs',str(target/'inputs')]] if scope=='monomer' else [['analyze_complex.py','--stage','all'],['analyze_interfaces.py'],['analyze_subassemblies.py'],['validate_analysis.py']]
            for command in commands:subprocess.run([sys.executable,str(target/'scripts'/command[0]),*command[1:]],check=True,cwd=target)
        print('Prepared',target,flush=True)
    print('Frozen source_data and prediction_outputs were preserved.')

if __name__=='__main__':main()
