"""Editable coordinate-derived molecular illustrations with no raster images.

Backbones are interpolating C-alpha traces. Selected residues are shown with
their original heavy-atom coordinates and explicit covalent connectivity.
Orthographic projection, rigid rotations and depth shading are display-only.
"""
from pathlib import Path
import copy
import numpy as np
from scipy.interpolate import CubicSpline
from matplotlib.lines import Line2D
from matplotlib.collections import LineCollection
from matplotlib.patches import Circle
from matplotlib.colors import to_rgb

WT='#2873A6';Q29P='#D97937';D320Y='#986399';CONTEXT='#B8C1C8'
ELEMENT={'N':'#35549A','O':'#C94642','S':'#BD9D36'}
BB=[('N','CA'),('CA','C'),('C','O')]
BONDS={
 'GLN':BB+[('CA','CB'),('CB','CG'),('CG','CD'),('CD','OE1'),('CD','NE2')],
 'PRO':BB+[('CA','CB'),('CB','CG'),('CG','CD'),('CD','N')],
 'ASP':BB+[('CA','CB'),('CB','CG'),('CG','OD1'),('CG','OD2')],
 'TYR':BB+[('CA','CB'),('CB','CG'),('CG','CD1'),('CG','CD2'),('CD1','CE1'),('CD2','CE2'),('CE1','CZ'),('CE2','CZ'),('CZ','OH')],
 'MET':BB+[('CA','CB'),('CB','CG'),('CG','SD'),('SD','CE')],
 'THR':BB+[('CA','CB'),('CB','OG1'),('CB','CG2')],
 'TRP':BB+[('CA','CB'),('CB','CG'),('CG','CD1'),('CG','CD2'),('CD1','NE1'),('NE1','CE2'),('CD2','CE2'),('CD2','CE3'),('CE2','CZ2'),('CE3','CZ3'),('CZ2','CH2'),('CZ3','CH2')]
}

def load_pdb(path):
    out={}
    for line in Path(path).read_text().splitlines():
        if line[:6].strip() not in ('ATOM','HETATM') or line[16] not in (' ','A'):continue
        chain=line[21];i=int(line[22:26]);name=line[12:16].strip();element=line[76:78].strip() or name[0]
        if element=='H':continue
        rec=out.setdefault(chain,{}).setdefault(i,{'name':line[17:20].strip(),'atoms':{},'elements':{}})
        rec['atoms'][name]=np.array([float(line[30:38]),float(line[38:46]),float(line[46:54])]);rec['elements'][name]=element
    return out

def transform(m,rotation,translation=None):
    n=copy.deepcopy(m)
    for c in n.values():
        for r in c.values():
            for k,p in r['atoms'].items():r['atoms'][k]=p@rotation+(0 if translation is None else translation)
    return n

def xyz(m,c,i,a='CA'):return m[c][i]['atoms'][a]
def fit(x,y):
    a=x.mean(0);b=y.mean(0);u,s,vt=np.linalg.svd((x-a).T@(y-b));d=np.eye(3);d[-1,-1]=np.linalg.det(u@vt);r=u@d@vt;return r,b-a@r
def unit(v):return v/np.linalg.norm(v)

def trace_primitives(m,c,lo,hi,color,highlight=None,radius=.15,context=True,samples=7):
    ids=[i for i in sorted(m[c]) if lo<=i<=hi and 'CA' in m[c][i]['atoms']]
    if len(ids)<2:return []
    blocks=[];block=[]
    for i in ids:
        if block and (i!=block[-1]+1 or np.linalg.norm(xyz(m,c,i)-xyz(m,c,block[-1]))>5.1):blocks.append(block);block=[]
        block.append(i)
    if block:blocks.append(block)
    result=[]
    for ids in blocks:
        if len(ids)<2:continue
        pts=np.array([xyz(m,c,i) for i in ids]);ts=np.r_[0,np.cumsum(np.linalg.norm(np.diff(pts,axis=0),axis=1))]
        cs=CubicSpline(ts,pts,axis=0);assert np.max(abs(cs(ts)-pts))<1e-9
        tt=np.linspace(ts[0],ts[-1],(len(ids)-1)*samples+1);zz=cs(tt);res=np.interp(tt,ts,ids)
        for k in range(len(tt)-1):
            mid=(res[k]+res[k+1])/2;focused=(highlight is None or highlight[0]<=mid<=highlight[1]);col=color if focused else CONTEXT
            result.append(dict(kind='line',p=zz[k:k+2],color=col,radius=radius if focused else radius*.50,alpha=1 if focused else .62,depth=float(zz[k:k+2,2].mean())))
    return result

def residue_primitives(m,c,i,color,radius=.095,balls=True):
    res=m[c][i];atoms=res['atoms'];els=res['elements'];result=[]
    for a,b in BONDS[res['name']]:
        if a not in atoms or b not in atoms:continue
        pa,pb=atoms[a],atoms[b];assert np.linalg.norm(pa-pb)<1.95
        pm=(pa+pb)/2
        for p,q,name in [(pa,pm,a),(pm,pb,b)]:
            result.append(dict(kind='line',p=np.array([p,q]),color=ELEMENT.get(els[name],color),radius=radius,alpha=1,depth=float((p[2]+q[2])/2)))
    if balls:
        for name,p in atoms.items():
            result.append(dict(kind='ball',p=p,color=ELEMENT.get(els[name],color),radius=radius*1.52,alpha=1,depth=float(p[2])))
    return result

def draw_scene(ax,primitives,bounds,fast=False,shadow=True):
    xmin,xmax,ymin,ymax=bounds;ax.set_xlim(xmin,xmax);ax.set_ylim(ymin,ymax);ax.set_aspect('equal',adjustable='box');ax.set_axis_off()
    box=ax.get_position();fig=ax.figure
    scale=min(fig.get_figwidth()*72*box.width/(xmax-xmin),fig.get_figheight()*72*box.height/(ymax-ymin))
    depths=[p['depth'] for p in primitives];lo=min(depths);span=max(max(depths)-lo,1.)
    prefix='molecule_axes_'+str(ax.figure.axes.index(ax))
    def shaded(p):
        f=.75+.30*(p['depth']-lo)/span;return tuple(np.clip(np.array(to_rgb(p['color']))*f,0,1))
    if fast:
        pp=sorted([p for p in primitives if p['kind']=='line'],key=lambda p:p['depth'])
        lc=LineCollection([p['p'][:,:2] for p in pp],colors=[shaded(p) for p in pp],linewidths=[2*p['radius']*scale for p in pp],alpha=1,capstyle='round',joinstyle='round');lc.set_gid(prefix+'_coordinate_derived_backbone');ax.add_collection(lc)
        for p in sorted([p for p in primitives if p['kind']=='ball'],key=lambda p:p['depth']):ax.add_patch(Circle(p['p'][:2],p['radius'],facecolor=shaded(p),edgecolor='white',lw=.35,zorder=10))
        return
    # One shadow pass prevents dark seams at each interpolated trace segment.
    if shadow:
        for p in sorted([x for x in primitives if x['kind']=='line'],key=lambda x:x['depth']):
            col=shaded(p);x,y=p['p'][:,:2].T;w=2*p['radius']*scale
            ax.add_line(Line2D(x,y,lw=w+.42,color=tuple(np.array(col)*.57),solid_capstyle='round',alpha=p['alpha']))
    for k,p in enumerate(sorted(primitives,key=lambda x:x['depth'])):
        col=shaded(p)
        if p['kind']=='line':
            x,y=p['p'][:,:2].T;w=2*p['radius']*scale
            line=Line2D(x,y,lw=w,color=col,solid_capstyle='round',alpha=p['alpha']);line.set_gid(prefix+'_bond_or_backbone_segment_'+str(k));ax.add_line(line)
        else:
            ball=Circle(p['p'][:2],p['radius'],facecolor=col,edgecolor=tuple(np.array(col)*.6),lw=.35);ball.set_gid(prefix+'_heavy_atom_'+str(k));ax.add_patch(ball)
            ax.add_patch(Circle(p['p'][:2]+np.array([-.22,.24])*p['radius'],p['radius']*.42,facecolor=tuple(.60*np.array(col)+.40),edgecolor='none',alpha=.65))

def bounds_for(points,pad=2.,aspect=None):
    pts=np.array(points);x0,y0=pts[:,:2].min(0);x1,y1=pts[:,:2].max(0);x0-=pad;x1+=pad;y0-=pad;y1+=pad
    if aspect:
        cx=(x0+x1)/2;cy=(y0+y1)/2
        if (x1-x0)/(y1-y0)<aspect:
            w=(y1-y0)*aspect;x0=cx-w/2;x1=cx+w/2
        else:
            h=(x1-x0)/aspect;y0=cy-h/2;y1=cy+h/2
    return (float(x0),float(x1),float(y0),float(y1))

def label(ax,point,text,at,color='#202C38',size=7,ha='left'):
    ax.annotate(text,xy=np.asarray(point)[:2],xycoords='data',xytext=at,textcoords='axes fraction',ha=ha,va='center',fontsize=size,color=color,arrowprops={'arrowstyle':'-','color':color,'lw':.65,'connectionstyle':'angle3,angleA=0,angleB=90'},bbox={'boxstyle':'round,pad=.15','fc':'white','ec':'none','alpha':.9})

def ca_marker(m,c,i,color,radius=.20):
    p=xyz(m,c,i);return dict(kind='ball',p=p,color=color,radius=radius,alpha=1,depth=float(p[2]))

def distance(ax,p,q,text=None,at=None):
    p,q=np.asarray(p),np.asarray(q);ax.plot([p[0],q[0]],[p[1],q[1]],color='#4C5864',lw=.8,ls=(0,(2,2)),zorder=20)
    if text:label(ax,(p+q)/2,text,at or (.6,.75),size=6.7)
