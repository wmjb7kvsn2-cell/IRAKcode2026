# IRAK4 structural modelling and Chai-1 downstream analysis

This repository contains the custom Python code, analysis definitions, derived source tables, reference sequences/coordinates, and figure-generation scripts used for the IRAK4 WT, Q29P and D320Y structural analyses in the revised manuscript.

**Scope:** downstream analysis of exported Chai-1 structures and confidence files, coordinate-based comparisons, quality-control diagnostics, and publication-figure generation. This repository does **not** contain a Chai-1 inference engine and does not itself submit prediction jobs. It does not perform molecular dynamics (MD), energy minimization, binding-free-energy calculations, or infer binding affinity.

## Analyses represented

1. **Full-length IRAK4 monomers:** five ranked Chai-1 models each for WT, Q29P and D320Y; sequence verification, pLDDT/PAE summaries, local torsions, residue-neighbour distances, local steric diagnostics and pairwise structural comparisons.
2. **Myddosome death-domain assemblies:** five ranked candidates each for WT and Q29P, using six MyD88 chains, four IRAK4 chains and four IRAK2 chains (6:4:4). Analyses include chain-copy matching against PDB 3MOP, confidence summaries, local Q29/P29 geometry, inter-chain proximity diagnostics and conditional pairwise SASA geometry.
3. **Publication figures:** editable vector figures generated from supplied coordinates and archived source tables.

## Repository layout

- `analysis_methods/monomer/` — original monomer analysis and robustness scripts.
- `analysis_methods/complex/` — original Myddosome assembly, interface, subassembly, validation and reporting scripts.
- `analysis_methods/local_polished/` — legacy PyMOL-dependent local rendering scripts retained for provenance.
- `scripts/` — reanalysis preparation, integrated figure generation and validation utilities.
- `source_data/` — archived derived numerical tables, method definitions, and audit summaries.
- `coordinates/` — rigidly aligned coordinate files used for the supplied structural visualizations; original prediction coordinates are not overwritten.
- `reference/` — reference FASTA records, PDB 3MOP and figure metadata.
- `docs/` — reproducibility notes, analysis environment records, and draft structural Methods/figure legends.

## Reproducing the downstream analysis

### 1. Set up the environment

Use Python 3.12. The archived analysis environment was Python 3.12.14 with NumPy 2.5.4, SciPy 1.17.0, Biopython 1.88, Matplotlib 3.10.8, Pillow 12.3.0, OpenMM 8.6.1 and PyMOL Open Source 3.2.0a0. See `docs/*environment.json` for the environment recorded for each stage.

For figure regeneration:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements_figures.txt
```

For coordinate reanalysis and validation, install `requirements_analysis.txt`. PyMOL Open Source 3.2.0a0 is only needed for the legacy local rendering scripts; it is not needed for the integrated vector-figure pipeline.

### 2. Obtain the original Chai-1 exports

The raw model exports are distributed separately as the manuscript Supplementary Data archives because they are data outputs rather than source code. Obtain and extract:

- `Supplementary_Data_1_IRAK4_Chai.zip`
- `Supplementary_Data_2_Myddosome_WT_PAE.zip`
- `Supplementary_Data_3_Myddosome_Q29P_PAE.zip`

Extract all three so that the shared `IRAK4_Chai_Supplementary_Data/prediction_outputs/` directory is available. Copy the `prediction_outputs/` directory to this repository root. Keep the original archives unchanged. The Data 1 archive contains the monomer PAE arrays and the CIF/score exports; Data 2 and Data 3 supply the full-resolution WT and Q29P complex PAE arrays.

### 3. Recompute the archived coordinate analyses

```bash
python scripts/prepare_reanalysis.py --run
```

The script creates `reproduced_analyses/IRAK4_Chai_run1/` and `reproduced_analyses/Myddosome_Chai_run1/` as separate working trees. The archived `source_data/` and `prediction_outputs/` are treated as frozen inputs; generated outputs are written to the new working trees. Exhaustive within-species chain-copy matching is computationally expensive.

To prepare the working trees without executing the analyses:

```bash
python scripts/prepare_reanalysis.py
```

### 4. Rebuild the publication figures

The figure builder uses the archived coordinate files, metadata and derived tables already supplied in this repository:

```bash
python scripts/build_integrated_figures.py
```

Figures are written to `figures/` and standalone panels to `panels/` as PNG, SVG and PDF. The SVG/PDF outputs are vector-based; the structure illustrations are coordinate-derived C-alpha traces and selected heavy-atom sticks.

### 5. Validate outputs

After figure generation:

```bash
python scripts/validate_integration.py
```

## Important provenance and limitations

- The five ranked structures per condition are candidate outputs from **one submitted Chai-1 job per condition**, not five independently seeded biological or computational replicates. The exact Chai-1 checkpoint/version, random seeds, MSA/template hits and server-side execution metadata were not present in the recovered exports.
- Chai-1 was operated with MSA and templates enabled and user-specified restraints disabled, according to the contemporaneous Methods record. Do not invent unavailable seed/checkpoint details.
- No new predictions are launched by the scripts in this repository. All scripts operate on supplied model exports or archived coordinates/tables.
- The 3MOP experimental reference contains engineered IRAK2 R50W, whereas the predicted WT and Q29P inputs retain native IRAK2 R50. The comparison excludes IRAK2 residue 50 where appropriate and this construct difference must be disclosed.
- Some predicted assemblies contain severe remote MyD88-chain overlap. This is a geometric prediction artifact and limits interpretation of whole-complex comparisons.
- Distances, contact counts, pairwise RMSDs, PAE, ipTM and conditional SASA/burial are descriptive structural metrics. They are not binding-energy or affinity estimates and do not establish altered Myddosome assembly, kinase activation, or signaling bias.
- Candidate ranks, chain copies and pairwise comparisons are not independent biological replicates; no inferential statistics are applied to structural-model comparisons.
- The separate earlier Protenix parameter record (MSA/template enabled; five samples; ten recycles; 200 diffusion steps; seed 101) belongs to a distinct preparation workflow and is **not** the source of the Chai-1 structures analyzed here. It is therefore not used as a Chai-1 parameter description.

## Citation

Please cite the associated manuscript and the Chai-1 method paper when using these scripts or outputs. The exact Chai-1 reference is listed in the manuscript bibliography. Reference experimental structure: PDB 3MOP. Human IRAK4 reference sequence: UniProt Q9NWZ3.

## License

No open-source license is assigned in this archive. Before making the repository public, select a license for the original code and verify redistribution permissions for third-party structures, prediction outputs, and software-derived assets. Do not assume that model outputs or third-party coordinates are automatically covered by a code license.
