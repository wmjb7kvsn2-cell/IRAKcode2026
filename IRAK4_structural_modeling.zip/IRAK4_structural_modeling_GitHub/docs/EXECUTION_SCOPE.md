# Execution scope and provenance

## Completed computational work represented here

- Chai-1 structure prediction outputs for full-length IRAK4 WT, Q29P and D320Y (five ranked outputs per condition) and for WT/Q29P Myddosome death-domain assemblies (five ranked outputs per condition) are present in the separately distributed Supplementary Data archives.
- Downstream coordinate analyses, confidence summaries, quality-control diagnostics, source tables, coordinate exports and editable figure-generation scripts are archived in this repository.
- The assembly analysis uses the native-sequence 6:4:4 input design: MyD88 residues 20-117, IRAK4 residues 4-106 and IRAK2 residues 2-112. All four IRAK4 copies carry WT or Q29P, respectively.

## Not performed / not recoverable

- The Chai-1 server-side checkpoint, exact version, random seeds, MSA hits and template hits were not included in the recovered outputs.
- The recovered analysis scripts do not launch Chai-1 inference jobs.
- No new AlphaFold3, Boltz or Protenix prediction is represented by these Chai-1 output files.
- No new molecular dynamics, energy minimization, MM/PB(GB)SA, FoldX or Rosetta ddG calculation is included in this Chai-1 analysis repository.
- The separate Protenix parameter record (five samples, ten recycles, 200 diffusion steps, seed 101) was from a separate setup and must not be conflated with the Chai-1 runs.

## Interpretive safeguards

Structural comparisons are descriptive. A ranked candidate is not an independent replicate. A chain copy is not an independent replicate. PAE/ipTM, geometric contacts, inter-chain distances, RMSD and conditional SASA do not measure binding affinity or prove signaling function. Severe nonphysical overlaps in some predicted assemblies constrain interpretation.
