# IRAK4 Chai-1 structural analyses: reproduction and editing

This package integrates 25 supplied candidate models: five candidates each for
full-length IRAK4 WT, Q29P and D320Y, and five candidates each for WT and Q29P
6:4:4 MyD88-IRAK4-IRAK2 death-domain assemblies. No additional predictions,
coordinate optimization, molecular dynamics or energy calculation were run for
this integration. Original coordinate and confidence files are preserved.

## Rebuild the publication figures

Extract Supplementary Data 1. From its `IRAK4_Chai_Supplementary_Data` directory:

```bash
python -m pip install -r requirements_figures.txt
python scripts/build_integrated_figures.py
```

This rebuilds Fig. 8 and Supplementary Figs. S7-S10 as PNG, SVG and PDF, plus
seven standalone editable SVG structure panels. It uses archived numerical
tables and rigidly aligned PDBs. Full PAE arrays are unnecessary for this step:
the plotted monomer matrices are archived 10-residue-bin means of candidate
median PAE, and complex matrices are original-chain-pair PAE summaries. Full
resolution arrays remain available in Supplementary Data 1-3.

The SVGs preserve editable text, individual paths and coordinate-derived
structure groups. Open SVG in Illustrator or Inkscape; ungroup as needed.
Nimbus Sans is the plotting font. It may be substituted with Arial or another
available sans serif, with label placement checked after substitution. PDFs
contain embedded fonts and vector paths; the distributed PDFs contain no
bitmap images. Molecular figures are projected C-alpha traces and selected
heavy-atom sticks, rather than secondary-structure cartoon assignments.

Fig. 8B and C show WT and variant separately, with an identical camera and scale within each pair. Each model retains its own sidechains, and the original domain alignments are preserved. Four individual SVG panels are also supplied for independent placement.

Projection uses actual supplied coordinates and rigid viewing transforms only.
Backbone display curves interpolate C-alpha positions. Derived viewing PDBs
have standard three-decimal coordinate precision; quantitative tables were
calculated from the original CIF coordinates. Annotation distances are checked
against the viewing PDBs within 0.004 Angstrom. No alignment or geometry is
changed for illustration.

## Inspect or recompute the original coordinate analyses

Extract Supplementary Data 1, 2 and 3 into the same directory, preserving their
shared `IRAK4_Chai_Supplementary_Data` root. Data 1 includes all 25 original
CIFs, 25 score JSONs, 15 monomer PAE arrays and five MSA-depth PDFs. Data 2 and
3 add five original complex PAE arrays each for WT and Q29P. All 80 raw files
have SHA-256 entries in `source_data/raw_prediction_manifest.csv`.

Original numerical analysis scripts and their recorded environments are in
`analysis_methods/monomer` and `analysis_methods/complex`. The polished local
view scripts are retained in `analysis_methods/local_polished` for provenance;
those legacy rendering scripts require PyMOL. The new vector figure pipeline
does not require PyMOL, Biopython or OpenMM.

```bash
python scripts/prepare_reanalysis.py
```

This creates a separate `reproduced_analyses` working tree with the original
`scripts`, `inputs`, `data`, `coordinates` and `reference` layouts. It does not
alter frozen inputs or archived measurements. To run the original coordinate
analyses, first install numpy, scipy, biopython and openmm in a suitable Python
environment, then use:

```bash
python scripts/prepare_reanalysis.py --run
```

The exhaustive 414,720-permutation copy matching is computationally expensive.
The legacy environment files record the versions originally used; the new
integration environment is in `notes/integration_environment.json`. OpenMM is
used to obtain residue bond templates for geometry diagnostics, not to relax
structures or compute binding energies. Original legacy plotting/reporting
utilities are archived for provenance; the new integrated plots are generated
by `scripts/build_integrated_figures.py`.

The submitted-job seeds, model checkpoint/version, full MSA hits and template
hits were not present in the recovered exports and cannot be reconstructed.
Consequently, this reproduces the downstream coordinate analysis and figure
construction, not a bit-identical rerun of the remote Chai server jobs.

## Publication text and validation

`manuscript/revision_content.json` in the complete author package stores the
copy-ready text. `build_revision_content.py` regenerates it; the accompanying
Word/PDF generator requires python-docx, reportlab, pypdf and PyMuPDF. The
supplied manuscript itself was a review PDF, so the Word deliverables are
insertion/replacement text with precise locations, not an edited full paper.
Proposed figure numbers follow the supplied originals and must be changed
consistently if another manuscript revision has already occupied them.

`validate_integration.py` checks all twelve SVGs for editable text, unique IDs
and no embedded images; checks six PDFs for no embedded images; and validates
the numerical values used in the response. `integration_validation.json`
records the resulting audit. Every page of the delivered Word documents and
the combined four-page supplement was rendered and visually inspected.

Scientific interpretation is deliberately descriptive: candidate ranks,
assembly copies and shared-model pairs are not independent biological
replicates. Severe remote MyD88 overlap prevents a causal assembly conclusion.
Distances and pair burial are conditional geometry, not affinity or energy.

Assembly-time utilities `prepare_integration.py` and `package_submission.py`
use the recovered input archive directory of this working session; they are
retained as provenance and are not needed for figure regeneration.
