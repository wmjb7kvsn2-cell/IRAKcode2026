# Draft Methods and Figure Legends

## Structural prediction and analysis

Myddosome death-domain assemblies comprised six copies of human MyD88 residues 20–117, four copies of IRAK4 residues 4–106, and four copies of IRAK2 residues 2–112. The WT and Q29P assemblies differed only at IRAK4 residue 29; all four IRAK4 copies carried the designated allele. Both predictions used Chai-1 with MMseqs2 MSAs and templates enabled and user-specified restraints disabled, as reported by the operator. Five ranked candidates were exported for each of one submitted job per genotype. Exact seed identities, model checkpoint, software version and template/MSA hits were not included in the exports and should be added if retrievable.

All chain sequences and residue numbering were verified. Full-length residue numbering is used in derived tables and figures, while original CIFs retain fragment numbering. To compare assemblies with the experimental DD complex (PDB 3MOP), species-constrained chain correspondences were exhaustively enumerated over 6! × 4! × 4! permutations and evaluated by proper-rotation Kabsch fitting of Cα atoms. Analysis cores comprised MyD88 residues 25–110, IRAK4 residues 20–100 and IRAK2 residues 10–90 excluding residue 50 (1,160 Cα atoms per assembly). Component subassemblies were also evaluated with independent rigid fitting and exhaustive within-species copy matching. Reference-contact retention was evaluated using minimum interchain heavy-atom distances ≤4.5 Å over common experimentally observed residues, excluding IRAK2 residue 50 because 3MOP contains engineered R50W. Both prediction groups contained native IRAK2 R50.

Local IRAK4 comparisons used 51 shared core residues outside residues 24–34 with pLDDT ≥80 in all 40 predicted IRAK4 copies. The N, Cα, C and O atoms of residues 24–34 were evaluated after alignment to 3MOP chain G. Local representative conformers were actual within-group medoids of the aligned backbone windows. Per-chain dihedral angles, local confidence and displacement profiles were calculated directly from predicted coordinates. Four-copy medians were calculated for each candidate before reporting five-candidate descriptive summaries. No hypothesis tests were performed, and model/copy values were not treated as independent biological replicates.

Severe interchain proximity was independently summarized as the number of heavy-atom pairs separated by <1.5 Å, alongside the exported Chai clash flags. These counts are geometric diagnostics, not MolProbity clashscores. Conditional IRAK4–IRAK2 two-chain buried surface area was defined as half the difference between the summed isolated-chain SASA and pair SASA, using a 1.4 Å probe and 480-point Shrake–Rupley sampling over IRAK4 residues 4–106 and IRAK2 residues 2–94. Selected pairs were checked at 960 points. These measures describe the supplied geometry; they do not estimate binding energy or affinity. Structure images were rendered from unchanged coordinates with common rigid viewing transforms, cameras and scale within comparative views.

## Figure 1. Predicted Myddosome DD assemblies and experimental reference

Side and axial views of the experimentally determined Myddosome DD assembly (3MOP), WT rank 0 and Q29P rank 0. MyD88, IRAK4 and IRAK2 are blue, gold and purple, respectively. Red spheres mark the four IRAK4 Q29/P29 Cα atoms. Dashed outlines identify spatially overlapping MyD88 copies in the Q29P candidate. Comparative panels share a camera and scale within each view. IRAK2 residues 95–112, unresolved in 3MOP, are thin gray traces. The reference contains IRAK2 R50W; both prediction groups retain native R50. The overlapping copies are prediction artifacts and are not interpreted as a biological assembly phenotype.

## Figure 2. Confidence, reference agreement and ensemble variability

Candidate-level ipTM, copy-permuted core Cα RMSD to 3MOP and reference-contact retention are shown for all five candidates per genotype. Crosses identify exported Chai interchain-clash flags. Heatmaps show the median bidirectional PAE for each original chain pair in rank 0 candidates. Ensemble pairwise RMSDs use exhaustive species-constrained copy matching. Within-group and between-group pairs share model coordinates and are descriptive, not independent repeats or inferential tests.

## Figure 3. Nonphysical overlap between MyD88 copies

Contrasting colors show MyD88 chains B and E at their original predicted relative positions in WT rank 3 and Q29P rank 0. The chains were not fitted to one another. Severe interchain heavy-atom proximity (<1.5 Å) and the closest same-frame MyD88 core Cα RMSD are summarized for every candidate. This failure mode occurs in both genotypes and limits interpretation of whole-complex differences. Atom-pair counts are distinct from the internal Chai clash criterion and from MolProbity clashscores.

## Figure 4. Local IRAK4 conformation around Q29/P29

Local-chain medoids show the predicted backbone rearrangement at residues 24–34 after fitting on a shared 51-residue high-confidence core outside the evaluated window. WT and Q29P are blue and orange. The selected actual conformers are WT rank 3/chain G and Q29P rank 4/chain H; selection refers to the local window and does not validate their full assemblies. The double-headed arrow identifies a coordinate correspondence, not motion. Dihedral-angle distributions, per-residue displacement from experimental IRAK4 chain G and residue 29 pLDDT include all four IRAK4 copies per candidate. Small points represent copies and diamonds represent within-candidate medians. Profile shading spans all 20 model/copy values and is not a confidence interval. Experimental Q29 dihedrals from 3MOP chains G–J are included for context.

## Figure 5. Exploratory IRAK4–IRAK2 interface geometry

Experimental and actual rank-0 predicted local interfaces are shown after rigid alignment on the IRAK4 core. The corresponding 3MOP G–K position maps to original Chai chains J–M for WT rank 0 and G–M for Q29P rank 0. Dashed lines label the nearest residue-29 sidechain to IRAK2 W63 heavy-atom separation; atom identities differ between Gln and Pro, and no hydrogen-bond assignment is implied. All-copy separations and conditional two-chain geometric burial are shown. Predicted interface confidence is limited and all full Q29P assemblies contain remote MyD88 overlap; these panels illustrate an exploratory local-geometric hypothesis, not altered affinity or assembly function.

## Supplementary Figure 1. Complete candidate assembly atlas

All five candidates per genotype are shown at one common orientation and scale with their ipTM and original Chai clash flags. Red spheres mark IRAK4 Q29/P29. A negative clash flag is not a complete stereochemical validation.

## Supplementary Figure 2. Complete PAE atlas

All ten full residue-level PAE matrices are shown on the same 0–30 Å scale. Chains retain their original Chai order. Boundaries separate the six MyD88, four IRAK4 and four IRAK2 chains. These are confidence diagnostics, not affinity or energetic measurements.
