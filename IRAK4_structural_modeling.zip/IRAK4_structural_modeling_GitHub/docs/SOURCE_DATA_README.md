# Source Data for Fig. 8 and Supplementary Figs. S7-S10

All distances and RMSDs are in Angstrom, area in square Angstrom, angles in
degrees, pLDDT on the 0-100 scale, and ipTM on the 0-1 scale. No new predictions
were generated for this integration. No inferential tests were performed.

| Panel | Figure-labelled source | Definition or supporting source |
|---|---|---|
| Fig. 8A | Monomer `sequence_audit.csv` and `alignment_definition.json` | Domain map and verified variant numbering |
| Fig. 8B,C | Original CIFs in Supplementary Data 1; viewing PDBs in the author package | WT rank 0, Q29P rank 1, D320Y rank 0; separate views with the same camera and scale within each pair after domain-local rigid fits |
| Fig. 8B annotations | `figure_panels/Figure_8B_angles.csv` | Actual residue-29 phi/psi of the displayed WT rank 0 and Q29P rank 1 |
| Fig. 8C annotations | `figure_panels/Figure_8C_distances.csv` | Actual minimum sidechain-to-sidechain heavy-atom distances (`sidechain_sidechain_min_A`) to M265/T324 in each displayed rank-0 model |
| Fig. 8D | `figure_panels/Figure_8D.csv` | All 25 WT-variant and 10 WT-WT shared-model pairs, separate domain fits |
| S7A | `figure_panels/S7A.csv` | Per-residue median and range across five candidates |
| S7B-D | `figure_panels/S7_PAE_WT.csv`, `S7_PAE_Q29P.csv`, `S7_PAE_D320Y.csv` | Ten-residue-bin means of per-pixel candidate median PAE; CSV columns identify row/column bin starts |
| S7E,F | `figure_panels/S7E.csv`, `S7F.csv` | Mutation-site confidence and both local comparison windows |
| S8A,B | Supplementary Data 1 CIFs and local viewing PDBs | Q29P rank 0 alternative and rank 1 configuration |
| S8C,D | `figure_panels/S8C.csv`, `S8D.csv` | Residue-29 phi/psi; residue-320 minimum sidechain distances |
| S8E,F | Monomer `selected_distances.csv` | Rank-0 selected atom-pair geometry, no hydrogen-bond assignment |
| S9A-C | Supplementary Data 1 CIFs and PDB 3MOP | Exhaustive species-constrained copy matching; common camera and scale |
| S9D-F | `figure_panels/S9D.csv`, `S9E.csv`, `S9F.csv` | ipTM and Chai flags; heavy-atom pairs <1.5 A; copy-matched candidate-pair RMSD |
| S9G,H | `figure_panels/S9_PAE_WT.csv`, `S9_PAE_Q29P.csv` | Median bidirectional rank-0 PAE by original chains A-N; CSV columns identify chain pairs |
| S10A | Complex `local_medoid_annotation.json`, `local_alignment.json` | Actual local medoids, WT rank 3/G and Q29P rank 4/H |
| S10B | `figure_panels/S10B.csv` | Phi angles across monomer candidates and all complex IRAK4 copies |
| S10C,D | Complex `Q29_interface_distances.csv`, `reference_comparison.csv` | Rank-0 actual mapped IRAK4-IRAK2 pair, residue 29 to IRAK2 W63 |
| S10E,F | `figure_panels/S10E.csv`, `S10F.csv` | All copy values and per-candidate medians; pair-induced geometric burial |

The `monomer` and `complex` folders preserve the complete previously computed
tables and method-definition JSONs, including alignment sensitivity, reference
comparison, sequence audits, local geometry and validation records. Column
names distinguish original chain IDs from matched reference positions. Tables
and derived coordinates use full-length residue numbering; raw fragment CIFs
retain fragment numbering. See original input hashes in
`raw_prediction_manifest.csv` and the numerical cross-checks in
`integration_audit.json`.

Full PAE arrays and original coordinate/score files are supplied in
Supplementary Data 1-3. Candidate ranks are zero-based, and the five candidates
per input derive from one submitted job. Multiple pairs share models; four
IRAK4 copies share each complex. Point counts therefore do not define
independent sample sizes or justify significance testing.

Pair BSA is (SASA of isolated IRAK4 + SASA of isolated IRAK2 - SASA of the
two-chain pair)/2, computed with a 1.4 A probe and 480 sphere points over IRAK4
4-106 and IRAK2 2-94. Both predictions use native IRAK2 R50, whereas 3MOP uses
R50W. Severe remote MyD88 overlap and limited interface confidence restrict
these measurements to exploratory geometry, not binding or assembly effects.
